# One Liners
A collection of useful Dart-related one-liner shell commands.

## Display Number of Workers
On worker box:
```
$ systemctl list-units '*worker@*' | grep @ | cut -d@ -f1 | uniq -c
      1   blacklist_watchdog_worker
      5   cleanup_router_worker
     10   git_cleanup_worker
      5   git_worker
      1   hal_worker
      5   provision_begin_worker
     15   provision_cert_worker
     10   provision_cleanup_worker
     15   provision_ip_worker
     15   provision_kvm_worker
     10   results_worker
     10   solve_cleanup_worker
      1   solve_queue_worker
     10   solve_worker
      1   start_router_worker
      5   start_worker
     10   test_worker
```

## Update All Your Local Dart Working Directories
On your devbox:
```
cd ~/dart-src
for d in */; do  echo ==== $d; git -C $d up; done
```

## Unseal the Vault
```
$ export VAULT_ADDR="http://localhost:8200"

$ vault operator unseal $(cat unseal_key_1.txt)
Key             Value
---             -----
Seal Type       shamir
Initialized     true
Sealed          false
Total Shares    1
Threshold       1
Version         1.21.2
Build Date      2026-01-06T08:33:05Z
Storage Type    file
Cluster Name    vault-cluster-d607aee9
Cluster ID      3db2f1a8-a4dd-bf1c-9b44-415cab86fad6
HA Enabled      false
```

## Display Dart Environment Stored in Vault
```
$ vault kv get secret/dart_environment
======== Secret Path ========
secret/data/dart_environment

======= Metadata =======
Key                Value
---                -----
created_time       2026-03-10T18:27:51.81619305Z
custom_metadata    <nil>
deletion_time      n/a
destroyed          false
version            3

============== Data ==============
Key                          Value
---                          -----
AUTH_ENDPOINT                https://dev4Auth.incy-mccree.incy.tech
DART_CLI_CLIENT_ID           sfU24LKQpb3jMJASSwROZlxptKDeASrpbaXmUyo3
DART_REDIS_HOST              dev4Redis.incy-mccree.incy.tech
RESOURCE_MANAGER_ENDPOINT    https://dev4Resources.incy-mccree.incy.tech
RESULTS_ENDPOINT             https://dev4Results.incy-mccree.incy.tech
```

## List all LDAP Dart Users
```
$ ldapsearch -H ldap://incy-ad-01.incy.tech  -w 'sXgX-fMkM8AfM@wuT!' -D "CN=Dart domain join service account,OU=Dart,OU=INCY_Service_Accounts,DC=incy,DC=tech" -b "OU=DART_End_Users,OU=INCY_Users,DC=incy,DC=tech" sAMAccountName | awk -F ': ' '/^sAMAccountName/{print $2}'
mid
tester1
tester2
tester3
tester4
incy-tester2
tester5
tester6
tester7
tester8
tester9
tester10
teamlead13
teamlead14
bowser
mccree
pikachu
kirby
incy-tester
donkey.kong
Feyre
porkchop
zaphod
```

## Copy a File Into a basebox VM
```
sudo apt install guestfish

sudo virt-copy-in -a /mnt/library/ubuntu_20.04-5_server_x64_en-US_pal3_evdet-prerelease_033.qcow2 evdet.pyz /opt/EvDet
```
