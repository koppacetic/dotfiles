#!/bin/bash
CA_BUNDLE="$HOME/.dart/dart_root_ca.pem"
TOKEN=$(dart_cli show user --token)

if [[ $1 == '-v' ]]; then
    echo CURL_CA_BUNDLE=${CA_BUNDLE} curl -H "Authorization: Bearer ${TOKEN}" -H "Content-Type: application/json" $@
    echo ''
fi

CURL_CA_BUNDLE=${CA_BUNDLE} curl -H "Authorization: Bearer ${TOKEN}" -H "Content-Type: application/json" $@
echo ''
