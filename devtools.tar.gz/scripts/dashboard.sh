#!/bin/bash
# Description:
#   Show active plans, claims, and reservations.
#
ACTIVE_USERS=$(dart_cli -B show plans -Aa -l50 | tail +3 | awk '{print $4}' | sort -u)
USER_REGEX=$(echo $ACTIVE_USERS | sed -e 's/ /|/g')

dart_cli show plans -Aa -l50
dart_cli show claims -l $ACTIVE_USERS
dart_cli show reservations --recent "$USER_REGEX"

