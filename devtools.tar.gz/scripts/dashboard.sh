#!/bin/bash
ACTIVE_USERS=$(dart_cli -B show plans -Aa -l50 | tail +3 | awk '{print $4}' | sort -u)

dart_cli show plans -Aa -l50
dart_cli show claims -l $ACTIVE_USERS
dart_cli show reservations --recent

