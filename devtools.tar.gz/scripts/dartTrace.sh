#!/bin/bash
USAGE="darttrace.sh <combo_id>"
WORKERS="start solve provision_kvm provision_ip provision_cert test results provision_cleanup"

if [[ -z "$1" ]]; then
    echo $USAGE
    exit 1
fi
COMBO=$1

for worker in $WORKERS; do
    grep $COMBO /var/log/${WORKER}_worker.log
done

exit 0
