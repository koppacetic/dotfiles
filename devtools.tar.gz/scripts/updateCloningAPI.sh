#!/bin/bash
USAGE="USAGE: updateCloningAPI.sh <tarfile>"
SERVICE="cloning_api"
LOGFILE="/var/log/cloning_api.log"

abort () {
    if [[ -t 2 ]]; then
        echo $'\033[31m'"$@"$'\033[0m'
    else
        echo "$@"
    fi
    exit 1
}

[[ "$EUID" -eq 0 ]] || abort "Must be run as root"
[[ -n "$1" ]] || abort $USAGE

TARFILE=$1
[[ -f $TARFILE ]] || abort "$TARFILE doesn't exist"

# Stop the cloning_api service
echo "Stopping $SERVICE..."
systemctl stop $SERVICE


# Untar the cloning API file
echo "Extracting $TARFILE..."
rm -fr /root/.shiv
cd /opt/cloning_api
tar xvzf $TARFILE

# Zap the log file
echo "Zapping $LOGFILE..."
cat /dev/null > $LOGFILE

# Start the cloning_api service
echo "Starting $SERVICE..."
systemctl start $SERVICE

# Show status
systemctl status $SERVICE
