#!/bin/bash
USAGE="multiuser.sh [-t testplan] [-u userlist] <dart_user>"
TESTPLAN="multiUser"
DART_USER=
# Uncomment if using old LDAP
TEST_USERS="incy-tester tester1 tester2 tester3 tester4"
TEST_PASSWORD="dartadmin"
# Uncomment if using new LDAP
#TEST_USERS="tester1 tester2 tester3 tester4"
#TEST_PASSWORD="Dartadmin!"

HELPTEXT="Synopsis:
    $USAGE

Description:
    Run the same testplan as different DART users.

    <dart_user> is your personal DART user name. You will be prompted
    for your password.

Options:
    -h, --help              Print this help message
    -t, --test <testplan>   Use an alternative testplan (Default: $TESTPLAN)
    -u, --users <userlist>  List of user accounts to use (Default: $TEST_USERS)

"

abort() {
    echo $1
    exit 1
}

# Handle command line options
while true; do
    case $1 in
    -t|--test)
		TESTPLAN=$2
		shift 2
		;;
    -u|--users)
		TEST_USERS=$2
		shift 2
		;;
    -h|--help)
		echo "$HELPTEXT"
		exit 0
		;;
    -*)
		echo "$USAGE"
		exit 1
		;;
    *)
		break
		;;
    esac
done

if [[ -z "$1" ]]; then
    echo $USAGE
    exit 1
fi
DART_USER=$1

[[ -f leafbags/plans/${TESTPLAN}.py ]] || abort "leafbags/plans/${TESTPLAN}.py doesn't exist"

for user in $TEST_USERS; do
    if [[ $user == "incy-tester" ]]; then
        password="45-panama-ENERGY-able-49"
    else
        password="$TEST_PASSWORD"
    fi
    echo "======== Running $TESTPLAN as $user"
    dart_cli login -p $password $user || abort "Login failed"
    dart_cli cert download ./dart_config || abort "Cert download failed"
    dart_cli submit plans.$TESTPLAN || abort "Submit failed"
    sleep 2
done

echo "======== Running $TESTPLAN as $DART_USER"
if [[ -n "$MY_DART_PASSWORD" ]]; then
    dart_cli login -p "$MY_DART_PASSWORD" $DART_USER || abort "Login failed"
else
    dart_cli login $DART_USER || abort "Login failed"
fi
dart_cli cert download ./dart_config || abort "Cert download failed"
dart_cli submit plans.$TESTPLAN || abort "Submit failed"

exit 0
,
