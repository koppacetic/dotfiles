#!/bin/bash
USAGE="USAGE: updateWorkers.sh <tarfile>"

# Import env variables for range
source /opt/workers/env.d/common.env

abort () {
    if [[ -t 2 ]]; then
        echo $'\033[31m'"$@"$'\033[0m'
    else
        echo "$@"
    fi
    exit 1
}

[[ "$EUID" -eq 0 ]] || abort "Must be run as root"
[[ -n "$1" ]] || abort $USAGE

TARFILE=$1
[[ -f $TARFILE ]] || abort "$TARFILE doesn't exist"

cd /opt/workers
echo "Stopping workers..."
systemctl stop *worker@*.service || abort "Can't stop workers"

echo "Extracting $TARFILE..."
rm -fr .shiv
tar xvzf $TARFILE
chown pandex_worker_user:pandex_worker_user *.pyz

echo "Zapping worker logs..."
for log in $(ls /var/log/*worker.log); do
    echo $log
    cat /dev/null > $log
done

echo "Zapping Redis queues..."
redis-cli -h $PDX_REDIS_HOST flushall

echo "Restarting workers..."
systemctl --all start *worker@*.service

systemctl list-units *worker@* | grep @ | cut -d@ -f1 | uniq -c

exit 0
