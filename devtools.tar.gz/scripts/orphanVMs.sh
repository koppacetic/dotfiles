#!/bin/bash
USAGE="USAGE: orphanVMs.sh [options]"
LISTDIRS="${LISTDIRS:-$HOME}"
HOSTFILE="kvms.lst"
CLONE_DIRS="/mnt/clones /mnt/clones2"

abort() {
    echo $1
    exit 1
}

# If kvms.lst exists in current directory, use it.
if [[ -f $HOSTFILE ]]; then
    echo "Using $HOSTFILE"
    kvmlist=$(cat $HOSTFILE)
else
    # Use LISTDIRS to find kvms.lst
    for d in $LISTDIRS; do
        if [[ -f "$d/$HOSTFILE" ]]; then
            echo "Using $d/$HOSTFILE"
            kvmlist=$(cat $d/$HOSTFILE)
            break
        fi
    done
fi
[[ -z "$kvmlist" ]] && abort "ERROR: KVM list file not found: $HOSTFILE"

# Make sure clone directories exist
for d in $CLONE_DIRS; do
    [[ -d $d ]] || abort "ERROR: Clone directory does not exist: $d"
done

# Build list of known VMs
cat /dev/null > /tmp/libvirt-tmp.lst
for vmhost in $kvmlist; do
    virsh -c "qemu+ssh://$vmhost/system" list --all | awk '/_clone_/{print $2}' >> /tmp/libvirt-tmp.lst
done
sort /tmp/libvirt-tmp.lst > /tmp/libvirt.lst

# Build list of clones
cat /dev/null > /tmp/clones-tmp.lst
for cdir in $CLONE_DIRS; do
    cd $cdir
    ls *_clone_*.qcow2 | sed -e 's/.qcow2//' >> /tmp/clones-tmp.lst
done
sort /tmp/clones-tmp.lst > /tmp/clones.lst

echo -e "LIBVIRT\t\t\t\t\t\t\t\t\t\tFILES"
diff -y --suppress-common-lines --width=180 --color=always /tmp/libvirt.lst /tmp/clones.lst
