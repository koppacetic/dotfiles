#!/bin/bash
USAGE="waitForPlan.sh [-v] <plan_id>"
debug=
verbose=
HELPTEXT="Synopsis:
    $USAGE

Description:
    Wait for specified plan_id to complete.

Options:
    -h, --help Print this help message
    -v         Use an alternative testplan (Default: $TESTPLAN)

"

abort() {
    echo $1
    exit 1
}

# Handle command line options
while true; do
    case $1 in
        -D)
            debug=1
            shift
            ;;
        -v)
            verbose=1
            shift
            ;;
        -h|--help)
            echo "$HELPTEXT"
            exit 0
            ;;
        -*)
            echo "$USAGE"
            exit 1
            ;;
        *)
            break
            ;;
    esac
done

if [[ -z "$1" ]]; then
    echo $USAGE
    exit 1
fi
PLAN_ID=$1

while true; do
    pstatus=$(dart_cli -B show plan $PLAN_ID | tail -1)
    [[ -n "$debug" ]] && echo "$pstatus"
    running=$(echo $pstatus | awk '{print $12}')
    staging=$(echo $pstatus | awk '{print $13}')
    pending=$(echo $pstatus | awk '{print $14}')
    if [[ "$running" == "0" && "$staging" == "0" && "$pending" == "0" ]]; then
        break
    fi
    sleep 5
done

if [[ -n "$verbose" ]]; then
    dart_cli show plan $PLAN_ID
fi

exit 0
