#!/bin/bash
USAGE="checkPlan.sh [--cleanup] [-k <kvmlistfile>] [-s <status>] <planId>"
debug=
verbose=
do_cleanup=
opts=
xopts="-v"

# Handle command line options
while true; do
    case $1 in
    -D)
        debug=1
        shift
        ;;

    --cache)
        CACHE_TIME=$2
        xopts="$xopts --cache $CACHE_TIME"
        shift 2
        ;;

    --cleanup)
        do_cleanup=1
        shift
        ;;

    -k)
        xopts="$xopts -k $2"
        shift 2
        ;;

    -s)
        opts="-s $2"
        shift 2
        ;;

    -*)
        echo $USAGE
        exit 1
        ;;

    *)
        break
        ;;
    esac
done

if [[ -z "$1" ]]; then
    echo $USAGE
    exit 1
fi
PLAN_ID=$1

# Filter out USB devices
VM_LIST=$(dart_cli -B show tests $opts -r $PLAN_ID | grep -v usb_ | sort -u)

# Tell findClone.sh to create and use a cache file
if [[ -z "$CACHE_TIME" ]]; then
    MY_CACHE_TIME=$(date +%Y%m%d%H%M)
    xopts="$xopts --cache $MY_CACHE_TIME"
fi

for vm in $VM_LIST; do
    [[ -n "$debug" ]] && echo "==== Checking $vm"
    if [[ -n "$do_cleanup" ]]; then
        findClone.sh $xopts --delete $vm
    else
        findClone.sh $xopts $vm
    fi
done

# Cleanup cache files
if [[ -z "$CACHE_TIME" ]]; then
    rm -f /tmp/*_${MY_CACHE_TIME}.txt
fi

exit 0
