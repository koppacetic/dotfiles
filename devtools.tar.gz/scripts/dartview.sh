#!/bin/bash
# Description:
#   View DART results files
#
USAGE="dartview.sh <sub|plan|test> <id> GLOB"

if [[ -z "$3" ]]; then
    echo $USAGE
    exit 1
fi
RTYPE=$1
ID=$2
GLOB=$3

FILES=$(dart_cli results list $RTYPE $ID $GLOB)
$PAGER $FILES
