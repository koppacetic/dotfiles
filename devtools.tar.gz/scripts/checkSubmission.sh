#!/bin/bash
USAGE="checkSubmission.sh [--cleanup] [-k <kvmlistfile>] <submissionId>"
debug=
do_cleanup=
xopts=

# Handle command line options
while true; do
    case $1 in
    -D)
        debug=1
        shift
        ;;

    --cleanup)
        do_cleanup=1
        shift
        ;;

    -k)
        xopts="$xopts -k $2"
        shift 2
        ;;

    -*)
        echo $USAGE
        exit 1
        ;;

    *)
        break
        ;;
    esac
done

if [[ -z "$1" ]]; then
    echo $USAGE
    exit 1
fi
SUB_ID=$1

# Get plan IDs
PLANS=$(dart_cli -B show plans -s $SUB_ID | tail +3 | awk '{print $1}')

# Tell findClone.sh to create and use a cache file
CACHE_TIME=$(date +%Y%m%d%H%M)
xopts="$xopts --cache $CACHE_TIME"

for plan in $PLANS; do
    echo "==== Checking plan $plan"
    if [[ -n "$do_cleanup" ]]; then
        checkPlan.sh $xopts --cleanup $plan
    else
        [[ -n "$debug" ]] && echo checkPlan.sh $xopts $plan
        checkPlan.sh $xopts $plan
    fi
done

# Cleanup cache files
#rm -f /tmp/*_${CACHE_TIME}.txt

exit 0

