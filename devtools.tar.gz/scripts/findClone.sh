#!/bin/bash
USAGE="findClone.sh [--delete] [-k <kvmlistfile>] [-v] <clone_name>"
KLIST_FILE="kvms.lst"
CLONE_DIRS="/mnt/clones /mnt/clones2"
debug=
verbose=
do_delete=
CACHE_TIME=

abort() {
    echo $1
    exit 1
}

# Handle command line options
while true; do
    case $1 in
    --cache)
        CACHE_TIME=$2
        shift 2
        ;;

    --delete)
        do_delete=1
        shift
        ;;

    -D)
        debug=1
        shift
        ;;

    -k)
        KLIST_FILE=$2
        shift 2
        ;;

    -v)
        verbose=1
        shift
        ;;

    -*)
        abort "$USAGE"
        ;;

    *)
        break
        ;;
    esac
done

if [[ -z "$1" ]]; then
    abort "$USAGE"
fi
CLONE=$1

if [[ ! -f "$KLIST_FILE" ]]; then
    # Look for file in $HOME/.dart
    if [[ ! -f "$HOME/.dart/$KLIST_FILE" ]]; then
        abort "File not found: $KLIST_FILE"
    fi
    KLIST_FILE="$HOME/.dart/$KLIST_FILE"
fi
KVM_SERVERS=$(cat $KLIST_FILE)

for kvm in $KVM_SERVERS; do
    [[ -n "$debug" ]] &&  echo "---- $kvm"
    if [[ -n "$CACHE_TIME" ]]; then
        # Create cache file (if it doesn't exist)
        CACHE_FILE="/tmp/${kvm}_${CACHE_TIME}.txt"
        if [[ ! -f $CACHE_FILE ]]; then
            virsh -c "qemu+ssh://${kvm}/system" list --all > $CACHE_FILE
        fi

        # Use cache file
        if grep -q ${CLONE} $CACHE_FILE; then
            KVM_SERVER=$kvm
            break
        fi
    else
        # Query libvirt directly
        if virsh -c "qemu+ssh://${kvm}/system" list --all | grep -q ${CLONE}; then
            KVM_SERVER=$kvm
            break
        fi
    fi
done

start_dir=$PWD
for d in $CLONE_DIRS; do
    cd $d
    if ls -lh ${CLONE}* &>/dev/null; then
        CLONE_DIR=$d
        break
    fi
done
cd $start_dir

waitForShutdown() {
    LIBVIRT_URL=$1

    while true; do
        found=$(virsh -c $LIBVIRT_URL list --state-shutoff | grep $1)
        [[ -n "$found" ]] && break
        echo -n "."
        sleep 2
    done
    echo ""
}

vmDelete() {
    LIBVIRT_URL=$1
    VMNAME=$2

    isRunning=$(virsh -c $LIBVIRT_URL list --state-running | grep $VMNAME)
    if [[ -n "$isRunning" ]]; then
        echo "Destroying $VMNAME..."
        virsh -c $LIBVIRT_URL destroy $VMNAME || abort "Error destroying $VMNAME"
        waitForShutdown $LIBVIRT_URL $VMNAME
    fi

    echo "Undefining $VMNAME..."
    virsh -c $LIBVIRT_URL undefine $VMNAME --remove-all-storage --delete-storage-volume-snapshots --checkpoints-metadata --nvram
}

if [[ -n "$KVM_SERVER" || -n "$CLONE_DIR" ]]; then
    [[ -n "$verbose" ]] &&  echo "---- $CLONE"
    if [[ -n "$KVM_SERVER" ]]; then
        echo "KVM: $KVM_SERVER"
    fi
    if [[ -n "$CLONE_DIR" ]]; then
        echo "DIR: $CLONE_DIR"
    fi

    if [[ -n "$do_delete" ]]; then
        if [[ -n "$KVM_SERVER" ]]; then
            LIBVIRT_URL="qemu+ssh://${KVM_SERVER}/system"
            vmDelete $LIBVIRT_URL $CLONE
        elif [[ -n "$CLONE_DIR" ]]; then
            echo "Removing from $CLONE_DIR"
            sudo rm $CLONE_DIR/$CLONE.qcow2
        fi
    fi
fi

exit 0
