# devtools
A collection of tools for DART development.

## Scripts

- checkPlan.sh
- findClone.sh
- dartcurl.sh
- dartTrace.sh
- bexec
- bcopy
- updateWorkers.sh
- updateResourceMan.sh
- updateResultsMan.sh
- updateAuth.sh
- updateCloningAPI.sh

### checkPlan.sh
A script for checking whether all the resources for a plan were removed properly and optionally clean them up if needed.

Usage:
```
checkPlan.sh [--cleanup] [-k <kvmlistfile>] [-s <status>] <planId>
```

What it does:
1. Gets a list of all the resources used by a plan
2. For each resource:
    - See if it still exists in libvirt
    - See if it's .qcow2 file still exists

Options:
 - --cleanup: Remove any resources that still exist
 - -k \<kvmlistfile>: Specify a file containing KVM server hostnames
 - -s \<status>: Only check resources for tests with \<status>

Example usage:
```
checkPlan.sh 5220

checkPlan.sh -s error 5220

checkPlan.sh --cleanup 5199
```

### findClone.sh
Determine whether a clone still exists in libvirt or in the clones directory.

Usage:
```
findClone.sh [--delete] [-k <kvmlistfile>] [-v] <clone_name>
```

What it does:
1. Uses virsh to determine if the clone exists on one of the KVM servers
2. Determines if the clone's .qcow2 file exists in one of the clones directories.

Options:
 - --delete: Remove the clone from KVM server and/or clones dir
 - -k \<kvmlistfile>: Specify a file containing KVM server hostnames
 - -v: Verbose mode

Example usage:
```
findClone.sh debian_8-11_server_x64_en-US_pal3_033_clone_eaCJzvfywd_tester2

findClone.sh -k kvms.lst -v windows_10-22H2_pro_x86_en-US_pal3_033_clone_IV3wh0LEbc_tester2

findClone.sh --delete debian_11-6_server_x64_en-US_pal3_033_clone_8V2zcOs5TK_tester2
```

### dartcurl.sh
A script for using curl to query DART REST API endpoints.

Usage:
```
dartcurl.sh [curl options] [curl parameters]
```

What it does:
1. Adds the auth token to the curl command
2. Set the root cert to $HOME/.dart/dart_root_ca.pem

Example usage:
```
dartcurl.sh 'https://dev4Resources.incy-mccree.incy.tech/claims/'

dartcurl.sh 'https://dev4Results.incy-mccree.incy.tech/api/results/?plan=983'

dartcurl.sh -X DELETE 'https://dev4resources.incy-mccree.incy.tech/claims/280/'
```

### dartTrace.sh
A script for debugging test combos in the worker log files.

Usage:
```
dartTrace.sh <string>
```

What it does:
Greps through the worker log files IN ORDER for a string.

Most useful by passing it a combo_id or clone name.

Examples:
```
dartTrace.sh windows_10-1511_enterprise-n_x86_en-US_pal3_033_clone_siry9cUau4_mccree

dartTrace.sh 3f34f59a-c2e7-492a-8bc2-d80ba5488cf1
```

### bexec (batch execute)
A script for executing the same command on multiple machines.

Usage:
```
bexec <hostlist file> <command>
```

A \<hostlist file\> is just a text file containing a list of hostnames, one per line.

For example, kvms.lst:
```
kvm-r2-u30.qqcyber.net
kvm-r2-u34.qqcyber.net
kvm-r2-u37.qqcyber.net
kvm-r2-u38.qqcyber.net
```

NOTE: You will need to ssh-copy-id your SSH key to any hostname in \<hostlist file\>.

To run the uptime command on every KVM server, you'd do:
```
> bexec kvms.lst uptime
======== kvm-r2-u30.qqcyber.net ========
 14:07:23 up  2:33,  0 users,  load average: 2.10, 2.52, 8.10
======== kvm-r2-u34.qqcyber.net ========
 14:07:23 up 236 days, 23:57,  2 users,  load average: 0.88, 1.70, 8.43
======== kvm-r2-u37.qqcyber.net ========
 14:07:24 up 19 days, 23:10,  0 users,  load average: 5.05, 6.39, 13.72
======== kvm-r2-u38.qqcyber.net ========
 14:07:25 up 98 days,  4:25,  0 users,  load average: 6.38, 7.32, 14.55
 ```

To make sure all the KVM servers are running the same version of cloning_api:
```
> bexec kvms.lst ls -l /opt/cloning_api/cloning_api
======== kvm-r2-u30.qqcyber.net ========
-rwxr-xr-x 1 1001 1001 13538236 Dec  6 09:27 /opt/cloning_api/cloning_api
======== kvm-r2-u34.qqcyber.net ========
-rwxr-xr-x 1 1001 1001 13538236 Dec  6 09:27 /opt/cloning_api/cloning_api
======== kvm-r2-u37.qqcyber.net ========
-rwxr-xr-x 1 1001 1001 13538236 Dec  6 09:27 /opt/cloning_api/cloning_api
======== kvm-r2-u38.qqcyber.net ========
-rwxr-xr-x 1 1001 1001 13538236 Dec  6 09:27 /opt/cloning_api/cloning_api
```

If you need to run piped commands, just enclose the string in single quotes:
```
> bexec kvms.lst 'df -h | grep clones'
======== kvm-r2-u30.qqcyber.net ========
10.100.1.16:/mnt/datastore/ironcity/clones       2.3T  1.2T  1.1T  52% /mnt/clones
10.100.1.16:/mnt/datastore/ironcity/clones2      1.5T  385G  1.1T  26% /mnt/clones2
======== kvm-r2-u34.qqcyber.net ========
10.100.1.16:/mnt/datastore/ironcity/clones       2.3T  1.2T  1.1T  52% /mnt/clones
10.100.1.16:/mnt/datastore/ironcity/clones2      1.5T  385G  1.1T  26% /mnt/clones2
======== kvm-r2-u37.qqcyber.net ========
10.100.1.16:/mnt/datastore/ironcity/clones       2.3T  1.2T  1.1T  52% /mnt/clones
10.100.1.16:/mnt/datastore/ironcity/clones2      1.5T  385G  1.1T  26% /mnt/clones2
======== kvm-r2-u38.qqcyber.net ========
10.100.1.16:/mnt/datastore/ironcity/clones2      1.5T  385G  1.1T  26% /mnt/clones2
10.100.1.16:/mnt/datastore/ironcity/clones       2.3T  1.2T  1.1T  52% /mnt/clones
```

 You can create multiple \<hostlist files\> for whatever purpose you want. For example, I have
 one for all the hosts in my range, mccree.lst.

### bcopy (batch copy)
A script copying the same file to multiple machines.

Usage:
```
bcopy [-d dir] <hostlist file> <file>
```

The \<hostlist file\> is just like the one used for bexec.

If no dir is specified the file is copied to the user's home directory.

To copy myfile.txt into /tmp on all the hosts in my range:
```
❯ bcopy -d /tmp mccree.lst myfile.txt
======== dev4vault ========
myfile.txt                                                          100%   91   108.5KB/s   00:00
======== dev4auth ========
myfile.txt                                                          100%   91    70.6KB/s   00:00
======== dev4kea ========
myfile.txt                                                          100%   91    76.7KB/s   00:00
======== dev4dns ========
myfile.txt                                                          100%   91    36.8KB/s   00:00
======== dev4redis ========
myfile.txt                                                          100%   91    64.8KB/s   00:00
======== dev4workers ========
myfile.txt                                                          100%   91    38.2KB/s   00:00
======== dev4resources ========
myfile.txt                                                          100%   91   103.7KB/s   00:00
======== dev4results ========
myfile.txt                                                          100%   91    39.5KB/s   00:00
======== dev4ui ========
myfile.txt                                                          100%   91    66.4KB/s   00:00
```

### updateWorkers.sh
A script for upgrading Panda Express. Install it on the workers VM.

What it does:
1. Stops all workers
2. Updates the workers from the specified tarfile
3. Removes the .shiv directory
4. Truncates all the worker logs
5. Clears the Redis queues
6. Starts all the workers

Example usage:
```
sudo ./updateWorkers.sh ~/panda_express-1.1.3-linux-x86_64-bundle.tar.gz
```

### updateResourceMan.sh
A script for upgrading the Resource Manager. Install it on the resource manager VM.

What it does:
1. Stops dart_resource_manager service
2. Updates the resource manager from the specified tarfile
3. Removes the .shiv directory
4. Runs makemigrations
5. Runs migrate
6. Truncates /var/log/dart_resource_manager.log
7. Starts dart_resource_manager service

Example usage:
```
sudo ./updateResourceMan.sh ~/resource_manager-1.1.2-linux-x86_64-bundle.tar.gz
```

### updateResultsMan.sh
A script for upgrading the Results Manager. Install it on the results manager VM.

What it does:
1. Stops dart_results_manager service
2. Updates the results manager from the specified tarfile
3. Removes the .shiv directory
4. Runs makemigrations
5. Runs migrate
6. Truncates /var/log/dart_results_manager.log
7. Starts dart_results_manager service

Example usage:
```
sudo ./updateResultsMan.sh ~/results_manager-1.0.0-linux-x86_64-bundle.tar.gz
```

### updateAuth.sh
A script for upgrading the Authentication Manager. Install it on the auth manager VM.

What it does:
1. Stops dart_auth_manager service
2. Updates the auth manager from the specified tarfile
3. Removes the .shiv directory
4. Runs makemigrations
5. Runs migrate
6. Truncates /var/log/dart_auth_manager.log
7. Starts dart_auth_manager service

Example usage:
```
sudo ./updateAuth.sh ~/auth_manager-0.4.4-linux-x86_64-bundle.tar.gz
```

### updateCloningAPI.sh
A script for upgrading the Cloning API. Install it on KVM servers.

What it does:
1. Stops cloning_api service
2. Updates the Cloning API from the specified tarfile
3. Removes the .shiv directory
6. Truncates /var/log/cloning_api.log
7. Starts cloning_api service

Example usage:
```
sudo ./updateCloningAPI.sh ~/cloning_api-1.3.0-linux-x86_64-debian-bundle.tar.gz
```
