# BASH Tips
Helpful tips for using Bash with DART.

## .bashrc
Some helpful things to add to your .bashrc file.

```
# Put .venv in project dir instead of $HOME
export PIPENV_VENV_IN_PROJECT=1

# Shorthand to switch to your venv
alias psh='pipenv shell'

# Pretty print JSON output
alias jt='python3 -m json.tool'

# Pretty print JSON to pager
jtm () {
    python3 -m json.tool "$@" | less
}
```

Examples:
```
dartcurl.sh 'https://dev4Resources.incy-mccree.incy.tech/claims/3484/' | jt

jtm vmscan.json
```

## Switching KVM servers
To easily switch between KVM servers when using virsh, I also add this to my .bashrc
```
alias .lv='echo LIBVIRT_DEFAULT_URI: $LIBVIRT_DEFAULT_URI'
alias .lv229='export LIBVIRT_DEFAULT_URI="qemu+ssh://kvm-r2-u29.int.qqcyber.net/system"'
alias .lv230='export LIBVIRT_DEFAULT_URI="qemu+ssh://kvm-r2-u30.int.qqcyber.net/system"'
alias .lv234='export LIBVIRT_DEFAULT_URI="qemu+ssh://kvm-r2-u34.int.qqcyber.net/system"'
alias .lv237='export LIBVIRT_DEFAULT_URI="qemu+ssh://kvm-r2-u37.int.qqcyber.net/system"'
alias .lv238='export LIBVIRT_DEFAULT_URI="qemu+ssh://kvm-r2-u38.int.qqcyber.net/system"'
```

Now I can do:
```
> .lv229
> virsh list
 Id      Name                                                                     State
-------------------------------------------------------------------------------------------
 4633    debian_11-6_server_x64_en-US_pal3_033_clone_33Kk8PpNaC_tester2           running
 4977    fedora_36_server_x64_en-US_pal3_033_clone_8qTY1dvHbu_tester3             running
 8805    debian_11-6_server_x64_en-US_pal3_033_clone_QmKjhE1OFI_tester3           running
 11900   windows_8-sp0_enterprise-n_x64_en-US_pal3_033_clone_RhaYaH0Jj4_tester2   running
 18121   debian_10-13_server_x64_en-US_pal3_033_clone_v5qvti6Zm8_tester1          running
 24063   debian_11-6_server_x64_en-US_pal3_033_clone_wrPCLKK3jb_mccree            running
 24064   debian_10-13_server_x64_en-US_pal3_033_clone_PfMzS3NbbG_bowser           running
 24231   windows_10-1703_enterprise_x86_en-US_pal3_033_clone_lxKsK2CEkp_mario     running

> .lv234
> virsh list
 Id      Name                                                                            State
--------------------------------------------------------------------------------------------------
 440     win7test                                                                        running
 444     pikarestest                                                                     running
 9178    windows_10-21H1_enterprise_x86_en-US_pal3_033_clone_BEHshYwHUi_pikachu          running
 12672   windows_2012-sp0_datacenter-desktop_x64_en-US_pal3_033_clone_NGlOP4iT5l_mario   running
 17038   windows_10-1511_enterprise_x86_en-US_pal3_033_clone_DjtvAoWRfJ_tester1          running
 18036   fedora_27_server_x64_en-US_pal3_033_clone_akCfYsDE8R_tron                       running
 21554   windows_8.1-sp0_pro_x86_en-US_pal3_033_clone_vetyS4P9A4_mario                   running
 21562   windows_10-22H2_home_x64_en-US_pal3_033_clone_E5nVjF0bn8_mario                  running
 21681   windows_10-21H1_enterprise-n_x64_en-US_pal3_033_clone_ZiBLV1uYFG_mario          running
 24282   windows_10-21H2_pro_x64_en-US_pal3_033_clone_FLT3dWvAjx_pikachu                 running
 28966   windows_10-1903_enterprise_x86_en-US_pal3_033_clone_5ewhPw5AoF_mario            running
 28972   windows_8-sp0_pro-n_x64_en-US_pal3_033_clone_vS2jPKM0CR_mario                   running
 28973   windows_10-1703_pro_x86_en-US_pal3_033_clone_LnJMMxDUVk_mario                   running
 28974   windows_10-22H2_home_x64_en-US_pal3_033_clone_epotklmB2J_mario                  running
> .lv
LIBVIRT_DEFAULT_URI: qemu+ssh://kvm-r2-u34.int.qqcyber.net/system
```
