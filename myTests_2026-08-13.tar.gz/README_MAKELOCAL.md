# Makelocal Test Script
A test to install the makelocal.sh script on a primary VM and then from that VM
installs a secondary VM.

## Primary VM Requirements
- Linux based OS
- Packages:
    - Debian: nfs-common, qemu-utils, libvirt-clients
- NFS mount point for base VMs
- NFS mount points for clone dirs
- Enough disk space to hold secondary VM

## Secondary VM Requirements
- Must be manually reserved
- Must be shut down

## Configuration
Edit the make_local.py test and update the following variables at the top of the
script for your current environment:
- BASE_DIR
- CLONE_DIRS
- NFS_SERVER

Tweak the code in the makelocal_setup() method that modifies /etc/fstab.
Make sure the remote NFS file paths are correct.

## Overall Logic

### runSetup()
1. Verify it's a Linux system
2. Install required APT packages

### run()
1. Shutdown secondary VM
2. Copy makelocal.sh to primary VM
3. Make $HOME/LocalVMs dir
4. Create NFS mount points
5. Add mount points to /etc/fstab
6. Mount NFS directories
7. Run makelocal.sh script
8. Verify downloaded secondary VM
