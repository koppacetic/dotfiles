#!/bin/bash
# Description:
#   Get bad VMs from a test plan
#
USAGE="getBad.sh <planId>"
HELPTEXT="Synopsis:
    $USAGE

Description:
    Get the VMs that failed from test run.

Options:
    -h, --help              Print this help message

"

# Handle command line options
while true; do
    case $1 in
    -h|--help)
		echo "$HELPTEXT"
		exit 0
		;;
    -*)
		echo "$USAGE"
		exit 1
		;;
    *)
		break
		;;
    esac
done

if [[ -z "$1" ]]; then
    echo $USAGE
    exit 1
fi
PLAN_ID=$1

# Collect VMs that failed for whatever reason
echo "Collecting Purged tests..."
dart_cli --data show tests -s purged $PLAN_ID | grep Skipped | awk '{print $2}' > bad1.txt
echo "Collecting Skipped tests..."
dart_cli --data show tests -s skipped $PLAN_ID | grep Skipped | awk '{print $2}' >> bad1.txt
#echo "Collecting Staging tests..."
#dart_cli --data show tests -s staging $PLAN_ID | grep Staging | awk '{print $2}' >> bad1.txt
echo "Collecting Error tests..."
dart_cli --data show tests -s error   $PLAN_ID | grep Error   | awk '{print $2}' >> bad1.txt
echo "Collecting Failure tests..."
dart_cli --data show tests -s failure $PLAN_ID | grep Failure | awk '{print $2}' >> bad1.txt

# Sort them and convert to base names
sort bad1.txt | sed -e 's/_clone.*$//' > bad.txt

# Print count
wc -l bad.txt

# Cleanup
rm -f bad1.txt
