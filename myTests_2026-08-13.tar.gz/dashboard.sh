#!/bin/bash
# Description:
#   Show active plans, claims, and reservations.
#
PLIMIT=200
ACTIVE_USERS=$(dart_cli --data show submissions -Aa | awk '{print $4}' | sort -u)
USER_REGEX=$(echo $ACTIVE_USERS | sed -e 's/ /|/g')

if [[ $1 == "--sub" ]]; then
    dart_cli show submissions -Aa
else
    dart_cli show plans -Aa -l$PLIMIT
fi
dart_cli show claims -l $ACTIVE_USERS
dart_cli show reservations --recent "$USER_REGEX"
