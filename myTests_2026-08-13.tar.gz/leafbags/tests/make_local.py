#
# Upload the makelocal.sh script to the primary VM, set up primary VM to run makelocal.sh, then run makelocal.sh
# to download secondary VM to primary.
#
# undermine tests.make_local <PrimaryRID> <SecondaryRID>
#
# Required files:
#   media/makelocal.sh
#
# NOTE: Secondary VM must be shutdown prior to running this script.
#
# NOTE: Secondary VM must not be MacOS.
#
import os
import time

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

BASE_DIR = "/mnt/library"
CLONE_DIRS = ["/mnt/clones", "/mnt/clones2"]
NFS_SERVER = "10.100.1.16"

MAKELOCAL_SCRIPT = "makelocal.sh"
PACKAGES = "nfs-common qemu-utils libvirt-clients"
MAX_TRIES = 24  # 4 minutes

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            self.log.info("-------- Shutting down secondary VM...")
            HAL(self.host2, bypass_version_check=True)
            self.log.info("Calling power_off...")
            (success, msg) = self.host2.HAL.power_off()
            if not success:
                return self.FAILURE, msg

            # Wait for secondary VM to power off
            self.log.info("Waiting for power off...")
            status = self._wait_for_power(self.host2, False)
            if status < 0:
                return self.FAILURE, "Secondary VM failed to shut down"
            self.log.info("Secondary VM has been shut down")

            ros = self.host.mirrorfunc("import", "os")
            rhome = ros.getenv("HOME")
            self.log.info(f"RHOME: {rhome}")

            self.log.info(f"-------- Transferring makelocal")
            rv, msg = self.makelocal_transfer(rhome, ros)
            if rv != self.SUCCESS:
                return rv, msg

            self.log.info("-------- Setting up makelocal...")
            rv, msg = self.makelocal_setup(rhome, ros)
            if rv != self.SUCCESS:
                return rv, msg

            self.log.info("-------- Running makelocal...")
            rv, msg = self.makelocal_run(rhome, ros)
            if rv != self.SUCCESS:
                return rv, msg

            return self.SUCCESS, f"Installed {self.secondary} successfully"
        except Exception as ex:
            return self.FAILURE, f"Exception: {ex}"

    def makelocal_setup(self, home, ros):
        """Set up for a makelocal.sh run
        1. Create $HOME/LocalVMs directory
        2. Create NFS mount point directories
        3. Add NFS mount points to /etc/fstab
        4. Mount the NFS mount points
        """
        if not ros.path.exists(f"{home}/LocalVMs"):
            local_VMs = ros.path.join(home, "LocalVMs")
            self.log.info(f"Creating {local_VMs} directory...")
            rv = self.host.mkdir(local_VMs)

        self.log.info(f"Creating NFS mount points...")
        if not ros.path.exists(BASE_DIR):
            rv = self.host.mkdir(BASE_DIR)
        for clone_dir in CLONE_DIRS:
            if not ros.path.exists(clone_dir):
                rv = self.host.mkdir(clone_dir)

        self.log.info(f"Adding NFS mount points to /etc/fstab...")
        contents = self.host.fread("/etc/fstab", is_text=True)
        if contents.find(NFS_SERVER) == -1:
            self.host.fappend("/etc/fstab", "\n", is_text=True)
            self.host.fappend("/etc/fstab", f"{NFS_SERVER}:/mnt/datastore/library\t{BASE_DIR}\tnfs\tdefaults,nolock 0 0\n", is_text=True)
            self.host.fappend("/etc/fstab", f"{NFS_SERVER}:/mnt/datastore/ironcity/clones\t{CLONE_DIRS[0]}\tnfs\tdefaults,nolock 0 0\n", is_text=True)
            self.host.fappend("/etc/fstab", f"{NFS_SERVER}:/mnt/datastore/ironcity/clones2\t{CLONE_DIRS[1]}\tnfs\tdefaults,nolock 0 0\n", is_text=True)
            contents = self.host.fread("/etc/fstab", is_text=True)
        # ---- DEBUG
        # self.log.info(f"/etc/fstab:\n{contents}")
        # ---- DEBUG

        self.log.info(f"Mounting NFS directories...")
        rc, out = self.host.execcmd("mount -a", shell=True, returncode=self.host.execute.RETURN)
        self.log.info(out)
        if rc != 0:
            return self.FAILURE, out
        # ---- DEBUG
        # rc, out = self.host.execcmd("df -ht nfs4", shell=True, returncode=self.host.execute.RETURN)
        # self.log.info(f"NFS:\n{out}")
        # if rc != 0:
        #     return self.FAILURE, out
        # ---- DEBUG

        return self.SUCCESS, f"{MAKELOCAL_SCRIPT} set up complete"

    def makelocal_transfer(self, home, ros):
        """Transfer makelocal.sh to target, verify transfer, and fix file permissions."""
        lpath = os.path.join("media", MAKELOCAL_SCRIPT)
        rpath = ros.path.join(home, MAKELOCAL_SCRIPT)
        self.log.info(f"Putting {lpath} to {rpath}...")
        rv = self.host.put(lpath, rpath)

        # Verify transfer
        lsize = os.stat(lpath).st_size
        rsize = ros.stat(rpath).st_size
        if lsize != rsize:
            return self.FAILURE, f"local size: {lsize}, remote size: {rsize}"

        # Fix file permissions
        rc, out = self.host.execcmd(f"chmod 755 {rpath}", shell=True, returncode=self.host.execute.RETURN)
        self.log.info(out)
        if rc != 0:
            return self.FAILURE, out

        return self.SUCCESS, f"{MAKELOCAL_SCRIPT} transferred successfully"

    def makelocal_run(self, home, ros):
        """Run makelocal.sh on target"""
        cmd = f"{home}/makelocal.sh --no-virsh -b {BASE_DIR} {self.kvm_server} {self.secondary}"
        self.log.info(f"EXECUTE: {cmd}")
        rc, out = self.host.execcmd(cmd, shell=True, returncode=self.host.execute.RETURN)
        self.log.info(out)
        if rc != 0:
            return self.FAILURE, out

        # Verify secondary VM was downloaded
        rpath = f"{home}/LocalVMs/{self.secondary}.qcow2"
        if not ros.path.exists(rpath):
            return self.FAILURE, f"{rpath} not downloaded from {self.kvm_server}"

        return self.SUCCESS, f"{MAKELOCAL_SCRIPT} ran successfully"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            self.log.info(f"-------- Verifying resources...")
            if len(self.resources) != 2:
                self.log.error(f"Expected 2 resources, got {len(self.resources)}")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("Primary VM has no db_properties")
                return False

            self.primary = self.host.db_properties.get("name")
            if self.primary is None:
                self.log.error("Primary VM has no name")
                return False
            self.log.info(f"PRIMARY: {self.primary}")

            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("Primary VM has no properties")
                return False

            # Verify primary VM is Linux
            if self.host.properties.get("family", "") != "linux":
                self.log.error("Primary VM is not a Linux host")
                return False

            # Verify secondary VM
            self.host2 = self.resources[1]
            if not hasattr(self.host2, "db_properties") or self.host2.db_properties is None:
                self.log.error("Secondary VM has no db_properties")
                return False

            self.secondary = self.host2.db_properties.get("name")
            if self.secondary is None:
                self.log.error("Secondary VM has no name")
                return False
            self.log.info(f"SECONDARY: {self.secondary}")

            parent = self.host2.db_properties.get("parent")
            if parent is None:
                self.log.error("Secondary VM has no parent")
                return False

            # Get kvm_server from parent of secondary VM
            self.kvm_server = parent.get("name")
            if self.kvm_server is None:
                self.log.error("Parent has no name")
                return False
            self.log.info(f"KVM SERVER: {self.kvm_server}")
            time.sleep(15)

            # Determine which package manager to use
            self.log.info(f"-------- Updating package manager...")
            if self.host.properties.get("os_name", "") in ["debian", "ubuntu"]:
                pacman = "apt"
            else:
                pacman = "dnf"

            # Update package manager
            command = f"{pacman} -q -y update"
            self.log.info(f"EXECUTE: {command}")
            rc, out = self.host.execcmd(command, shell=True, returncode=self.host.execute.RETURN)
            self.log.info(out)
            if rc != 0:
                return False

            # Install required packages
            self.log.info(f"-------- Installing required packages...")
            command = f"{pacman} -q -y install {PACKAGES}"
            self.log.info(f"EXECUTE: {command}")
            rc, out = self.host.execcmd(command, shell=True, returncode=self.host.execute.RETURN)
            self.log.info(out)
            if rc != 0:
                return False

            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return False

    def _wait_for_power(self, host, state: bool) -> int:
        """ Wait for power_state of host to match specified state. """
        tries = 0
        while tries < MAX_TRIES:
            try:
                (success, powered_up) = host.HAL.power_state()
                self.log.info(f"powered_up: '{powered_up}'")
                if success and powered_up == state:
                    break
            except Exception as ex:
                self.log.info(f"power_state() error: {ex}")

            tries += 1
            time.sleep(10)

        if tries >= MAX_TRIES:
            return -1
        return 0

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
