import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi


@leafi.MainLeaf()
@leafi.DefineProcessor()
class TestInfo(leaf.Leaf):
    def parseArgs(self, username=None, password=None, domain=None, method=None, createAcct=False, **kwargs):
        self.username = username
        self.password = password
        self.domain   = domain
        self.method   = method
        self.createAcct = createAcct

    def runSetup(self):
        self.parseArgs(*self.args, **self.kwargs)
        return True

    def run(self):
        if len(self.resources) == 0:
            return self.FAILURE, "No resources"
        host = self.resources[0]
        assert isinstance(host, undermine.undermine.client.Client)
        assert isinstance(host, palantir.client.Client)

        # properties = host.db_properties.get("properties")
        # os_family = properties.get("family")
        os_family = host.get_os_family()

        self.log.info("Getting emissary...")
        em = host.getEmissary(self.username, self.password)

        self.log.info("Running whoami...")
        em_user = em.execcmd('whoami').rstrip()

        self.log.info('Emissary user is {}'.format(em_user))
        if self.username is not None:
            if not self.username.lower().endswith(em_user.lower()):
                raise Exception('Expected user %r but found %r' % (self.username, em_user))

        return self.SUCCESS, f"Emissary {os_family} user: {em_user}"

    def runCleanup(self):
        return
