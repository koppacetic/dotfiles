import time
from datetime import datetime
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

SLEEP_TIME = 1 * 60
snapshot_name = ["SNAPSHOT_01"]
snapshot_name2 = ["SNAPSHOT_DUP_CHECK"]
snapshot_names = ["snapshot_01", "snapshot_02", "snapshot_03"]

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## runSetup ########")
        try:
            HAL(self.host)

            # check if the resource has any snapshots
            self.log.info("--- Checking for pre-existing snapshots")
            rv, snapshots = self.listSnapshots()
            if rv == self.FAILURE:
                return rv, "Error listing snapshots"
            if len(snapshots) > 0:
                self.log.info("Deleting pre-existing snapshots")
                rv, msg = self.deleteSnapshots(snapshots)
                if rv == self.FAILURE:
                    return rv, "Error deleting pre-existing snapshots"
                rv, snapshots = self.listSnapshots()
                if rv == self.FAILURE:
                    return rv, "Error listing snapshots"
                if len(snapshots) > 0:
                    self.log.info("Pre-existing snapshots not really deleted")
                    return self.FAILURE, "Pre-existing snapshots not really deleted"

            # Create snapshots
            self.log.info('--- Creating snapshots')
            rv, msg = self.createSnapshots(snapshot_names)
            if rv == self.FAILURE:
                return rv, msg
            rv, snapshots = self.listSnapshots()
            if rv == self.FAILURE:
                return rv, "Error listing snapshots"
            if len(snapshots) != len(snapshot_names):
                self.log.info("Snapshot count mismatch")
                return self.FAILURE, "Snapshot count mismatch"

            rv, snapshot = self.listCurrentSnapshot()
            if rv == self.FAILURE:
                return rv, "Failed to list current snapshot"
            self.log.info(f'Current snapshot\n{snapshot}')

            # Duplicate snapshot check
            self.log.info('--- Snapshot duplicate check')
            rv, msg = self.createSnapshots(snapshot_name2)
            if rv == self.FAILURE:
                return rv, f"Cannot create {snapshot_name2}"
            rv, msg = self.createSnapshots(snapshot_name2)
            if rv != self.FAILURE:
                return self.FAILURE, f"Created {snapshot_name2} twice!"
            rv, msg = self.deleteSnapshots(snapshot_name2)
            if rv == self.FAILURE:
                return rv, f"Cannot delete {snapshot_name2}"

            self.log.info("--- List all snapshots")
            rv, snapshots = self.listSnapshots()
            if rv == self.FAILURE:
                return rv, "Error listing snapshots"
            self.log.info(snapshots)

            # Delete all snapshots
            self.log.info("--- Delete all snapshots")
            rv, msg = self.deleteSnapshots(snapshots)
            if rv ==  self.FAILURE:
                return rv, msg
            rv, snapshots = self.listSnapshots()
            if rv == self.FAILURE:
                return rv, "Error listing snapshots"
            if len(snapshots) != 0:
                self.log.info("All snapshots not deleted")
                return self.FAILURE, "All snapshots not deleted"

            return self.SUCCESS, "Snapshot tests successful!"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def createSnapshots(self, snapshotnames):
        for name in snapshotnames:
            start = datetime.now()
            (ok, snapshot) = self.host.HAL.snapshot_vm(name)
            if not ok:
                self.log.info(f"Failed to create: {name}")
                return self.FAILURE, f"Failed to create: {name}"
            duration = datetime.now() - start
            self.log.info(f"Created {name} in {duration.seconds} seconds")
            time.sleep(1)
        return self.SUCCESS, "All snapshots created"

    def deleteSnapshots(self, snapshots):
        for name in snapshots:
            start = datetime.now()
            (ok, msg) = self.host.HAL.delete_snapshot(name)
            if not ok:
                self.log.info(f"Failed to delete {name}: {msg}")
                return self.FAILURE, f"Failed to delete {name}: {msg}"
            duration = datetime.now() - start
            self.log.info(f"Deleted {name} in {duration.seconds} seconds")
        return self.SUCCESS, "All snapshots deleted"

    def listCurrentSnapshot(self):
        (ok, snapshot) = self.host.HAL.get_current_snapshot()
        if not ok:
            return self.FAILURE, "Failed to get current snapshot"
        return self.SUCCESS, snapshot

    def listSnapshots(self):
        # check if the resource has any snapshots
        (ok, snapshots) = self.host.HAL.list_snapshots()
        if not ok:
            return self.FAILURE, "Failed to list snapshots"
        return self.SUCCESS, snapshots

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            # Check number of resources passed to test script
            if len(self.resources) < 1:
                self.log.error("Wrong number of resources specified, expecting at least 1")
                return False

            # Make sure resources were specified using rid://
            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.log.info(f"HOST: {self.host.db_properties.get('name')}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False

            return True
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
