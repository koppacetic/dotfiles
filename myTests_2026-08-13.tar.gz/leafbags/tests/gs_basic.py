import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from gs_client import __version__ as gs_version

TEST_DIR = "/test"

@leafi.MainLeaf()
class MyTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")

        try:
            self.log.info(f"CLIENT VERSION: {gs_version}")
            self.log.info(f"AGENT VERSION: {self.host.version()}")

            self.log.info(f"FAMILY: {self.host.get_os_family()}")
            ipaddr = self.host.get_agent_ip()
            self.log.info(f"IP ADDRESS: {ipaddr}")

            self.log.info(f"Creating {TEST_DIR} directory...")
            rv = self.host.mkdir(TEST_DIR, make_all=True)
            self.log.info(f"mkdir() returned {rv}")

            self.log.info(f"Removing {TEST_DIR} directory...")
            rv = self.host.rmdir(TEST_DIR)
            self.log.info(f"rmdir() returned {rv}")

            self.log.info(f"Calling survey()...")
            survey = self.host.survey()
            self.log.info(f"SURVEY: {survey}")

            self.log.info(f"Executing whoami...")
            (retcode, whoami, stderr) = self.host.execcmd("whoami", shell=True)
            if retcode != 0:
                self.log.error(f"Error: retcode={retcode}\n{stderr}")
            self.log.info(f"WHOAMI: {whoami.strip()}")

            if self.host.get_os_family() == "windows":
                self.log.info(f"Executing systeminfo...")
                (retcode, sysinfo, stderr) = self.host.execcmd("systeminfo", shell=True)
                if retcode != 0:
                    self.log.error(f"Error: retcode={retcode}\n{stderr}")
                self.log.info(f"SYSINFO:\n{sysinfo.strip()}")

                self.log.info(f"Calling mirrorfunc...")
                r_os = self.host.mirrorfunc("import", "os")
                self.log.info(f"Calling r_os.getlogin()...")
                user = r_os.getlogin()
                self.log.info(f"USER: {user}")

            self.log.info(f"Calling os.getlogin...")
            user = self.host.execfunc("os.getlogin")
            self.log.info(f"USER: {user}")

            return self.SUCCESS, f"Genestealer test complete"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) < 1:
                self.log.error("Wrong number of resources specified, expecting at least 1")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.log.info(f"HOST: {self.host.db_properties.get('name')}")

            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False

            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
