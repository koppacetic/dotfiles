import gc
import time

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from event_detection.evdet_util import EvDet

EVDET_INTERVAL = 2.0
INTERVAL_TOLERANCE = 0.25

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            for host in self.targets:
                hostname = host.db_properties.get("name")
                self.log.info(f"-------- Starting EvDet on {hostname}, interval={EVDET_INTERVAL}")
                evDet = EvDet(host, self.eventDet, interval=EVDET_INTERVAL)

                self.log.info("Getting emissary...")
                em = host.getEmissary()

                self.log.info(f"Executing emissary whoami...")
                em_whoami = em.execcmd("whoami", shell=True)
                self.log.info(f"WHOAMI: {em_whoami}")

                self.log.info(f"Executing emissary notepad...")
                retval = em.execcmd("notepad.exe", shell=True, wait=False, detach=True)
                self.log.info(f"{retval}")

                self.log.info(f"Sleeping...")
                time.sleep(5)

                self.log.info("Stopping EvDet...")
                numEvents, max_interval, numFailures = evDet.stop(get_files=True)
                evDet = None
                msg = f"Got {numEvents} events, {numFailures} failures. max_interval {max_interval:.4f}"
                self.log.info(msg)

                if max_interval - EVDET_INTERVAL > INTERVAL_TOLERANCE:
                    msg = f"Max interval was {max_interval:.4f}, expected {EVDET_INTERVAL} or less"
                    self.log.error(msg)
                    return self.FAILURE, msg

                # Force garbage collection
                self.log.info("Garbage collecting...")
                gc.collect()

            time.sleep(5)
            return self.SUCCESS, "EvDet ran successfully on all hosts"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) < 2:
                self.log.error("Wrong number of resources specified, expecting at least 2")
                return False

            self.targets = []
            for ii, res in enumerate(self.resources):
                # First host is EvDet
                if ii == 0:
                    self.eventDet = self.resources[ii]
                    if not hasattr(self.eventDet, "db_properties") or self.eventDet.db_properties is None:
                        self.log.error("No db_properties, use rid:// to specify resources")
                        return False
                    evdet_hostname = self.eventDet.db_properties.get("name")
                    self.log.info(f"EVDET: {evdet_hostname}")
                    if not self.eventDet.service_is_up():
                        self.log.error(f"Agent not responding on {evdet_hostname}")
                        return False
                    continue

                self.targets.append(self.resources[ii])
                if not hasattr(self.targets[ii-1], "db_properties") or self.targets[ii-1].db_properties is None:
                    self.log.error("No db_properties, use rid:// to specify resources")
                    return False
                hostname = self.targets[ii-1].db_properties.get("name")
                self.log.info(f"HOST: {hostname}")
                self.targets[ii-1].properties = self.targets[ii-1].db_properties.get("properties")
                if self.targets[ii-1].properties is None:
                    self.log.error("No properties found")
                    return False
                if not self.targets[ii-1].service_is_up():
                    self.log.error(f"Agent not responding on {hostname}")
                    return False

            return True
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
