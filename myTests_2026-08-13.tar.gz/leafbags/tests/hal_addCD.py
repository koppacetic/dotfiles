import time
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

MAX_TRIES = 60  # 5 minutes
SLEEP_TIME = 2

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        if len(self.resources) == 0:
            return self.FAILURE, "### No resource ###"

        self.log.info("Getting resource")
        self.tgt = self.resources[0]

        self.log.info("Setting up HAL")
        HAL(self.tgt)
        self.log.info("====== Resource IP: {} ======".format(self.tgt.ip))

        self.log.info('====== Adding CD test: {} ======='.format(self.tgt.ip))

        # source = "/mnt/iso/template/iso/Win11_23H2_English_x64v2.iso"      # test windows
        # source = "/mnt/iso/template/iso/en-US/debian-11.8.0-amd64-netinst.iso" #u38
        # source = "/mnt/ios/fake.iso"
        source = "/mnt/iso/en-US/linux/debian/debian-10.11.0-amd64-netinst.iso"

        # breakpoint()
        (success, msg) = self.tgt.HAL.add_cd(source, set_default=True)
        # # (success, msg) = self.tgt.HAL.add_cd(source, set_default=False)
        if not success:
            self.log.info("### failed to add_cd: {}".format(msg))
            return self.FAILURE, "### Failed to add cd: {} ###".format(msg)


        self.log.info("add_cd test succeeded")

        #reboot (powerOff and powerOn)
        rv, msg = self.testReboot()
        self.log.info(f"{rv} {msg}")
        if rv != self.SUCCESS:
            return self.FAILURE, "Failed to reboot after adding CD"

        # remove CD
        self.log.info('====== remove_cd test from host: {} ======='.format(self.tgt.ip))

        (success, msg) = self.tgt.HAL.remove_cd(source)
        if not success:
            self.log.info("### failed to remove_cd: {}".format(msg))
            return self.FAILURE, "### Failed to remove cd: {} ###".format(msg)

        self.log.info("remove_cd test succeeded")

        #reboot (powerOff and powerOn)
        rv, msg = self.testReboot(force=True)
        self.log.info(f"{rv} {msg}")
        if rv != self.SUCCESS:
            return self.FAILURE, "Failed to reboot after removing CD"

        return self.SUCCESS, "Test completed"

    def testReboot(self, force=False):
        host = self.resources[0]
        # power off
        self.log.info("======= PowerOff Test =======")
        (success,msg) = host.HAL.power_off(force=True)
        if not success:
            self.log.info("### Waiting for powerOff failed...")
            return self.FAILURE, msg

        self.log.info("Waiting for powered off state...")
        status = self._wait_for_power(host, False)
        self.log.info('status powerOff: {}'.format(status))
        if status < 0:
            return self.FAILURE, "Wait for PowerOff failed"

        self.log.info('### power state host: {} ###'.format(msg))

        self.log.info("powerOff succeeded")

        # power on
        time.sleep(60)
        self.log.info("======= PowerOn Test =======")
        (success, msg) = self.tgt.HAL.power_on()
        if not success:
            self.log.info("### Waiting for powerOn failed...")
            return self.FAILURE, msg

        self.log.info("Waiting for powered on state...")
        status = self._wait_for_power(host, True)
        self.log.info('status powerOn: {}'.format(status))
        if status < 0:
            return self.FAILURE, "Wait for PowerOn failed"

        self.log.info('### power state host: {} ###'.format(msg))

        self.log.info("powerOn succeeded")

        return self.SUCCESS, "powerOff and powerOff succeeded"

    def _wait_for_service(self, resource, state: bool) -> int:
        """ Wait for Palantir service of host to match specified state. """
        tries = 0
        while tries < MAX_TRIES:
            is_up = resource.service_is_up()
            self.log.info(f"is_up: {is_up}")
            if is_up == state:
                break
            tries += 1
            time.sleep(5)
        #breakpoint()
        if tries >= MAX_TRIES:
            #self.log.info("### this host services is not up after 30 tries")
            return -1
        return 0

    def _wait_for_power(self, host, state: bool) -> int:
        """ Wait for power_state of host to match specified state. """
        tries = 0
        while tries < MAX_TRIES:
            try:
                #breakpoint()
                (success, powered_up) = host.HAL.power_state()
                self.log.info(f"powered_up: '{powered_up}'")
                if success and powered_up == state:
                    break
            except Exception as ex:
                self.log.info(f"power_state() error: {ex}")

            tries += 1
            time.sleep(5)

        if tries >= MAX_TRIES:
            return -1
        return 0

    def runCleanup(self):
        self.log.info('### runCleanup ###')
        return
