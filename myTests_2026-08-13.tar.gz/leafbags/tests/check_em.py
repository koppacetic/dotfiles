import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

@leafi.MainLeaf()
@leafi.DefineProcessor()
class EmissaryTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        properties = self.host.db_properties.get("properties")
        os_family = properties.get("family")

        self.log.info(f"Getting emissary for '{self.username}'...")
        em = self.host.getEmissary(self.username, self.password)

        self.log.info("Running whoami...")
        em_user = em.execcmd('whoami').rstrip()

        self.log.info(f"Emissary user: {em_user}")
        if self.username is not None:
            if not em_user.lower().endswith(self.username.lower()):
                return self.FAILURE, f"Expected user '{self.username}' but found '{em_user}'"

        return self.SUCCESS, f"Emissary {os_family} user: {em_user}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) == 0:
            self.log.error("No resources specified")
            return False

        self.host = self.resources[0]
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.hostname = self.host.db_properties.get("name", "VM")
            self.log.info(f"HOST: {self.hostname}")

        if not self.host.service_is_up():
            self.log.error("Palantir not responding")
            return False

        self.parseArgs(*self.args, **self.kwargs)
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return

    def parseArgs(self, username=None, password=None, domain=None, method=None, createAcct=False, **kwargs):
        self.username = username
        self.password = password
        self.domain   = domain
        self.method   = method
        self.createAcct = createAcct
