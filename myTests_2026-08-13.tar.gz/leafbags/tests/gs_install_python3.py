import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

PUT_DIR = "temp"

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            # This script only works on Windows 64bit
            os_family = self.host.get_os_family()
            if os_family != "windows":
                return self.FAILURE, f"This test doesn't support: {os_family}"
            os_arch = self.host.get_os_arch()
            if os_arch != "x86_64":
                return self.FAILURE, f"This test doesn't support: {os_arch}"

            self.log.info(f"Creating {PUT_DIR} directory...")
            rv = self.host.mkdir(PUT_DIR, make_all=True)
            self.log.info(f"mkdir returned: {rv}")
            # if rv != 0:
            #     self.log.error(f"Error: retcode={rv}\n{stderr}")
            #     return self.FAILURE, f"Mkdir error: retcode={rv}\n{stderr}"

            self.log.info(f"Putting python-3.8.10 file...")
            rv = self.host.put("media/python-3.8.10-amd64.exe", PUT_DIR)
            self.log.info(f"put returned: {rv}")
            # if rv != 0:
            #     self.log.error(f"Error: retcode={rv}\n{stderr}")
            #     return self.FAILURE, f"Put error: retcode={rv}\n{stderr}"

            self.log.info(f"Executing python-3.8.10 installer...")
            cmd = "python-3.8.10-amd64.exe /passive InstallAllUsers=1 Shortcuts=0 Include_doc=0 Include_tcltk=0 Include_test=0 TargetDir=C:\\python38"
            rv, stdout, stderr = self.host.execcmd(cmd, shell=True, wait=True, cwd=PUT_DIR)
            if rv != 0:
                self.log.error(f"Installer error: retcode={rv}\n{stderr}")
                return self.FAILURE, f"Installer error: retcode={rv}\n{stderr}"
            self.log.info(stdout)

            return self.SUCCESS, "Python-3.8.10 installed successfully"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) == 0:
                self.log.error("No resources specified")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties found, use rid:// to specify resources")
                return False

            hostname = self.host.db_properties.get("name")
            if hostname is None:
                self.log.error("No 'name' in db_properties")
                return False
            self.log.info(f"HOST: {hostname}")

            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False

            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
