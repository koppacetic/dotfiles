"""
Checks the difference between the local machine's time and a given resource's time.

This script helps locate resources that have incorrect time or timezone settings.
The time calculations take timezones into account.
"""

from datetime import datetime, timezone

import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

def seconds_to_hms(total_seconds):
    """ Converts total seconds to hours, minutes, seconds. """
    sign = 1
    if total_seconds == 0:
        return 0, 0, 0
    if total_seconds < 0:
        total_seconds = -1 * total_seconds
        sign = -1

    hours = sign * (total_seconds // 3600)
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    return hours, minutes, seconds

@leafi.MainLeaf()
@leafi.DefineProcessor()
class TimeCheck(leaf.Leaf):
    """ Test that checks for incorrect time settings on a resource. """
    def run(self):
        host = self.resources[0]
        family = host.db_properties["properties"]["family"]

        # get resource time in seconds
        if family == "windows":
            cmd = "powershell -command \"[int64](([DateTime]::UtcNow - [DateTime]'1970-01-01').TotalSeconds)\""
        else:
            cmd = "date -u +%s"  # linux/freebsd/darwin
        resource_time_utc = int(host.execcmd(cmd, shell=True))
        host.log.info(f"{resource_time_utc=}")

        # get reference time
        reference_time_utc = int(datetime.now(timezone.utc).timestamp())
        host.log.info(f"{reference_time_utc=}")

        # if the time is off by more than 1 minute, report an error
        delta = reference_time_utc - resource_time_utc
        h, m, s = seconds_to_hms(delta)
        if abs(delta) < 60:
            return self.SUCCESS, f"delta={h}h {m}m {s}s"
        else:
            return self.FAILURE, f"delta={h}h {m}m {s}s"
