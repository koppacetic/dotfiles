import re
import socket
import subprocess
import time

import chardet
import dateutil
import palantir
import paramiko
import undermine
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from undermine.underlib.system.win_utils import getLoggedInUser

# Configuration
ACCOUNTS = ["Administrator", "admin", "user"]
ACCOUNTS_CHECK = True
ACTIVATION_CHECK = False
POWERMGT_CHECK = True
UAC_CHECK = True
RDP_CHECK = False
REARM_CHECK = True

EMISSARY_CHECK = True

RUSSIAN_ADMINISTRATOR = "администратор"

REARM_SCRIPT_PATH = "/Windows/Temp/rearm.txt"
REARM_SCRIPT_PATH2 = "/Windows/Temp/rearm.bat"
# Retry every 10 seconds for 3 minutes
REARM_SLEEP_TIME = 10
REARM_RETRIES = 18

@leafi.MainLeaf()
@leafi.DefineProcessor()
class VmTest(leaf.Leaf):
    """Check basic functionality of a virtual machine."""

    def run(self):
        self.log.info("######## run ########")

        # Check for no Palantir
        if self.host.properties.get("agent") == "none":
            retval, retmsg = self.verify_agentless_vm()
            return retval, retmsg

        if not self.host.service_is_up():
            self.log.error("Palantir not responding")
            return self.FAILURE, "Palantir not responding"

        # Log User/Palantir/Undermine info
        r_pal = self.host.mirrorfunc('import', 'palantir')
        remote_ver = r_pal.__version__
        local_ver = palantir.__version__

        retval = self.SUCCESS
        retmsg = ""
        if self.host.properties.get("family") == 'windows':
            (domain, user_name) = getLoggedInUser(self.host)
            self.log.info(f"User: {domain}/{user_name}, Undermine: {undermine.__version__}, RemotePalantir: {remote_ver}, LocalPalantir: {local_ver}")
            if local_ver != remote_ver:
                self.log.warning("Palantir version mismatch")

            if ACCOUNTS_CHECK:
                self.log.info("======== Checking accounts...")
                if not self.accountsOK():
                    retval = self.FAILURE
                    if len(retmsg) > 0:
                        retmsg += ", "
                    retmsg += "Accounts check failed"
                    self.log.error("Accounts check failed")

            if ACTIVATION_CHECK:
                self.log.info("======== Checking Windows activation...")
                if not self.activationOK():
                    retval = self.FAILURE
                    if len(retmsg) > 0:
                        retmsg += ", "
                    retmsg += "Windows activation check failed"
                    self.log.error("Windows activation check failed")

            if UAC_CHECK:
                self.log.info("======== Checking User Access Control (UAC)...")
                if not self.userAccessOK():
                    retval = self.FAILURE
                    if len(retmsg) > 0:
                        retmsg += ", "
                    retmsg += "Windows UAC check failed"
                    self.log.error("Windows UAC check failed")

            if RDP_CHECK:
                self.log.info("======== Checking Window Remote Desktop (RDP)...")
                if not self.remoteDesktopOK():
                    retval = self.FAILURE
                    if len(retmsg) > 0:
                        retmsg += ", "
                    retmsg += "Windows RDP check failed"
                    self.log.error("Windows RDP check failed")

            if POWERMGT_CHECK:
                self.log.info("======== Checking power management...")
                if not self.powerOK():
                    retval = self.FAILURE
                    if len(retmsg) > 0:
                        retmsg += ", "
                    retmsg += "Power management check failed"
                    self.log.error("Power management check failed")

            if REARM_CHECK:
                self.log.info("======== Checking Windows rearm script...")
                if not self.rearmOK():
                    retval = self.FAILURE
                    if len(retmsg) > 0:
                        retmsg += ", "
                    retmsg += "Windows rearm check failed"
                    self.log.error("Windows rearm check failed")

        elif self.host.properties.get("family") in ['linux', 'bsd', 'macos']:
            r_getpass = self.host.mirrorfunc('import', 'getpass')
            user_name = r_getpass.getuser()
            self.log.info(f"User: {user_name}, Undermine: {undermine.__version__}, RemotePalantir: {remote_ver}, LocalPalantir: {local_ver}")
            if local_ver != remote_ver:
                self.log.warning("Palantir version mismatch")
        else:
            return self.FAILURE, f"Invalid OS family: {self.host.properties.get('family')}"

        if EMISSARY_CHECK:
            # Check Emissary
            self.log.info(f"======== Checking emissary...")
            if not self.emissaryOK():
                retval = self.FAILURE
                if len(retmsg) > 0:
                    retmsg += ", "
                retmsg += "Emissary check failed"
                self.log.error("Emissary check failed")

        if retmsg == "":
            retmsg = "All VM checks completed successfully"
        return retval, retmsg

    def ssh_connect(self, host, username, password, timeout=30):
        """Returns a connected Parimiko client object."""

        start_time = time.time()
        while time.time() - start_time < timeout:
            client = paramiko.SSHClient()
            client.load_system_host_keys()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            try:
                client.connect(hostname=host, port=22, username=username, password=password, timeout=5)
                return client
            except (paramiko.ssh_exception.NoValidConnectionsError, socket.timeout) as e:
                self.log.info(f"SSH service is not ready: {e}")
                client.close()

        raise TimeoutError(f"Failed to connect via SSH to {host}")

    def verify_agentless_vm(self):
        """ Verify VMs that don't have an agent (e.g. Palantir) """
        ip = self.host.properties.get("nic_primary").get("ip")
        self.log.info(f"======== Pinging IP address {ip}...")
        rc, out = subprocess.getstatusoutput(f"ping -c1 {ip}")
        if rc != 0:
            return self.FAILURE, "No response from ping"

        olines = out.split("\n")
        self.log.info(olines[0])
        self.log.info(olines[-1])

        family = self.host.properties.get("family")
        if family in ["linux", "bsd", "esxi"]:
            if family == "esxi":
                username = "root"
            else:
                username = "user"

            self.log.info(f"======== Connecting to {username}@{ip}...")
            try:
                client = self.ssh_connect(ip, username=username, password="dartadmin")
                self.log.info("Connected")

                if family != "esxi":
                    self.log.info(f"======== Checking for sudo privileges...")
                    _, stdout, stderr = client.exec_command("sudo id")

                    errout = stderr.read().decode().strip()
                    if errout:
                        self.log.error(errout)
                        return self.FAILURE, errout

                    output = stdout.read().decode().strip()
                    if output:
                        self.log.info(output)

                    client.close()
            except Exception as ex:
                self.log.error(f"{type(ex).__name__}: {ex}")
                return self.FAILURE, "Failed to connect via ssh"

        return self.SUCCESS, "All VM checks completed successfully"

    def remoteDesktopOK(self):
        """Verify that Windows Remote Desktop (RDP) is enabled."""
        # RDP not supported on Windows Home editions
        if self.host.properties.get("edition") in ["home", "home-n", "home-basic", "home-kn", "home-premium"]:
            self.log.warning("Remote Desktop not supported on Windows Home editions, skipping...")
            return True

        retval = True
        cmd = "reg query \"HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server\" /v fDenyTSConnections"
        self.log.info(f"Exec: {cmd}")
        b_results = self.host.execcmd(cmd, shell=True, wait=True)
        if type(b_results) is bytes:
            results = b_results.decode('utf-8', errors='replace')
        else:
            results = b_results

        found_status = False
        lines = results.split("\r\n")
        for full_line in lines:
            line = str(full_line.strip())
            if len(line) == 0:
                continue
            self.log.info(line)
            if "fDenyTSConnections" in line:
                found_status = True
                parts = line.split()
                rdpStatus = parts[-1]
                if rdpStatus != "0x0":
                    retval = False
                break
        if not found_status:
            retval = False

        return retval

    def userAccessOK(self):
        """Verify that Windows User Access Control (UAC) is enabled."""
        retval = True
        cmd = "reg query HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\ /v EnableLUA"
        self.log.info(f"Exec: {cmd}")
        b_results = self.host.execcmd(cmd, shell=True, wait=True)
        if type(b_results) is bytes:
            results = b_results.decode('utf-8', errors='replace')
        else:
            results = b_results

        found_status = False
        lines = results.split("\r\n")
        for full_line in lines:
            line = str(full_line.strip())
            if len(line) == 0:
                continue
            self.log.info(line)
            if "EnableLUA" in line:
                found_status = True
                parts = line.split()
                enableLUA = parts[-1]
                if enableLUA != "0x1":
                    retval = False
                break
        if not found_status:
            retval = False

        return retval

    def activationOK(self):
        """Verify Windows has been activated.

        Possible values for LicenseStatus:
            0=Unlicensed
            1=Licensed
            2=OOBGrace
            3=OOTGrace
            4=NonGenuineGrace
            5=Notification
            6=ExtendedGrace

        The only acceptable value is 1.
        """
        retval = True
        cmd = "powershell -c \"(Get-WmiObject -Query 'SELECT LicenseStatus FROM SoftwareLicensingProduct WHERE PartialProductKey IS NOT NULL').LicenseStatus\""
        self.log.info(f"Exec: {cmd}")
        b_results = self.host.execcmd(cmd, shell=True, wait=True)
        if type(b_results) is bytes:
            results = b_results.decode('utf-8', errors='replace').rstrip()
        else:
            results = b_results.rstrip()
        self.log.info(f"Windows activation status: {results}")
        if results != "1":
            retval = False

        return retval

    def rearmOK(self):
        """Verify Windows rearm script is in temp directory."""
        # Rearm script not supported on Windows core editions
        edition = self.host.properties.get("edition")
        if edition is not None and re.search(r'core', edition) is not None:
            self.log.info("Rearm check not supported on core editions, skipping...")
            return True

        for _ in range(REARM_RETRIES):
            rv = self.host.path_exists(REARM_SCRIPT_PATH) or self.host.path_exists(REARM_SCRIPT_PATH2)
            if bool(rv):
                return True
            self.log.info(f"Sleeping for {REARM_SLEEP_TIME} seconds...")
            time.sleep(REARM_SLEEP_TIME)

        self.log.info(f"Rearm check failed after {REARM_RETRIES*REARM_SLEEP_TIME} seconds")
        return False

    def powerOK(self):
        """Verify power management settings"""
        commands = [
            "powercfg /query scheme_current sub_sleep standbyidle",
            "powercfg /query scheme_current sub_sleep hibernateidle",
            "powercfg /query scheme_current sub_disk diskidle",
            "powercfg /query scheme_current sub_video videoidle",
        ]

        retval = True
        if self.host.properties.get("family") == "windows":
            # Powercfg not supported on Windows 7
            if self.host.properties.get("os_version") in ["7", "2008r2"]:
                self.log.warning("Power management check not supported on this OS, skipping...")
                return True

            for cmd in commands:
                self.log.info(f"Exec: {cmd}")
                b_results = self.host.execcmd(cmd, shell=True, wait=True)
                if type(b_results) is bytes:
                    results = b_results.decode('utf-8', errors='replace')
                else:
                    results = b_results

                lines = results.split("\r\n")
                if len(lines) < 5:
                    self.log.error(f"Command failed: nlines={len(lines)}, need at least 5 lines")
                    retval = False
                    continue

                # self.log.info(lines[-4])
                parts = lines[-4].split()
                if parts[-1] != "0x00000000":
                    self.log.error("Failed (AC)")
                    retval = False

                # self.log.info(lines[-3])
                parts = lines[-3].split()
                if parts[-1] != "0x00000000":
                    self.log.error("Failed (DC)")
                    retval = False
        elif self.host.properties.get("family") == "linux":
            pass
            # cmd = "systemd-inhibit --list"
            # self.log.info(f"Exec: {cmd}")
            # b_results = self.host.execcmd(cmd, shell=True, wait=True)
            # if type(b_results) is bytes:
            #     results = b_results.decode('utf-8', errors='replace')
            # else:
            #     results = b_results

            # found_status = False
            # lines = results.split("\r\n")
            # for full_line in lines:
            #     line = str(full_line.strip())
            #     if len(line) == 0:
            #         continue
            #     self.log.info(line)
            #     # if "UPower" in line:
            #     #     found_status = True
            # # if not found_status:
            # #     retval = False
        else:
            self.log.warning(f"Power management check not supported on {self.host.properties.get('family')}")

        return retval

    def accountsOK(self):
        """Verify Windows Administrator, admin, and user accounts exist and their password don't expire"""
        retval = True

        lang = self.host.properties.get("language")
        for acct_name in ACCOUNTS:
            # Handle foreign language Administrator account
            if acct_name == "Administrator" and lang.startswith("ru"):
                acct_name = RUSSIAN_ADMINISTRATOR

            cmd = f"net user {acct_name}"
            self.log.info(f"Exec: {cmd}")
            rc, b_results = self.host.execcmd(cmd, shell=True, wait=True, returncode=self.host.execute.RETURN)
            if type(b_results) is bytes:
                self.log.info(f"Detecting encoding of {len(b_results)} bytes...")
                cd_result = chardet.detect(b_results)
                encoding = cd_result['encoding']
                self.log.info(f"Encoding is '{encoding}', decoding bytes...")
                results = b_results.decode(encoding, errors='replace')
            else:
                results = b_results

            if rc != 0:
                self.log.error(f"Command failed: rc={rc}, results={results}")
                retval = False
                continue

            lines = results.split("\r\n")
            for ii, line in enumerate(lines):
                self.log.info(f"{ii}: {line}")

            # Check for password expiration
            parts = lines[9].split()
            if parts[1] == "expires":       # English language VM
                if parts[2] != "Never":
                    self.log.error(f"Password for {acct_name} expires on {parts[2]}")
                    retval = False
            else:                           # Foreign language VM
                # If last field on line 9 contains a date, then the password expires
                try:
                    expire_dt = dateutil.parser.parse(parts[-1], fuzzy=True)
                    self.log.error(f"Password for {acct_name} expires")
                    retval = False
                except dateutil.parser.ParserError as ex:
                    pass

        return retval

    def emissaryOK(self):
        """Verify Emissary functionality"""
        try:
            em = self.host.getEmissary()
        except Exception as ex:
            self.log.error(f"ERROR: {ex}")
            return False

        em_user = em.execcmd('whoami').rstrip()
        if em_user is None:
            self.log.error("Emissary whoami returned None")
            return False

        self.log.info(f"Emissary user: {em_user}")
        return True

    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) == 0:
            self.log.error("No resources specified")
            return False

        self.host = self.resources[0]
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.hostname = self.host.db_properties.get("name", "UNKNOWN")
            self.log.info(f"HOST: {self.hostname}")
        else:
            self.log.error("No db_properties found")
            return False

        self.host.properties = self.host.db_properties.get("properties")
        if self.host.properties is None:
            self.log.error("No properties found")
            return False
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
