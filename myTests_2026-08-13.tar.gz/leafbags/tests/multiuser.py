import random
import time

import palantir
import undermine
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
import undermine.underlib.wingman as WM
from event_detection.evdet_util import EvDet
from undermine.underlib.system.win_utils import getLoggedInUser

EVDET_INTERVAL = 2.0
INTERVAL_TOLERANCE = 0.25

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            self.log.info(f"Starting EventDetection, interval={EVDET_INTERVAL}")
            evDet = EvDet(self.host, self.eventDet, interval=EVDET_INTERVAL)

            self.log.info("Checking Palantir...")
            self.check_palantir(self.host)
            self.check_palantir(self.target)
            self.check_palantir(self.linux)

            self.log.info("Getting emissary...")
            em = self.host.getEmissary()

            self.log.info(f"Executing emissary whoami...")
            em_whoami = em.execcmd("whoami", shell=True)
            self.log.info(f"WHOAMI: {em_whoami}")

            self.log.info("Installing wingman...")
            wingman = WM.install_wingman(em)

            desktop = wingman.Desktop()

            # Open NotePad, write some text, and save file
            self._notepad_test(em, desktop, "If it is to be it is up to me to do.")

            self.log.info(f"Sleeping...")
            time.sleep(5)

            self.log.info("Stopping EvDet...")
            numEvents, max_interval, numFailures = evDet.stop(get_files=True)
            msg = f"Got {numEvents} events, {numFailures} failures. max_interval {max_interval:.4f}"
            self.log.info(msg)

            if numEvents == 0:
                self.log.error("No events detected")
                return self.FAILURE, "No events detected"

            if max_interval - EVDET_INTERVAL > INTERVAL_TOLERANCE:
                msg = f"Max interval was {max_interval:.4f}, expected {EVDET_INTERVAL} or less"
                self.log.error(msg)
                return self.FAILURE, msg

            return self.SUCCESS, msg
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def check_palantir(self, host):
        hostname = host.db_properties.get("name")
        self.log.info(f"-------- {hostname}")

        r_pal = host.mirrorfunc('import', 'palantir')
        remote_ver = r_pal.__version__
        local_ver = palantir.__version__

        if host.get_os_family() == 'windows':
            (domain, user_name) = getLoggedInUser(host)
            while user_name is None:
                self.log.warning("Host not ready, sleeping...")
                time.sleep(5)
                (domain, user_name) = getLoggedInUser(host)
            self.log.info(f"User: {domain}/{user_name}, Undermine: {undermine.__version__}, RemotePalantir: {remote_ver}, LocalPalantir: {local_ver}")
        else:
            r_getpass = host.mirrorfunc('import', 'getpass')
            user_name = r_getpass.getuser()
            self.log.info(f"User: {user_name}, Undermine: {undermine.__version__}, RemotePalantir: {remote_ver}, LocalPalantir: {local_ver}")

    def _notepad_test(self, em, desktop, test_str):
        """Open Notepad, write some text, save the file, and close Notepad."""
        self.log.info("---- Starting notepad.exe...")
        em.spawn('notepad.exe', shell=True)

        time.sleep(5)

        self.log.info("Finding Notepad window...")
        notepad_windows = desktop.listWindows('Notepad')
        if len(notepad_windows) == 0:
            return self.FAILURE, "Notepad window not found"
        notepad_win = notepad_windows[0]

        self.log.info("Sending text...")
        notepad_win.sendKeys(test_str)
        time.sleep(5)

        self.log.info("Opening the File menu")
        notepad_win.mouseClick(10, -15)
        time.sleep(5)

        self.log.info("Clicking on Save button")
        notepad_win.mouseClick(15,70)
        time.sleep(5)

        self.log.info("Finding SaveAs window")
        windows = desktop.listWindows('Save As')
        if len(windows) == 0:
            return self.FAILURE, "SaveAs window not found"
        save_win = windows[0]
        time.sleep(5)

        # Create random filename
        rand_int = random.randint(0,999)
        filename = f'TestFile{rand_int:03d}.txt'

        self.log.info(f"Entering filename: {filename}")
        save_win.sendKeys(filename)
        time.sleep(5)

        self.log.info(f"Saving {filename}")
        buttons = save_win.listControls('Save')
        if len(buttons) == 0:
            return self.FAILURE, "Save button not found"
        save_button = buttons[0]
        save_button.mouseClick()
        time.sleep(5)

        self.log.info("Closing all Notepad windows...")
        for win in notepad_windows:
            win.close()

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) != 4:
                self.log.error("Wrong number of resources specified, expecting 4")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            hostname = self.host.db_properties.get("name")
            self.log.info(f"HOST: {hostname}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error(f"No properties found on {hostname}")
                return False
            if not self.host.service_is_up():
                self.log.error(f"Agent not responding on {hostname}")
                return False

            self.target = self.resources[1]
            if not hasattr(self.target, "db_properties") or self.target.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            hostname = self.target.db_properties.get("name")
            self.log.info(f"TARGET: {hostname}")
            self.target.properties = self.target.db_properties.get("properties")
            if self.target.properties is None:
                self.log.error(f"No properties found on {hostname}")
                return False
            if not self.target.service_is_up():
                self.log.error(f"Agent not responding on {hostname}")
                return False

            self.linux = self.resources[2]
            if not hasattr(self.linux, "db_properties") or self.linux.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            hostname = self.linux.db_properties.get("name")
            self.log.info(f"LINUX: {hostname}")
            self.linux.properties = self.target.db_properties.get("properties")
            if self.linux.properties is None:
                self.log.error(f"No properties found on {hostname}")
                return False
            if not self.linux.service_is_up():
                self.log.error(f"Agent not responding on {hostname}")
                return False

            self.eventDet = self.resources[3]
            if not hasattr(self.eventDet, "db_properties") or self.eventDet.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            evdet_hostname = self.eventDet.db_properties.get("name")
            self.log.info(f"EVDET: {evdet_hostname}")
            if not self.eventDet.service_is_up():
                self.log.error(f"Agent not responding on {evdet_hostname}")
                return False
            return True
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
