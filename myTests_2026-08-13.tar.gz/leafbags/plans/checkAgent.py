from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
PARENT = "kvm-r2-u37.qqcyber.net"
SAMPLES = -1

testPlan = PLANSPEC(
    script = "tests.check_agent",
    hostslots = [
        HOST(),
        # HOST(parent=ParentCondition(name=PARENT)),
        # HOST(agent="gene"),
        # HOST(name=RegexCondition(".*_033")),
        # HOST(family='windows'),
        # HOST(os_name='ubuntu'),
    ],
    namespace = f"checkAgent_{TIMESTAMP}",
    planname = "checkAgent",
    samples = SAMPLES,
    replications = 1,
)
EXECUTE(testcase=testPlan)
