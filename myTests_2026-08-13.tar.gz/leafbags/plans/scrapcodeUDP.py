from tplanner.planlang import *

deb_host = HOST(os_name='debian', architecture='x64')
ubuntu_host = HOST(os_name='ubuntu', architecture='x64')

my_test = PLANSPEC(
    # Replace with your undermine test
    script = "tests.sleep",
    # script = "tests.scrapcode_UDP_test",

    # Define available host slots. Leave as shown.
    hostslots=[
        deb_host | ubuntu_host,
        HOST(family='linux', os_name=['debian'], os_version=['10'], architecture=['x64']),
    ],
    # Name your test
    namespace ='scrapcode_UDP',
    # Assign a name to your plan
    planname = 'scrapCodeDemo',
    # Set the no. of samples to test. -1 to test all available samples.
    # Number of samples to test. -1 means all available
    samples = 3,
    # Specify how many times each sample set should be repeated.
    replications = 2,
)
EXECUTE(testcase=my_test)
