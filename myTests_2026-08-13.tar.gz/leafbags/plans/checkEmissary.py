from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SAMPLES = 2

testPlan = PLANSPEC(
    script = "tests.check_em",
    hostslots = [
        # HOST(),
        HOST(family='windows'),
    ],
    paramslots=[
        ['username=user'], ['password=dartadmin']
    ],
    namespace = f"checkEmissary_{TIMESTAMP}",
    planname = "checkEmissary",
    samples = SAMPLES,
    replications = 1,
)
EXECUTE(testcase=testPlan)
