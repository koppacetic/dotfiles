from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "checkVMlist"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SCRIPT = "tests.check_vm"
LIST_FILE = "vmlist.txt"

try:
    # Create vmlist from vmlist.txt
    vmlist = list()
    with open(LIST_FILE, "r", encoding="utf-8") as file:
        for line in file:
            # Skip blank lines and comments
            vmname = line.strip()
            if vmname == "" or vmname[0] == "#":
                continue

            # Strip off '.qcow2' if there
            vmname = vmname.replace(".qcow2", "")
            vmlist.append(vmname)

    # Run the test against all the VMs
    test_plan = PLANSPEC(
        script = f"{SCRIPT}",
        hostslots = [
            HOST(name=vmlist),
        ],
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        planname = NAMESPACE,
        samples = -1,
        replications = 1
    )
    EXECUTE(testcase=test_plan)
except Exception as ex:
    print(f"{ex}")
