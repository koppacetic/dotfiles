from tplanner.planlang import *

testPlan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(name=RegexCondition(".*_033")),
    ],
    namespace = "solveTest-$t",
    planname = "solveTest",
    p_notes = "Specify host name by regex",
    samples = -1,
    replications = 1
)
EXECUTE(testcase=testPlan)
