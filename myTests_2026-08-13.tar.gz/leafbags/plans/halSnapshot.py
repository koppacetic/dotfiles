from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SAMPLES = 1
KVMS = ["kvm-r2-u30.qqcyber.net", "kvm-r2-u34.qqcyber.net", "kvm-r2-u37.qqcyber.net", "kvm-r2-u38.qqcyber.net"]
# KVMS = ["kvm-r2-u37.qqcyber.net", "kvm-r2-u38.qqcyber.net"]
OSNAMES = ["alma", "centos", "debian", "fedora", "freebsd", "ubuntu", "windows_10", "windows_2008", "windows_2012",
           "windows_2016", "windows_2019", "windows_2022", "windows_7", "windows_8.1", "windows_8-"]

for regex in OSNAMES:
    for kvm in KVMS:
        short_name = kvm.replace(".qqcyber.net", "")
        short_name = short_name.replace("-r", "")
        short_name = short_name.replace("-u", "")
        testPlan = PLANSPEC(
            script = "tests.hal_snapshot1",
            hostslots = [HOST(name=RegexCondition(regex), parent=ParentCondition(name=kvm))],
            namespace = f"halSnapshot_{TIMESTAMP}",
            planname = f"halSnapshot-{short_name}-{regex}",
            samples = SAMPLES,
            replications = 1
        )
        EXECUTE(testcase=testPlan)
