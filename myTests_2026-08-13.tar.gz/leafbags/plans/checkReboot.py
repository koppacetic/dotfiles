from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "checkReboot"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SCRIPT = "tests.hal_reboot"
SAMPLES = -1

testPlan = PLANSPEC(
    script = f"{SCRIPT}",
    hostslots = [
        HOST(),
        # HOST(name=RegexCondition("prerelease")),
    ],
    namespace = f"{NAMESPACE}_{TIMESTAMP}",
    planname = f"{NAMESPACE}",
    samples = SAMPLES,
    replications = 1,
)
EXECUTE(testcase=testPlan)
