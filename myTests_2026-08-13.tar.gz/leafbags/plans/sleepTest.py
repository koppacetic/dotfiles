from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
PARENT = "kvm-r2-u38.incy.tech"
SLEEPTIME = 5
SAMPLES = 5

testPlan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        # HOST(),
        HOST(family=["windows", "linux", "esxi"], agent=["pal3", "none"]),
        # HOST(os_name="photon"),
        # HOST(parent=ParentCondition(name=PARENT)),
        # HOST(family="windows", memory_mb="16184"),
        # HOST(family="windows", os_version="10"),
        # HOST(family="linux"),
        # HOST(agent="none"),
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"],
    ],
    namespace = f"sleepTest_{TIMESTAMP}",
    n_notes = "A simple sleep test",
    planname = f"sleepTest-{SLEEPTIME}s",
    p_notes = f"Sleep time: {SLEEPTIME} seconds",
    samples = SAMPLES,
    replications = 1
)

#breakpoint()
EXECUTE(testcase=testPlan)
