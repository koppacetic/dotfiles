from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

testPlan = PLANSPEC(
    script = "tests.check_agent",
    hostslots = [
        HOST(family="windows", os_version="7", edition="pro"),
    ],
    namespace = f"checkWin7Pro_{TIMESTAMP}",
    planname = "checkWin7Pro",
    samples = -1,
    replications = 1,
)
EXECUTE(testcase=testPlan)
