from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "checkKVM"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
KVM_FILE = "kvms.lst"
SAMPLES = 10

SCRIPT = "tests.check_palantir"
SLEEPTIME = 5

def execute_plan(kvmname):
    short_name = kvmname.replace(".qqcyber.net", "")
    short_name = short_name.replace(".incy.tech", "")
    short_name = short_name.replace("-r", "")
    short_name = short_name.replace("-u", "")

    test_plan = PLANSPEC(
        script = f"{SCRIPT}",
        paramslots = [
            [f"sleeptime={SLEEPTIME}"],
        ],
        hostslots = [
            HOST(parent=ParentCondition(name=kvmname), family=["windows", "linux"]),
            # HOST(parent=ParentCondition(name=kvm), os_name="debian"),
            # HOST(parent=ParentCondition(name=kvm), architecture="x86"),
            # HOST(parent=ParentCondition(name=kvm), family="windows", os_version="11"),
            # HOST(parent=ParentCondition(name=kvm), family="macos"),
        ],
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        planname = f"{NAMESPACE}-{short_name}",
        samples = SAMPLES,
        replications = 1
    )
    EXECUTE(testcase=test_plan)

try:
    with open(KVM_FILE, "r", encoding="utf-8") as file:
        for line in file:
            kvmname = line.strip()
            if kvmname[0] == '#':
                continue
            if len(kvmname) > 0:
                execute_plan(kvmname)
except Exception as ex:
    print(f"{ex}")
