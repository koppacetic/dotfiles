from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "checkBad"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SCRIPT = "tests.check_vm"
BADVM_FILE = "bad.txt"

try:
    with open(BADVM_FILE, "r", encoding="utf-8") as file:
        for line in file:
            # Skip blank lines and comments
            vmname = line.strip()
            if vmname == "" or vmname[0] == "#":
                continue

            # Strip off '.qcow2' if there
            vmname = vmname.replace(".qcow2", "")

            test_plan = PLANSPEC(
                script = f"{SCRIPT}",
                hostslots = [
                    HOST(name=vmname, agent=["pal3", "none"]),
                ],
                namespace = f"{NAMESPACE}_{TIMESTAMP}",
                planname = vmname,
                samples = 1,
                replications = 1
            )
            EXECUTE(testcase=test_plan)
except Exception as ex:
    print(f"{ex}")
