from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SCRIPT = "tests.sleep"
#SCRIPT = "tests.check_vm",
SLEEPTIME = 5 * 60
SAMPLES = -1

testPlan = PLANSPEC(
    script = SCRIPT,
    hostslots = [
        HOST(name=RegexCondition("_mccree-physical")),
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"],
    ],
    namespace = f"checkPhysical_{TIMESTAMP}",
    planname = "checkPhysical",
    samples = SAMPLES,
    replications = 1,
)
EXECUTE(testcase=testPlan)
