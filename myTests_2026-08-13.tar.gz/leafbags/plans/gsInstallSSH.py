from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

test_plan = PLANSPEC(
    script = "tests.gs_install_ssh",
    hostslots = [
        HOST(agent="gene"),
    ],
    namespace = f"gsInstallSSH_{TIMESTAMP}",
    planname = f"gsInstallSSH",
    verbose = True,
    samples = 1,
    replications = 1
)
EXECUTE(testcase=test_plan)
