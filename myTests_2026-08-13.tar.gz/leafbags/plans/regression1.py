from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "regression1"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
DEFAULT_SAMPLES = 3

HOSTSLOTS = [HOST(family="macos")]
USB_HOST = "kvm-r2-u37.incy.tech"

# Plan table
#  An array of dicts containing test parameters.
#
#  name: (required) PLANSPEC planname
#  script: (required) PLANSPEC script
#  hostslots: PLANSPEC hostslots. Can be a string or a list. Default: all
#             Valid string values:
#               all: HOST()
#               windows, linux, bsd: HOST(family=<stringvalue>)
#  paramslots: PLANSPEC paramslots. Default: []
#  samples: PLANSPEC samples. Default: DEFAULT_SAMPLES
PLANS = [
            # Basic tests
            {"name": "sleepTest", "script": "sleep", "hostslots": HOSTSLOTS},
            {"name": "checkAgent", "script": "check_agent", "hostslots": HOSTSLOTS},
            {"name": "fileOps", "script": "file_ops", "hostslots": HOSTSLOTS},

            # HAL tests
            {"name": "halReboot", "script": "hal_reboot", "hostslots": HOSTSLOTS},
            {"name": "halScreenshot", "script": "hal_screenshot", "hostslots": HOSTSLOTS},
            {"name": "halSnapshot1", "script": "hal_snapshot1", "hostslots": HOSTSLOTS},

            # Emissary tests
            # {"name": "emWindows", "script": "em_windows", "hostslots": "windows", "paramslots": [
            #     [f'username=emuser'], ['password=emPassword123'], [f'method=gui'], ['createAcct=@True']
            # ]},
            # {"name": "emLinux", "script": "em_linux", "hostslots": "linux", "paramslots": [
            #     [f'username=user'], ['password=dartadmin']
            # ]},

            # EventDetection tests
            # {"name": "evdetBasic", "script": "evdet_basic", "hostslots": [
            #     HOST(family="windows", os_version="10"),
            #     HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")])
            # ]},
            # {"name": "evdetWindows", "script": "evdet_windows", "hostslots": [
            #     HOST(family="windows", os_version="10"),
            #     HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")])
            # ]},
            # {"name": "evdetExtend", "script": "evdet_extend", "hostslots": [
            #     HOST(family="windows", os_version="10"),
            #     HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")])
            # ]},
            # {"name": "evdetStop", "script": "evdet_stop", "hostslots": [
            #     HOST(family="windows", os_version="10"),
            #     HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")])
            # ]},

            # USB tests
            # {"name": "usbAttach", "script": "usb_attach", "hostslots": [
            #     HOST(family="windows", os_version="10", parent=ParentCondition(name=USB_HOST)),
            #     RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST)),
            # ]},
            # {"name": "usbWindows", "script": "usb_windows", "hostslots": [
            #     HOST(family="windows", os_version="10", parent=ParentCondition(name=USB_HOST)),
            #     RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST)),
            # ]},
            # {"name": "usbLinux", "script": "usb_linux", "hostslots": [
            #     HOST(family="linux", os_name="debian", parent=ParentCondition(name=USB_HOST)),
            #     RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST)),
            # ]},
        ]

def execute_plan(plan_info):
    plan_name = plan_info.get("name")
    script = plan_info.get("script")
    hostslots = plan_info.get("hostslots", "all")
    paramslots = plan_info.get("paramslots", [])
    samples = plan_info.get("samples", DEFAULT_SAMPLES)

    if hostslots == "all":
        planname = f"{plan_name}-{hostslots}"
        hosts = [HOST()]
    elif hostslots in ["windows", "linux", "bsd", "macos"]:
        planname = f"{plan_name}-{hostslots}"
        hosts = [HOST(family=hostslots)]
    elif isinstance(hostslots, list):
        planname = plan_name
        hosts = hostslots
    else:
        print(f"Invalid hostslots for {plan_name}")
        return

    test_plan = PLANSPEC(
        script = f"tests.{script}",
        hostslots = hosts,
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        planname = planname,
        paramslots = paramslots,
        samples = samples,
        replications = 1
    )
    EXECUTE(testcase=test_plan)

def run():
    for plan_dict in PLANS:
        execute_plan(plan_dict)

run()
