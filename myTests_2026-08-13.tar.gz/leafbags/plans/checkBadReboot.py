from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "checkBadReboot"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SCRIPT = "tests.hal_reboot"
BADVM_FILE = "badReboot.txt"

def execute_plan(vmname):
    # Plan name based on vmname
    parts = vmname.split("_")
    planname = "_".join(parts[0:7])

    test_plan = PLANSPEC(
        script = f"{SCRIPT}",
        hostslots = [
            HOST(name=vmname),
        ],
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        planname = planname,
        samples = 1,
        replications = 1
    )
    EXECUTE(testcase=test_plan)

try:
    with open(BADVM_FILE, "r", encoding="utf-8") as file:
        for line in file:
            vmname = line.strip()
            execute_plan(vmname)
except Exception as ex:
    print(f"{ex}")
