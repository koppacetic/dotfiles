from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SAMPLES = 10

testPlan = PLANSPEC(
    script = "tests.evdet_ocr",
    namespace = f"evdetOCR_{TIMESTAMP}",
    planname = "evdetOCR",
    p_notes = 'EventDetection Windows OCR test',
    hostslots = [
        HOST(family="windows", os_version="10"),
        HOST(apps=[AppCondition("evdet")])
    ],
    # verbose = True,
    samples = SAMPLES
)
EXECUTE(testcase=testPlan)
