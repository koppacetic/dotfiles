from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SAMPLES = -1

testPlan = PLANSPEC(
    script = "tests.check_vm",
    hostslots = [
        HOST(name=RegexCondition("prerelease"), agent=["pal3", "none"]),
    ],
    namespace = f"checkPrerelease_{TIMESTAMP}",
    planname = "checkPrerelease",
    samples = SAMPLES,
    replications = 1,
)
EXECUTE(testcase=testPlan)
