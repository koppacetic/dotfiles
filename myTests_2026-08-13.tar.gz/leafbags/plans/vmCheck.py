from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
VMS = [
    "windows_11-21H2_pro-for-workstation_x64_en-US_pal3_033",
    "windows_11-21H2_home_x64_en-US_pal3_033",
    "windows_11-21H2_home-n_x64_en-US_pal3_033",
    "windows_11-21H2_pro-education_x64_en-US_pal3_033",
    "windows_11-22H2_pro_x64_en-US_pal3_033",
    "windows_11-21H2_education-n_x64_en-US_pal3_033",
    "windows_11-21H2_pro_x64_en-US_pal3_033",
    "windows_11-21H2_pro-n-for-workstation_x64_en-US_pal3_033",
    "windows_11-21H2_education_x64_en-US_pal3_033",
    "windows_11-21H2_pro-n_x64_en-US_pal3_033",
]

for vm in VMS:
    testPlan = PLANSPEC(
        script = "tests.check_agent",
        hostslots = [
            HOST(name=vm),
        ],
        namespace = f"vmCheck_{TIMESTAMP}",
        planname = f"vmCheck",
        samples = -1,
        replications = 1
    )
    EXECUTE(testcase=testPlan)
