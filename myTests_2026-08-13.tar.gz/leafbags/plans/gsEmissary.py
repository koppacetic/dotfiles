from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

test_plan = PLANSPEC(
    script = "tests.gs_emissary",
    hostslots = [
        HOST(agent="gene"),
    ],
    namespace = f"gsEmissary_{TIMESTAMP}",
    planname = f"gsEmissary",
    verbose = True,
    samples = 1,
    replications = 1
)
EXECUTE(testcase=test_plan)
