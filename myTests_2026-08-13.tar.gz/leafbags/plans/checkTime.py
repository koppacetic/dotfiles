from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "checkTime"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SCRIPT = "tests.time_check"
SAMPLES = -1

testPlan = PLANSPEC(
    script = SCRIPT,
    hostslots = [
        # HOST(),
        # HOST(name=RegexCondition("prerelease")),
        HOST(name=RegexCondition("\\d{5}$")),
    ],
    namespace = f"{NAMESPACE}_{TIMESTAMP}",
    planname = f"{NAMESPACE}",
    samples = SAMPLES,
    replications = 1,
)
EXECUTE(testcase=testPlan)
