from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SAMPLES = 100

testPlan = PLANSPEC(
    script = "tests.check_vm",
    hostslots = [
        HOST(family=["windows", "linux", "esxi"], agent=["pal3", "none"]),
        # HOST(agent=["pal3", "none"]),
        # HOST(agent="none"),
        # HOST(family="esxi", agent="none"),
        # HOST(name=RegexCondition("_26098")),
    ],
    namespace = f"checkVM_{TIMESTAMP}",
    planname = "checkVM",
    samples = SAMPLES,
    replications = 1,
)
EXECUTE(testcase=testPlan)
