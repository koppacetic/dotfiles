from tplanner.planlang import *

testPlan = PLANSPEC(
    namespace = "evdetWindows-$t",
    planname = "evdetWindows",
    p_notes = 'EventDetection Windows test',
    script = "tests.evdet_windows2",
    hostslots = [
        HOST(family="windows") - HOST(os_name="8"),
        HOST(name=RegexCondition("prerelease"), apps=[AppCondition("evdet")]),
        # HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")]),
    ],
    samples = 1
)
EXECUTE(testcase=testPlan)
