from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "halReboot"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SCRIPT = "tests.hal_reboot"
SAMPLES = 10

FAMILY = "linux"
LINUX = ["alma", "alpine", "centos", "debian", "fedora", "opensuse", "rocky", "ubuntu"]
for os_name in LINUX:
    host = HOST(family=FAMILY, os_name=os_name, agent=["pal3", "none"])
    testplan = PLANSPEC(
        script = SCRIPT,
        hostslots = [host],
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        planname = f"{NAMESPACE}-{FAMILY}-{os_name}",
        p_notes = f"Family: {FAMILY}, os_name: {os_name}",
        samples = SAMPLES,
        replications = 1
    )
    EXECUTE(testcase=testplan)

FAMILY = "bsd"
BSD = ["freebsd"]
for os_name in BSD:
    host = HOST(family=FAMILY, os_name=os_name, agent=["pal3", "none"])
    testplan = PLANSPEC(
        script = SCRIPT,
        hostslots = [host],
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        planname = f"{NAMESPACE}-{FAMILY}-{os_name}",
        p_notes = f"Family: {FAMILY}, os_name: {os_name}",
        samples = SAMPLES,
        replications = 1
    )
    EXECUTE(testcase=testplan)

FAMILY = "windows"
WINDOWS = ["10", "11", "2008r2", "2012", "2012r2", "2016", "2019", "2022", "7", "8", "8.1"]
# WINDOWS = ["2008r2", "2016", "2019", "2022"]
# WINDOWS = ["11"]
for os_name in WINDOWS:
    host = HOST(family=FAMILY, os_name=os_name, agent=["pal3", "none"])
    testplan = PLANSPEC(
        script = SCRIPT,
        hostslots = [host],
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        planname = f"{NAMESPACE}-{FAMILY}-{os_name}",
        p_notes = f"Family: {FAMILY}, os_name: {os_name}",
        samples = SAMPLES,
        replications = 1
    )
    EXECUTE(testcase=testplan)

# FAMILY = "macos"
# host = HOST(family=FAMILY, agent=["pal3", "none"])
# testplan = PLANSPEC(
#     script = SCRIPT,
#     hostslots = [host],
#     namespace = f"{NAMESPACE}_{TIMESTAMP}",
#     planname = f"{NAMESPACE}-{FAMILY}",
#     p_notes = f"Family: {FAMILY}",
#     samples = -1,
#     replications = 1
# )
# EXECUTE(testcase=testplan)
