from tplanner.planlang import *

myTest = PLANSPEC(
    script = "tests.check_palantir",
    hostslots = [HOST(os_name="ubuntu", os_version="20", os_minorversion="04")],
    paramslots = [],
    namespace = "ubuntu2004-$t",
    planname = "ubuntu2004",
    samples = -1,
    replications = 1
)
EXECUTE(testcase=myTest)
