from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

test_plan = PLANSPEC(
    script = "tests.check_agent",
    hostslots = [
        HOST(agent="gene"),
    ],
    namespace = f"gsCheck_{TIMESTAMP}",
    planname = f"gsCheck",
    samples = -1,
    replications = 1
)
EXECUTE(testcase=test_plan)
