from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

testPlan = PLANSPEC(
    script = "tests.evdet_multi",
    namespace = f"evdetMulti_{TIMESTAMP}",
    planname = "evdetMulti",
    p_notes = 'Multiple EventDetection test',
    hostslots = [
        HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")]),
        HOST(family="windows", os_version="11"),
        HOST(family="windows", os_version="10"),
        HOST(family="windows", os_version="8"),
        HOST(family="windows", os_version="7"),
        HOST(family="windows", os_version="10"),
        # HOST(family="windows", os_version="11"),
        # HOST(family="windows", os_version="11"),
        # HOST(family="windows", os_version="11"),
        # HOST(family="windows", os_version="11"),
        # HOST(family="windows", os_version="11"),
    ],
    samples = 1
)
EXECUTE(testcase=testPlan)
