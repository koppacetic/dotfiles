from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "multiPlanSleep"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SLEEPTIME = 5
SAMPLES = 1
NUM_PLANS = 100

for ii in range(NUM_PLANS):
    testPlan = PLANSPEC(
        script = "tests.sleep",
        hostslots = [
            HOST(),
        ],
        paramslots = [
            [f"sleeptime={SLEEPTIME}"],
        ],
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        n_notes = "A multi-plan sleep test",
        planname = f"{NAMESPACE}-{SLEEPTIME}s",
        p_notes = f"Sleep time: {SLEEPTIME} seconds",
        samples = SAMPLES,
        replications = 1
    )
    EXECUTE(testcase=testPlan)
