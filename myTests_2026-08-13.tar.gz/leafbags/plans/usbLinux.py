from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
USB_HOST = "kvm-r2-u37.incy.tech"
SAMPLES = 3
# USB_REGEX = "^usb_GEMBIRD_PhotoFrame"
# USB_REGEX = "^usb_Alcor-Micro-Corp"

testPlan = PLANSPEC(
    script = 'tests.usb_linux',
    hostslots = [
        HOST(family="linux", parent=ParentCondition(name=USB_HOST), cloneable=True),
        # HOST(os_name="centos", parent=ParentCondition(name=USB_HOST)),
        # RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST), name=RegexCondition(USB_REGEX))
        RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST))
    ],
    namespace = f"usbLinux_{TIMESTAMP}",
    planname = "usbLinux",
    samples = SAMPLES,
    replications = 1,
)

EXECUTE(testcase=testPlan)
