from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SAMPLES = 25

test_plan = PLANSPEC(
    script = "tests.multiuser",
    hostslots = [
        # Typical onsite run
        HOST(family="windows", os_version=["10", "11"], language="en-us", architecture="x64"),
        HOST(family="windows", os_version="7", architecture="x64"),
        HOST(family="linux", os_name="debian", os_version="11", os_minorversion="6", architecture="x64"),
        HOST(apps=[AppCondition("evdet")]),
    ],
    namespace = f"multiUser_{TIMESTAMP}",
    planname = f"multiUser",
    samples = SAMPLES,
    replications = 1
)
EXECUTE(testcase=test_plan)
