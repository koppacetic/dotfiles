from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

test_plan = PLANSPEC(
    script = "tests.file_ops",
    hostslots = [
        HOST(),
    ],
    namespace = f"fileOps_{TIMESTAMP}",
    planname = f"fileOps",
    verbose = True,
    samples = 10,
    replications = 1
)
EXECUTE(testcase=test_plan)
