from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
PARENT = "kvm-r2-u37.incy.tech"
SAMPLES = 50

testPlan = PLANSPEC(
    script = "tests.check_palantir",
    hostslots = [
        # HOST(),
        HOST(family=["windows", "linux"], parent=ParentCondition(name=PARENT)),
        # hostslots = [HOST(language='ko-kr')],
        # HOST(name=RegexCondition(r"windows_.*_pal3_\d{5}")),
        # HOST(os_name='ubuntu'),
        # hostslots = [HOST(os_name='2012r2', edition='datacenter-desktop')],
        # hostslots = [HOST(family='linux')],
        # HOST(family='windows'),
        # hostslots = [HOST(family='windows', os_version='10', build='21H2', edition='pro')],
        # hostslots = [HOST(family='windows', os_version='7', edition='professional', architecture='x64')],
        # HOST(family='windows'),
    ],
    namespace = f"checkPalantir_{TIMESTAMP}",
    planname = "checkPalantir",
    samples = SAMPLES,
    replications = 1,
)
EXECUTE(testcase=testPlan)
