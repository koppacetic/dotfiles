from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "regression"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
DEFAULT_SAMPLES = 5
USB_HOST = "kvm-r2-u37.incy.tech"

# Plan table
#  An array of dicts containing test parameters.
#
#  name: (required) PLANSPEC planname
#  script: (required) PLANSPEC script
#  hostslots: PLANSPEC hostslots. Can be a string or a list. Default: all
#             Valid string values:
#               all: HOST()
#               none: HOST(agent="none")
#               windows, linux, macos, bsd, esxi: HOST(family=<stringvalue>)
#  paramslots: PLANSPEC paramslots. Default: []
#  samples: PLANSPEC samples. Default: DEFAULT_SAMPLES
PLANS = [
        # Basic tests
        {"name": "sleepTest", "script": "sleep", "hostslots": "windows", "samples": 1},
        {"name": "sleepTest", "script": "sleep", "hostslots": "linux", "samples": 1},
        # {"name": "sleepTest", "script": "sleep", "hostslots": "macos", "samples": 1},
        {"name": "sleepTest", "script": "sleep", "hostslots": "bsd", "samples": 1},
        # {"name": "sleepTest", "script": "sleep", "hostslots": "esxi", "samples": 1},
        {"name": "sleepTest", "script": "sleep", "hostslots": "none", "samples": 1},

        {"name": "checkVM", "script": "check_vm", "hostslots": "windows"},
        {"name": "checkVM", "script": "check_vm", "hostslots": "linux"},
        # {"name": "checkVM", "script": "check_vm", "hostslots": "macos", "samples": -1},
        {"name": "checkVM", "script": "check_vm", "hostslots": "bsd", "samples": -1},
        # {"name": "checkVM", "script": "check_vm", "hostslots": "esxi", "samples": -1},
        {"name": "checkVM", "script": "check_vm", "hostslots": "none"},

        {"name": "fileOps", "script": "file_ops", "hostslots": "windows"},
        {"name": "fileOps", "script": "file_ops", "hostslots": "linux"},
        # {"name": "fileOps", "script": "file_ops", "hostslots": "macos", "samples": -1},
        {"name": "fileOps", "script": "file_ops", "hostslots": "bsd", "samples": -1},

        # HAL tests
        {"name": "halReboot", "script": "hal_reboot", "hostslots": "windows"},
        {"name": "halReboot", "script": "hal_reboot", "hostslots": "linux"},
        # {"name": "halReboot", "script": "hal_reboot", "hostslots": "macos"},
        {"name": "halReboot", "script": "hal_reboot", "hostslots": "bsd"},
        {"name": "halReboot", "script": "hal_reboot", "hostslots": "none"},

        {"name": "halScreenshot", "script": "hal_screenshot", "hostslots": "windows"},
        {"name": "halScreenshot", "script": "hal_screenshot", "hostslots": "linux"},
        # {"name": "halScreenshot", "script": "hal_screenshot", "hostslots": "macos"},
        {"name": "halScreenshot", "script": "hal_screenshot", "hostslots": "bsd"},

        {"name": "halSnapshot1", "script": "hal_snapshot1", "hostslots": "windows"},
        {"name": "halSnapshot1", "script": "hal_snapshot1", "hostslots": "linux"},
        # {"name": "halSnapshot1", "script": "hal_snapshot1", "hostslots": "macos"},
        {"name": "halSnapshot1", "script": "hal_snapshot1", "hostslots": "bsd"},
        {"name": "halSnapshot1", "script": "hal_snapshot1", "hostslots": "none"},

        # Emissary tests
        {"name": "emWindows", "script": "em_windows", "hostslots": "windows", "paramslots": [
            [f'username=user'], ['password=dartadmin']
        ]},
        {"name": "emCreateUser", "script": "em_windows", "hostslots": "windows", "paramslots": [
            [f'username=emuser'], ['password=emPassword123'], [f'method=gui'], ['createAcct=@True']
        ]},
        {"name": "emLinux", "script": "em_linux", "hostslots": "linux", "paramslots": [
            [f'username=user'], ['password=dartadmin']
        ]},
        {"name": "emBsd", "script": "em_linux", "hostslots": "bsd", "samples": -1, "paramslots": [
            [f'username=user'], ['password=dartadmin']
        ]},

        # EventDetection tests
        {"name": "evdetBasic", "script": "evdet_basic", "hostslots": [
            HOST(family="windows", os_version="10"),
            HOST(apps=[AppCondition("evdet")])
        ]},
        {"name": "evdetWindows", "script": "evdet_windows", "hostslots": [
            HOST(family="windows", os_version="10"),
            HOST(apps=[AppCondition("evdet")])
        ]},
        {"name": "evdetExtend", "script": "evdet_extend", "hostslots": [
            HOST(family="windows", os_version="10"),
            HOST(apps=[AppCondition("evdet")])
        ]},
        {"name": "evdetStop", "script": "evdet_stop", "hostslots": [
            HOST(family="windows", os_version="10"),
            HOST(apps=[AppCondition("evdet")])
        ]},
        {"name": "evdetOCR", "script": "evdet_ocr", "hostslots": [
            HOST(family="windows", os_version="10"),
            HOST(apps=[AppCondition("evdet")])
        ]},

        # Typical onsite test
        {"name": "onsite", "script": "multiuser", "hostslots": [
            HOST(family="windows", os_version=["10", "11"], language="en-us", architecture="x64"),
            HOST(family="windows", os_version="7", architecture="x64"),
            HOST(family="linux", os_name="debian", os_version="11", os_minorversion="6", architecture="x64"),
            HOST(apps=[AppCondition("evdet")]),
        ]},

        # USB tests
        {"name": "usbWindows", "script": "usb_windows", "samples": 3, "hostslots": [
            HOST(family="windows", os_version="10", parent=ParentCondition(name=USB_HOST)),
            RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST), cloneable=True),
        ]},
        {"name": "usbLinux", "script": "usb_linux", "samples": 3, "hostslots": [
            HOST(family="linux", parent=ParentCondition(name=USB_HOST), cloneable=True),
            RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST)),
        ]},
    ]

def execute_plan(plan_info):
    plan_name = plan_info.get("name")
    script = plan_info.get("script")
    hostslots = plan_info.get("hostslots", "all")
    paramslots = plan_info.get("paramslots", [])
    samples = plan_info.get("samples", DEFAULT_SAMPLES)

    if hostslots == "all":
        planname = f"{plan_name}-{hostslots}"
        hosts = [HOST()]
    elif hostslots in ["windows", "linux", "macos", "bsd", "esxi"]:
        planname = f"{plan_name}-{hostslots}"
        if hostslots == "esxi":
            hosts = [HOST(family=hostslots, agent="none")]
        else:
            hosts = [HOST(family=hostslots)]
    elif hostslots == "none":
        planname = f"{plan_name}-{hostslots}"
        hosts = [HOST(agent=hostslots)]
    elif isinstance(hostslots, list):
        planname = plan_name
        hosts = hostslots
    else:
        print(f"Invalid hostslots for {plan_name}")
        return

    test_plan = PLANSPEC(
        script = f"tests.{script}",
        hostslots = hosts,
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        planname = planname,
        paramslots = paramslots,
        samples = samples,
        replications = 1
    )
    EXECUTE(testcase=test_plan)

def run():
    for plan_dict in PLANS:
        execute_plan(plan_dict)

run()
