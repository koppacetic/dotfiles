from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

testplan = PLANSPEC(
    script = "tests.hal_addCD",
    hostslots = [
        HOST(family="linux"),
    ],
    namespace = f"halAddCD_{TIMESTAMP}",
    planname = "halAddCD",
    samples = 1
)
EXECUTE(testcase=testplan)
