from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y%m%d-%H%M%S")
SAMPLES = -1

testplan = PLANSPEC(
    script = "tests.hal_reboot",
    # hostslots = [HOST()],
    hostslots = [
        HOST(agent="none"),
        # HOST(name=RegexCondition(r"windows_.*_pal3_\d{5}")),
        # HOST(family='windows', os_version='10', build='21H1', architecture='x64')
    ],
    namespace = f"halReboot1_{TIMESTAMP}",
    planname = "halReboot1",
    samples = SAMPLES
)
EXECUTE(testcase=testplan)
