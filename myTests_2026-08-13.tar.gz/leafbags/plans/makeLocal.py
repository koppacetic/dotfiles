from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

testplan = PLANSPEC(
    script = "tests.make_local",
    hostslots = [
        # Primary
        HOST(family='linux', os_name="ubuntu", os_version="20"),

        # Secondary
        HOST(family='linux', os_name="alma", os_version="9"),
    ],
    namespace = f"makeLocal_{TIMESTAMP}",
    planname = f"makeLocal",
    n_notes = "Download a VM within another VM",
    samples = 1
)
EXECUTE(testcase=testplan)
