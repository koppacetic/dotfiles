#!/bin/bash
# Description:
#   Show active plans, claims, and reservations.
#
dart_cli show plans -a
dart_cli show claims -l
dart_cli show reservations --recent mccree
