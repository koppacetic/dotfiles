# Multiuser Shell Script
A script for concurrently running the same testplan as different users.

## Basic Usage
```
multiuser.sh <dart_user> [testplan]
```

- dart_user is your DART username (ie. mccree, bowser, pikachu, tron, feyre, avantusmario)
- testplan is optional and is the testplan you want to run. If non is specified, skipSleep is used.

You run the script from your test repo. The accounts it uses are incy-tester, tester2, tester3, and the dart_user you specify on the command line.

It will prompt you for your dart_user password when you run the script.

### Examples
I typically run it like this:
```
multiuser.sh mccree
```

Which runs my skipSleep testplan.

To run one of your own testplans, you'd do something like this:
```
multiuser.sh bowser mytest
```

## Recommendations
- At first, just use a basic 10 second sleep test to see how the system behaves.
- My testplan just uses HOST() and samples = 100.

## Watching Progress
After running the multiuser.sh script I typically use the following command to monitor it's progress.
```
watch 'dart_cli show plans -A -l4; dart_cli show claims --load mccree incy-tester tester2 tester3'
```

In the above command, you'd have to change 'mccree' to your dart_user name.

It will display something like this and update the counters every 2 seconds:
```
Every 2.0s: dart_cli show plans -A -l4; dart_cli show claims --load mccree incy-tester tester2 tester3        skipdev1.incy.tech: Mon Aug 21 14:14:20 2023

┏━━━━━━┯━━━━━━━━━━━━━━━━━━━━━┯━━━━━━━━━━━━━┯━━━━━━━━━━━━━┯━━━┯━━━┯━━━┯━━━┯━━━┯━━━┯━━━┯━━━┯━━━━━┯━━━━━━━━━━━━━┯━━━━━━━━━━┓
┃ Plan │ Start               │ User        │ Name        │ S │ F │ A │ S │ E │ P │ R │ S │   P │ Script      │ Run Time ┃
┠──────┼─────────────────────┼─────────────┼─────────────┼───┼───┼───┼───┼───┼───┼───┼───┼─────┼─────────────┼──────────┨
┃ 1019 │ 2023-08-21 14:12:34 │ mccree      │ skipSleep_1 │ 0 │ 0 │ 0 │ 0 │ 0 │ 0 │ 0 │ 0 │ 100 │ tests.sleep │  0:00:00 ┃
┃ 1018 │ 2023-08-21 14:12:22 │ tester3     │ skipSleep_1 │ 0 │ 0 │ 0 │ 0 │ 0 │ 0 │ 0 │ 0 │ 100 │ tests.sleep │  0:00:00 ┃
┃ 1017 │ 2023-08-21 14:12:17 │ tester2     │ skipSleep_1 │ 0 │ 0 │ 0 │ 0 │ 0 │ 0 │ 0 │ 1 │  99 │ tests.sleep │  0:00:00 ┃
┃ 1016 │ 2023-08-21 14:12:12 │ incy-tester │ skipSleep_1 │ 0 │ 0 │ 0 │ 0 │ 0 │ 0 │ 3 │ 6 │  91 │ tests.sleep │  0:00:00 ┃
┗━━━━━━┷━━━━━━━━━━━━━━━━━━━━━┷━━━━━━━━━━━━━┷━━━━━━━━━━━━━┷━━━┷━━━┷━━━┷━━━┷━━━┷━━━┷━━━┷━━━┷━━━━━┷━━━━━━━━━━━━━┷━━━━━━━━━━┛
                                   Claims Per Server
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┯━━━━━━━━┯━━━━━━━━┯━━━━━┯━━━━━━━┯━━━━━━━┯━━━━━━━┯━━━━━━━━┓
┃                            │        │        │     │       │   CPU │   CPU │        ┃
┃ Server                     │ Owner  │ Active │ Max │ Score │ Usage │  Load │ Memory ┃
┠────────────────────────────┼────────┼────────┼─────┼───────┼───────┼───────┼────────┨
┃ kvm-r2-u29.int.qqcyber.net │ System │      8 │  50 │ 12.59 │ 18.04 │ 10.10 │  29.67 ┃
┃ kvm-r2-u30.int.qqcyber.net │ System │      3 │  50 │ 11.15 │ 21.25 │ 10.20 │  33.59 ┃
┃ kvm-r2-u34.int.qqcyber.net │ System │      8 │  50 │ 11.73 │ 17.16 │  9.61 │  23.72 ┃
┃ kvm-r2-u37.int.qqcyber.net │ System │      0 │  50 │ 11.41 │ 32.73 │ 20.95 │   6.70 ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┷━━━━━━━━┷━━━━━━━━┷━━━━━┷━━━━━━━┷━━━━━━━┷━━━━━━━┷━━━━━━━━┛
         Total Claims
┏━━━━━━━━━━━━━┯━━━━━━━━┯━━━━━┓
┃ Owner       │ Active │ Max ┃
┠─────────────┼────────┼─────┨
┃ System      │     19 │ 200 ┃
┃ mccree      │      0 │  88 ┃
┃ incy-tester │     17 │  88 ┃
┃ tester2     │      2 │  88 ┃
┃ tester3     │      0 │  88 ┃
┗━━━━━━━━━━━━━┷━━━━━━━━┷━━━━━┛
```
