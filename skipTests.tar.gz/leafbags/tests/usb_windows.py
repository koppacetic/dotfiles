import time

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

SLEEP_TIME = 5

@leafi.MainLeaf()
class UnitTest(leaf.Leaf):
    """Windows-only USB test"""

    def run(self):
        self.log.info("######## run ########")
        try:
            # Initialize HAL
            self.log.info(f"Initializing HAL on {self.hostname}...")
            HAL(self.host)

            # List files in home directory
            self.log.info("List home dir...")
            r_os = self.host.mirrorfunc('import', 'os')
            files = r_os.listdir(".")
            self.log.info(f"HOME:\n{files}")

            # Attach to USB to the VM
            self.log.info(f"Attaching {self.usbname} to {self.hostname}...")
            success, msg = self.host.HAL.attach_device_to_vm(self.usb.db_properties)
            if not success:
                return self.FAILURE, f"Attach failed: {msg}"

            time.sleep(SLEEP_TIME)

            # The USB drive gets automatically mounted on D:/, format it
            self.log.info(f"Formatting {self.usbname}...")
            if self.host.properties.get("agent") == "gene":
                retcode, out, err = self.host.execcmd("format D: /v:MyDrive /fs:exFAT /q", shell=True)
                if retcode != 0:
                    self.log.info(f"retcode: {retcode}, {out}, {err}")
                    return self.FAILURE, "Format failed"
            else:
                retcode, out = self.host.execcmd("format D: /v:MyDrive /fs:exFAT /q", shell=True, returncode=self.host.execute.RETURN)
                if retcode != 0:
                    self.log.info(f"retcode: {retcode}, {out}")
                    return self.FAILURE, "Format failed"

            # Copy some files onto flash drive
            self.log.info("Copy some files onto flash drive...")
            if self.host.properties.get("agent") == "gene":
                retcode, out, err = self.host.execcmd("copy *.* D:", shell=True)
                if retcode != 0:
                    self.log.info(f"retcode: {retcode}, {out}, {err}")
                    return self.FAILURE, "Copy failed"
            else:
                retcode, out = self.host.execcmd("copy *.* D:", shell=True, returncode=self.host.execute.RETURN)
                if retcode != 0:
                    self.log.info(f"retcode: {retcode}, {out}")
                    return self.FAILURE, "Copy failed"

            # List files on flash drive
            self.log.info("List flash drive...")
            files = r_os.listdir("D:/")
            self.log.info(f"D Drive:\n{files}")

            # Detach the USB from the VM
            self.log.info(f"Detaching {self.usbname} from {self.hostname}...")
            success, msg = self.host.HAL.detach_device_from_vm(self.usb.db_properties)
            if not success:
                return self.FAILURE, f"Detach failed: {msg}"

            return self.SUCCESS, 'Completed Successfully.'
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) != 1:
                self.log.error("Wrong number of resources specified, expecting 1")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.hostname = self.host.db_properties.get("name")
            self.log.info(f"HOST: {self.hostname}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False
            if not self.host.service_is_up():
                self.log.error(f"Agent not responding on {self.hostname}")
                return False

            if len(self.usbs) != 1:
                self.log.error("Wrong number of USB resources specified, expecting 1")
                return False
            self.usb = self.usbs[0]
            if not hasattr(self.usb, "db_properties") or self.usb.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.usb.properties = self.usb.db_properties.get("properties")
            if self.usb.properties is None:
                self.log.error("No USB properties found")
                return False
            self.usbname = self.usb.db_properties.get("name")
            bus = self.usb.properties.get("bus")
            device = self.usb.properties.get("device")
            if bus is None or device is None:
                self.log.error(f"Invalid USB: No bus or device")
                return False
            self.log.info(f"USB: {bus}, {device}, {self.usbname}")
            return True
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        try:
            self.log.info(f"Detaching {self.usbname} from {self.hostname}...")
            success, msg = self.host.HAL.detach_device_from_vm(self.usb.db_properties)
            # if not success:
            #     self.log.error(f"Detach failed: {msg}")
        except Exception as ex:
            self.log.error(f"runCleanup error: {type(ex).__name__}: {ex}")
