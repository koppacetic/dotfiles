import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

@leafi.MainLeaf()
class SleepTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        # raise RuntimeError("Fake error")
        try:
            raise RuntimeError("Fake error")
        except Exception as ex:
            self.log.exception(ex, stack_info=True)
            # self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) < 1:
                self.log.error("Wrong number of resources specified, expecting at least 1")
                return False

            self.host = self.resources[0]
            if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
                self.hostname = self.host.db_properties.get("name", "VM")
                self.log.info(f"HOST: {self.hostname}")
            return True
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
