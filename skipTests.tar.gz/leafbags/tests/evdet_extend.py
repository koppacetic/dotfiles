import time

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from event_detection.evdet_util import EvDet

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            evDet = EvDet(self.host, self.eventDet, interval=2.7)
            self.log.info(f"Started EvDet, timeout at {evDet.timeout_time}")

            self.log.info("Extending EvDet by 10 minutes")
            evDet.extend_timeout(10 * 60)

            self.log.info(f"New EvDet timeout at {evDet.timeout_time}")

            time.sleep(10)

            self.log.info("Stopping EvDet")
            numEvents, interval, numFailures = evDet.stop(get_files=True)
            msg = f"Got {numEvents} events, {numFailures} failures, interval {interval}"
            self.log.info(msg)
            return self.SUCCESS, msg
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) != 2:
                self.log.error("Wrong number of resources specified, expecting 2")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            hostname = self.host.db_properties.get("name")
            self.log.info(f"HOST: {hostname}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False
            if not self.host.service_is_up():
                self.log.error(f"Agent not responding on {hostname}")
                return False

            self.eventDet = self.resources[1]
            if not hasattr(self.eventDet, "db_properties") or self.eventDet.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            evdet_hostname = self.eventDet.db_properties.get("name")
            self.log.info(f"EVDET: {evdet_hostname}")
            if not self.eventDet.service_is_up():
                self.log.error(f"Agent not responding on {evdet_hostname}")
                return False
            return True
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
