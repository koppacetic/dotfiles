import os

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

@leafi.MainLeaf()
class MyTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        self.log.info(f"Creating subdirs...")
        for ii in range(1,4):
            subdir = os.path.join(self.output_dir, f"subdir{ii}")
            os.mkdir(subdir)
            path = os.path.join(subdir, "file.txt")
            os.close(os.open(path, os.O_CREAT))
            if ii == 1:
                subsubdir = os.path.join(subdir, "subsubdir")
                os.mkdir(subsubdir)
                path = os.path.join(subsubdir, "file.txt")
                os.close(os.open(path, os.O_CREAT))
        return self.SUCCESS, "Success"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
