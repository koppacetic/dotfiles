import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

TEST_FQDN = "google.com"
TEST_FQDN_BAD = "blahblahblah"
TEST_SERVICE = "https"
TEST_PORT = 443

@leafi.MainLeaf()
class MyTest(leaf.Leaf):
    """Test networking API"""

    def run(self):
        self.log.info("######## run ########")

        try:
            self.log.info(f"Executing nslookup({TEST_FQDN})...")
            ip_list = self.host.nslookup(TEST_FQDN)
            self.log.info(f"nslookup() returned {ip_list}")
            if ip_list is None or len(ip_list) == 0:
                self.log.error(f"nslookup({TEST_FQDN}) failed")
                return self.FAILURE, f"nslookup({TEST_FQDN}) failed"

            self.log.info(f"Executing nslookup({TEST_FQDN_BAD})...")
            rv = self.host.nslookup(TEST_FQDN_BAD)
            self.log.info(f"nslookup() returned {rv}")
            if rv is None or len(rv) == 0:
                self.log.error(f"nslookup({TEST_FQDN_BAD}) failed")
                return self.FAILURE, f"nslookup({TEST_FQDN_BAD}) failed"

            # self.log.info(f"Executing getaddrinfo({TEST_FQDN}, {TEST_SERVICE})...")
            # rv = self.host.getaddrinfo(TEST_FQDN, TEST_SERVICE)
            # self.log.info(f"getaddrinfo() returned {rv}")

            # self.log.info(f"Executing getnameinfo({ip_list}, {TEST_SERVICE})...")
            # rv = self.host.getaddrinfo(TEST_FQDN, TEST_SERVICE)
            # self.log.info(f"getaddrinfo() returned {rv}")

            return self.SUCCESS, f"Test completed successfully"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) < 1:
                self.log.error("Wrong number of resources specified, expecting at least 1")
                return False
            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.log.info(f"HOST: {self.host.db_properties.get('name')}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False
            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
