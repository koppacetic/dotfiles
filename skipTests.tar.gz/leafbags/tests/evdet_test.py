import time

import palantir.client
import underlib.wingman as WM
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from event_detection.evdet_util import EvDet
from palantir.support.netcom import NetcomError


MAX_REBOOTS = 1

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) != 2:
            self.log.error("Wrong number of resources specified, expecting 2")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.hostname = self.host.db_properties.get("name", "VM")
            self.log.info(f"HOST: {self.hostname}")

        if not self.host.service_is_up():
            self.log.error("Host Palantir not responding")
            return False

        self.eventDet = self.resources[1]
        assert isinstance(self.eventDet, undermine.undermine.client.Client)
        assert isinstance(self.eventDet, palantir.client.Client)
        if hasattr(self.eventDet, "db_properties") and self.eventDet.db_properties is not None:
            evdet_hostname = self.eventDet.db_properties.get("name", "VM")
            self.log.info(f"EVDET: {evdet_hostname}")

        if not self.eventDet.service_is_up():
            self.log.error("EventDet Palantir not responding")
            return False

        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True

    def wingman_it(self, host, range):
        #import pdb; pdb.set_trace()

        # initialize emissary and wingman
        em = host.getEmissary()
        wingman = WM.install_wingman(em)
        desktop = wingman.Desktop()

        self.log.info("Starting notepad...")
        em.spawn('notepad.exe', shell=True)
        time.sleep(2)

        self.log.info("That's enough.  Just return")
        return

        self.log.info("enter text into the notepad")
        win = None
        while win is None:
            windows = desktop.listWindows('Notepad')
            if len(windows) > 0:
                win = windows[0]
                test_string = 'I am a longer string making sure that all of the text gets entered properly'
                win.sendKeys(test_string)
            time.sleep(15)

        self.log.info(" open the file menu")
        win.mouseClick(10, -15)
        time.sleep(1)

        self.log.info(" click on the save button")
        win.mouseClick(15,70)
        time.sleep(1)

        self.log.info(" get the Save Window")
        save_win = None
        while save_win is None:
            windows = desktop.listWindows('Save As')
            if len(windows) > 0:
                save_win = windows[0]
            time.sleep(1)

        self.log.info(" enter file name")
        save_win.sendKeys('TestFile{}.txt'.format(range))
        time.sleep(5)

        self.log.info(" save the file")
        save_win.listControls('Save')[0].mouseClick()
        time.sleep(5)

        self.log.info(" close the notepad window")
        win.close()


    def run(self):
        self.log.info("######## run ########")
        self.startTime = time.time()
        evDet = EvDet(self.host, self.eventDet, interval=2.7)

        if self.host.ostype() == 'posix':
            self.log.info("let's reboot a few times to get more screenshots to evaluate")
        else:
            self.log.info("Let's fire up a bunch of Notepad instances")
        numEvents = interval = numFailures = 0
        totalEvents  = totalFailures = 0
        for ii in range(MAX_REBOOTS):
            if self.host.ostype() == 'posix':
                self.log.info(f"Rebooting ({ii})...")
                self.host.execcmd("/sbin/shutdown -r now", shell=True, wait=False)
                time.sleep(20)
                while self.host.service_is_down():
                    self.log.info("Palantir is still down, sleeping...")
                    time.sleep(5)

                self.log.info("Rebooted.")
                numEvents, interval, numFailures = evDet.stop(get_files=True)
                totalEvents += numEvents
                totalFailures += numFailures
                self.log.info(f"Got {numEvents} events, {numFailures} failures. interval {interval}")
                if numEvents == 0:
                    self.log.error("No events")
                    return self.FAILURE, "No events"
                time.sleep(10)
                evDet.start()
            else:
                self.wingman_it(self.host, ii)

        self.endTime = time.time()
        timeDiff = self.endTime - self.startTime

        if interval > 3.0:
            self.log.error("Interval was {}, expected 2.0, time = {}".format(interval, timeDiff))
            return self.FAILURE, "Interval was {}, expected 2.0, time = {}".format(interval, timeDiff)
        if numFailures > 0:
            self.log.error("{} failures, time = {}".format(numFailures, timeDiff))
            return self.FAILURE, "{} failures, time = {}".format(numFailures, timeDiff)

        msg = f"Got {totalEvents} events, {totalFailures} failures, interval {interval}"
        return self.SUCCESS, msg
