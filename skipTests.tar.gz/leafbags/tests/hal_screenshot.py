import time

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

MAX_TRIES = 60

@leafi.MainLeaf()
@leafi.DefineProcessor()
class HalScreenshot(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            # Initialize HAL
            HAL(self.host, bypass_version_check=True)

            self.log.info("Getting emissary...")
            em = self.host.getEmissary()

            self.log.info(f"Executing emissary notepad...")
            if self.host.properties.get("agent") == "gene":
                retval = em.execcmd("notepad.exe", shell=True, wait=False)
            else:
                retval = em.execcmd("notepad.exe", shell=True, wait=False, detach=True)
            self.log.info(f"{retval}")

            self.log.info(f"Sleeping...")
            time.sleep(10)

            (success, msg) = self.host.HAL.screenshot_vm(self.output_dir)
            if not success:
                self.log.error(f"Screenshot error: {msg}")
                return self.FAILURE, msg

            return self.SUCCESS, "Screenshot succeeded"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) != 1:
                self.log.error("Wrong number of resources specified, expecting 1")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            hostname = self.host.db_properties.get("name")
            self.log.info(f"HOST: {hostname}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False
            if not self.host.service_is_up():
                self.log.error(f"Agent not responding on {hostname}")
                return False
            return True
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
