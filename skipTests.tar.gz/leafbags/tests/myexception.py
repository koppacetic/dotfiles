import time

import palantir
import palantir.client
import undermine
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi


class MyException(Exception):
    pass

@leafi.MainLeaf()
@leafi.DefineProcessor()
class MyTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            raise MyException("I'm exceptional!")
        except Exception as ex:
            return self.ERROR, f"Exception: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) == 0:
            self.log.error("No resources specified")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.hostname = self.host.db_properties.get("name", "VM")
            self.log.info(f"HOST: {self.hostname}")

        if not self.host.service_is_up():
            self.log.error("Palantir not responding")
            return False
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
