import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

TEST_DIR = "myTestDir"
TEST_FILE = "myTestFile.txt"
TEST_FILE2 = "myTestFile2.txt"

@leafi.MainLeaf()
class MyTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")

        try:
            self.log.info(f"FAMILY: {self.host.get_os_family()}")
            self.log.info(f"SEP: {self.host.sep()}")

            # Create a test directory in root
            test_dir = self.host.sep() + TEST_DIR
            self.log.info(f"Creating {test_dir}...")
            rv = self.host.mkdir(test_dir)
            self.log.info(f"mkdir() returned {rv}")
            rv = self.host.path_exists(test_dir)
            self.log.info(f"path_exists() returned {rv}")
            if bool(rv) != True:
                self.log.error(f"Error: {test_dir} doesn't exist")
                return self.FAILURE, f"{test_dir} not created"

            # Create a test file
            file_path = test_dir + self.host.sep() + TEST_FILE
            self.log.info(f"Creating empty {file_path}...")
            rv = self.host.fwrite(file_path, fdata=b"")
            self.log.info(f"fwrite() returned {rv}")
            rv = self.host.path_exists(file_path)
            self.log.info(f"path_exists() returned {rv}")
            if bool(rv) != True:
                self.log.error(f"Error: {file_path} doesn't exist")
                return self.FAILURE, f"{file_path} not created"

            # Get hash of empty file
            hash1 = self.host.fhash(file_path)
            self.log.info(f"fhash() returned {hash1}")

            # Write something to file
            self.log.info(f"Appending to {file_path}...")
            rv = self.host.fappend(file_path, b"This is some test data.")
            self.log.info(f"fappend() returned {rv}")

            # Compare hashes
            hash2 = self.host.fhash(file_path)
            self.log.info(f"fhash() returned {hash2}")
            if hash1 == hash2:
                self.log.error(f"Error: {file_path} hash didn't change")
                return self.FAILURE, f"{file_path} hash didn't change"

            # Rename test file
            if self.host.properties.get("agent") == "gene":
                self.log.info(f"Renaming {TEST_FILE} to {TEST_FILE2}...")
                file_path2 = test_dir + self.host.sep() + TEST_FILE2
                rv = self.host.rename(file_path, file_path2)
                self.log.info(f"rename() returned {rv}")
                rv = self.host.path_exists(file_path2)
                self.log.info(f"path_exists() returned {rv}")
                if bool(rv) != True:
                    self.log.error(f"Error: {file_path2} doesn't exist")
                    return self.FAILURE, f"{file_path2} not created"
                rv = self.host.path_exists(file_path)
                self.log.info(f"path_exists() returned {rv}")
                if bool(rv) == True:
                    self.log.error(f"Error: {file_path} exists after rename")
                    return self.FAILURE, f"{file_path} exists after rename"

                # Compare hashes
                hash3 = self.host.fhash(file_path2)
                self.log.info(f"fhash() returned {hash3}")
                if hash2 != hash3:
                    self.log.error(f"Error: {file_path} hash changed after rename")
                    return self.FAILURE, f"{file_path} hash changed after rename"

            # Remove the test file
            if self.host.properties.get("agent") == "gene":
                file_to_remove = file_path2
            else:
                file_to_remove = file_path
            self.log.info(f"Removing {file_to_remove}...")
            rv = self.host.rmfile(file_to_remove)
            self.log.info(f"rmfile() returned {rv}")
            rv = self.host.path_exists(file_to_remove)
            self.log.info(f"path_exists() returned {rv}")
            if bool(rv) == True:
                self.log.error(f"Error: {file_to_remove} not deleted")
                return self.FAILURE, f"{file_to_remove} not deleted"

            # Remove the test directory
            self.log.info(f"Removing {test_dir}...")
            rv = self.host.rmtree(test_dir)
            self.log.info(f"rmtree() returned {rv}")
            rv = self.host.path_exists(test_dir)
            self.log.info(f"path_exists() returned {rv}")
            if bool(rv) == True:
                self.log.error(f"Error: {test_dir} not deleted")
                return self.FAILURE, f"{test_dir} not deleted"

            return self.SUCCESS, f"Test complete"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            # Check number of resources passed to test script
            if len(self.resources) < 1:
                self.log.error("Wrong number of resources specified, expecting at least 1")
                return False

            # Make sure resources were specified using rid://
            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.log.info(f"HOST: {self.host.db_properties.get('name')}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False

            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
