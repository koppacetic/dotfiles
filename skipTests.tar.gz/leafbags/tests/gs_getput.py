import os
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from gs_client import __version__ as gs_version

TEST_DIR = "/test"
TEST_FILE = "lorem.txt"

@leafi.MainLeaf()
class MyTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")

        try:
            self.log.info(f"CLIENT VERSION: {gs_version}")
            self.log.info(f"AGENT VERSION: {self.host.version()}")

            self.log.info(f"Creating {TEST_DIR} directory...")
            rv = self.host.mkdir(TEST_DIR, make_all=True)
            self.log.info(f"mkdir() returned {rv}")

            lpath = f"media/{TEST_FILE}"
            rpath = f"{TEST_DIR}/{TEST_FILE}"
            self.log.info(f"Putting {lpath} to {rpath}...")
            if not os.path.exists(lpath):
                return self.FAILURE, f"Local file not found: {lpath}"
            rv = self.host.put(lpath, rpath)
            self.log.info(f"put() returned {rv}")

            self.log.info(f"Reading {rpath}...")
            contents = self.host.fread(rpath)
            self.log.info(contents)

            self.log.info(f"Getting {rpath}...")
            getpath = os.path.join(self.output_dir, TEST_FILE)
            rv = self.host.get(rpath, getpath)
            self.log.info(f"get() returned {rv}")
            if not os.path.exists(getpath):
                return self.FAILURE, "Get failed"

            self.log.info(f"Removing {TEST_DIR} directory...")
            rv = self.host.rmtree(TEST_DIR)
            self.log.info(f"rmtree() returned {rv}")

            return self.SUCCESS, f"Genestealer test complete"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) < 1:
                self.log.error("Wrong number of resources specified, expecting at least 1")
                return False
            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.log.info(f"HOST: {self.host.db_properties.get('name')}")
            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
