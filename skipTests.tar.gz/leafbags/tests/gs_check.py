import gs_client
import undermine
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from undermine.underlib.system.win_utils import getLoggedInUser


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        remote_ver = self.host.version()
        local_ver = gs_client.__version__

        self.log.info("Getting logged in user...")
        (retcode, user_name, stderr) = self.host.execcmd("whoami", shell=True)
        if retcode != 0:
            self.log.error(f"Error: retcode={retcode}\n{stderr}")
        user_name = user_name.strip()
        self.log.info(f"SUCCESS - User: {user_name}, Undermine: {undermine.__version__}, RemoteGS: {remote_ver}, LocalGS: {local_ver}")
        return self.SUCCESS, f"User: {user_name}, Undermine: {undermine.__version__}, RemoteGS: {remote_ver}, LocalGS: {local_ver}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) == 0:
                self.log.error("No resources specified")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties found, use rid:// to specify resources")
                return False

            self.hostname = self.host.db_properties.get("name", "VM")
            self.log.info(f"HOST: {self.hostname}")
            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
