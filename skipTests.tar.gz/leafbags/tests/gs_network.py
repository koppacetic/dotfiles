import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from gs_client import __version__ as gs_version

TEST_FQDN = "google.com"
TEST_SERVICE = "https"
TEST_FQDN_BAD = "blahblahblah"
TEST_SERVICE_BAD = "blah"
TEST_PORT = 443
TEST_PORT_BAD = 9999
TEST_IP_BAD = "999.999.999.999"

@leafi.MainLeaf()
class MyTest(leaf.Leaf):
    """Test Genestealer networking API"""

    def run(self):
        self.log.info("######## run ########")

        try:
            self.log.info(f"CLIENT VERSION: {gs_version}")
            self.log.info(f"AGENT VERSION: {self.host.version()}")
            ipaddr = self.host.get_agent_ip()
            self.log.info(f"IP ADDRESS: {ipaddr}")
            port = self.host.get_port()
            self.log.info(f"PORT: {port}")

            self.log.info(f"====> nslookup({TEST_FQDN})...")
            ip_list = self.host.nslookup(TEST_FQDN)
            self.log.info(f"nslookup() returned {ip_list}")
            if ip_list is None or len(ip_list) == 0:
                self.log.error(f"nslookup({TEST_FQDN}) failed")
                return self.FAILURE, f"nslookup({TEST_FQDN}) failed"

            self.log.info(f"====> nslookup({TEST_FQDN_BAD})...")
            rv = self.host.nslookup(TEST_FQDN_BAD)
            self.log.info(f"nslookup() returned {rv}")
            if len(rv) != 0:
                self.log.error(f"nslookup({TEST_FQDN_BAD}) succeeded?!")
                return self.FAILURE, f"nslookup({TEST_FQDN_BAD}) succeeded?!"

            self.log.info(f"====> getaddrinfo({TEST_FQDN}, {TEST_SERVICE})...")
            rv = self.host.getaddrinfo(TEST_FQDN, TEST_SERVICE)
            self.log.info(f"getaddrinfo() returned {rv}")
            if rv is None or len(rv) == 0:
                self.log.error(f"getaddrinfo({TEST_FQDN}, {TEST_SERVICE}) failed")
                return self.FAILURE, f"getaddrinfo({TEST_FQDN}, {TEST_SERVICE}) failed"

            self.log.info(f"====> getaddrinfo({TEST_FQDN_BAD}, {TEST_SERVICE_BAD})...")
            rv = self.host.getaddrinfo(TEST_FQDN_BAD, TEST_SERVICE_BAD)
            self.log.info(f"getaddrinfo() returned {rv}")
            if len(rv) != 0:
                self.log.error(f"getaddrinfo({TEST_FQDN_BAD}, {TEST_SERVICE_BAD}) succeeded?!")
                return self.FAILURE, f"getaddrinfo({TEST_FQDN_BAD}, {TEST_SERVICE_BAD}) succeeded?!"

            self.log.info(f"====> getnameinfo({ip_list[0]}, {TEST_PORT})...")
            rv = self.host.getnameinfo(ip_list[0], TEST_PORT)
            self.log.info(f"getnameinfo() returned {rv}")
            if rv is None or len(rv) == 0:
                self.log.error(f"getnameinfo({ip_list[0]}, {TEST_PORT}) failed")
                return self.FAILURE, f"getnameinfo({ip_list[0]}, {TEST_PORT}) failed"

            # self.log.info(f"====> getnameinfo({TEST_IP_BAD}, {TEST_PORT_BAD})...")
            # rv = self.host.getnameinfo(TEST_IP_BAD, TEST_PORT_BAD)
            # self.log.info(f"getnameinfo() returned {rv}")
            # if len(rv) != 0:
            #     self.log.error(f"getnameinfo({TEST_IP_BAD}, {TEST_PORT_BAD}) succeeded?!")
            #     return self.FAILURE, f"getnameinfo({TEST_IP_BAD}, {TEST_PORT_BAD}) succeeded?!"

            self.log.info(f"====> ping({ip_list[0]})...")
            rv = self.host.ping(ip_list[0])
            self.log.info(f"ping() returned {rv}")
            if rv is None or len(rv) == 0:
                self.log.error(f"ping({ip_list[0]}) failed")
                return self.FAILURE, f"ping({ip_list[0]}) failed"

            self.log.info(f"====> ping({TEST_FQDN})...")
            rv = self.host.ping(TEST_FQDN)
            self.log.info(f"ping() returned {rv}")
            if rv is None or len(rv) == 0:
                self.log.error(f"ping({TEST_FQDN}) failed")
                return self.FAILURE, f"ping({TEST_FQDN}) failed"

            self.log.info(f"====> traceroute({ip_list[0]})...")
            rv = self.host.traceroute(ip_list[0])
            self.log.info(f"traceroute() returned {rv}")
            if rv is None or len(rv) == 0:
                self.log.error(f"traceroute({ip_list[0]}) failed")
                return self.FAILURE, f"traceroute({ip_list[0]}) failed"

            self.log.info(f"Executing whoami...")
            retcode, whoami, stderr = self.host.execcmd("whoami", shell=True)
            if retcode != 0:
                self.log.error(f"Error: retcode={retcode}\n{stderr}")
            self.log.info(f"WHOAMI: {whoami.strip()}")

            return self.SUCCESS, f"Test completed successfully"
        except Exception as ex:
            self.log.error(f"Exception {type(ex).__name__}: {ex}")
            return self.FAILURE, f"Exception {type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) < 1:
                self.log.error("Wrong number of resources specified, expecting at least 1")
                return False
            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.log.info(f"HOST: {self.host.db_properties.get('name')}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False
            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
