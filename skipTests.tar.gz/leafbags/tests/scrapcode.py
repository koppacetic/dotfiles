from time import localtime, sleep, strftime, time

import palantir
from event_detection.evdet_util import EvDet
from hal_client.hal_client import HAL
from scapy.all import IP, UDP, raw, rdpcap
from undermine.undermine import leaf
from undermine.undermine.meta import leafi
from utils import file_manipulation, process, transfer
from utils.scrapcode_utils import (config_scrapcode_file_dropper,
                                   config_scrapcode_udp_ping)

#from palantir.support.netcom import NetcomError


def remote_function():
    import os
    return os.environ.get("TEMP")

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def set_up_target_data(self):
        file_name = file_manipulation.get_uniq_tmp_name()
        file_path ='/tmp/scrapcode/{}{}'.format( self.config_host.sep(), file_name)
        self.config_host.fwrite(file_path, self.data_to_write_to_file, is_text=True)
        return file_path

    def get_target_temp_dir(self):
        if self.target_host.db_properties['properties']['family'] == 'linux':
            return '/tmp'
        tempDir = self.target_host.remotefunc(remote_function)
        self.log.info("tempDir is {}".format(tempDir))
        return tempDir

    def test_udp_ping(self):
        data_path = self.set_up_target_data()
        target_path_temp_dir = self.get_target_temp_dir()
        target_bin = config_scrapcode_udp_ping(self.config_host, self.target_host, data_path=data_path,
                                               target_ip=self.config_host.ip, port=self.udp_port,
                                               num_of_pings=self.num_of_pings)
        target_bin_filename = 'scrap_code'
        if self.target_host.db_properties['properties']['family'] == 'windows':
            target_bin_filename += '.exe'

        target_bin_filename += '.configured' # TODO take this out when the -o flag is respected

        remote_dest = target_path_temp_dir + self.target_host.sep() + target_bin_filename
        rv = transfer.transfer_file_between_hosts(self.config_host, target_bin, self.target_host, remote_dest)
        if rv is not True:
            self.log.error("Could not transfer {}:{} to {}:{}".format(self.config_host, target_bin,
                                                                      self.target_host, remote_dest))
            return self.FAILURE, "Could not transfer {}:{} to {}:{}".format(self.config_host, target_bin,
                                                                            self.target_host, remote_dest)

        if self.target_host.db_properties['properties']['family'] == 'linux':
            cmd = "chmod +x {}".format(remote_dest)
            self.target_host.execcmd(cmd, wait=True, shell=True)

        cmd = '/usr/sbin/tcpdump -nvv -w /tmp/output.pcap -U host {}'.format(self.target_host.ip)
        rv = self.config_host.execcmd(cmd, wait=False, shell=True)
        self.config_host.log.info('Fired off tcpdump: {}'.format(rv))
        self.log.info("sleeping for 5 secs to be sure tcpdump is up and running")
        sleep(5)

        self.log.info("About to fire {}".format(remote_dest))
        rv = self.target_host.execcmd(remote_dest, shell=True, wait=True)
        self.config_host.log.info('Fired off {}: {}'.format(remote_dest, rv))

        self.log.info("sleeping for 5 secs to be sure tcpdump writes out his data")
        sleep(5)
        rv = process.kill_process_by_name(self.config_host, 'tcpdump')
        self.log.info("process.kill_process_by_name(tcpdump) returned {}".format(rv))

        rv = self.config_host.get('/tmp/output.pcap', self.output_dir + '/output.pcap')
        self.log.info("rv=self.config_host.get('/tmp/output.pcap', '{}') returned {}".format(self.output_dir + '/output.pcap', rv))

        count = 0
        packets = rdpcap(self.output_dir + '/output.pcap')
        for pkt in packets:
            if not pkt.haslayer(IP):
                self.log.debug("not an IP packet!")
                continue

            self.log.debug('got an IP packet!')
            if pkt[IP].src != self.target_host.ip or pkt[IP].dst != self.config_host.ip:
                self.log.debug('\tNot my hosts: src:{} dst:{}'.format(pkt[IP].src, pkt[IP].dst))
                continue

            self.log.debug('\tand it is from target and meant for us')
            if not pkt[IP].haslayer(UDP):
                self.log.debug('\t\tNo UDP layer')
                continue

            self.log.debug('\t\tAnd it has UDP!!')
            if pkt[IP][UDP].dport != self.udp_port:
                self.log.debug('\t\t\tSoo close!! port is {}'.format(pkt[IP][UDP].dport))
                continue

            self.log.debug('\t\t\tAnd it matches our requested port!!')

            if raw(pkt[IP][UDP].payload).decode('utf-8') != self.data_to_write_to_file:
                self.log.info('\t\t\tAnd its data DOES NOT match what we requested!!')
                continue

            self.log.debug('\t\t\tAnd its data matches what we requested!!')
            count += 1

        if count != self.num_of_pings:
            return self.FAILURE, "Did not get {} UDP packets. got {}!".format(self.num_of_pings, count)
        return self.SUCCESS, "good to go"

    def test_file_dropper(self):
        data_path = self.set_up_target_data()
        target_path_temp_dir = self.get_target_temp_dir()
        target_path = target_path_temp_dir + self.target_host.sep() + 'FiletoLookFor'
        target_path = target_path.replace('\\','\\\\')
        target_bin = config_scrapcode_file_dropper(self.config_host, self.target_host, target_path=target_path,
                                                   data_path=data_path)
        target_bin_filename = 'scrap_code'
        if self.target_host.db_properties['properties']['family'] == 'windows':
            target_bin_filename += '.exe'

        target_bin_filename += '.configured'

        remote_dest = target_path_temp_dir + self.target_host.sep() + target_bin_filename
        remote_dest = remote_dest.replace('\\', '\\\\')

        rv = transfer.transfer_file_between_hosts(self.config_host, target_bin, self.target_host, remote_dest)
        if rv is not True:
            self.log.error("Could not transfer {}:{} to {}:{}".format(self.config_host, target_bin,
                                                                      self.target_host, remote_dest))
            return self.FAILURE, "Could not transfer {}:{} to {}:{}".format(self.config_host, target_bin,
                                                                            self.target_host, remote_dest)

        if self.target_host.db_properties['properties']['family'] == 'linux':
            cmd = "chmod +x {}".format(remote_dest)
            rv = self.target_host.execcmd(cmd, wait=True, shell=True)

        rv = self.target_host.execcmd(remote_dest, shell=True, wait=True)
        self.log.info("Launched {}:*{}*".format(remote_dest, rv))
        if self.target_host.path_exists(target_path) is not True:
            self.log.error("Could not find expected file!")
            return self.FAILURE, "Could not find expected file".format(target_path)

        # We know it's ASCII, so decode() it.
        file_contents = self.target_host.fread(target_path).decode()

        if file_contents != self.data_to_write_to_file:
            self.log.error("File contents {} do not match {}".format(file_contents, self.data_to_write_to_file))
            return self.FAILURE, "File contents {} do not match {}".format(file_contents, self.data_to_write_to_file)

        return self.SUCCESS, "ScrapCode Passes Muster!"

    def get_package_version(self, package):
        self.log.info(f'get {package} version \n')
        cmd = f'{self.python_path} -m pip show {package}'
        result = self.resource.execcmd(cmd, shell=True, convert_from='utf8')

        for line in result.split('\n'):
            if not line.startswith('Version'):
                continue
            version = line.split(':').pop(1).strip()
            return version

    def update_package(self, package):
        self.python_path = self.resource.mirrorfunc('import', 'sys').executable
        prev_version = self.get_package_version(package)
        self.log.info(f"Previous {package} Version: {prev_version}")

        pypi_host = "pypi.incy.tech"
        pypi_url = f"https://{pypi_host}/dev/simple"
        pip_cmd = f"pip install {package} -i {pypi_url} --trusted-host {pypi_host} --upgrade"

        install_cmd = f"{self.python_path} -m {pip_cmd}"
        self.log.info(f"EXEC CMD: {install_cmd}")

        begin_time = time()
        rv, output = self.resource.execcmd(install_cmd, shell=True, convert_from='utf8',
                                           returncode=self.resource.execute.RETURN)
        end_time = time()

        self.log.info(f'EXEC CMD output: {output}')

        begin_fmt = strftime('%H:%M:%S', localtime(begin_time))
        end_fmt = strftime('%H:%M:%S', localtime(end_time))
        elapsed = end_time - begin_time
        self.log.info(f"\n{self.name}\tTIME-Start-End-Elapsed:\t{begin_fmt}\t{end_fmt}\t{elapsed}\n")

        if rv != 0:
            raise Exception(f'update palantir user failed output: {output}')
        return elapsed

    def runSetup(self):
        self.log.info("######## runSetup ########")
        self.data_path=None
        self.data_to_write_to_file = u"Data to write to file"

        self.DoEvDet = self.kwargs.get('DoEvDet', False)
        if self.DoEvDet:
            if len(self.resources) != 3:
                self.log.error('Need 3 resources! A target, config_host, and EvDet')
                return False
        else:
            if len(self.resources) != 2:
                self.log.error('Need 2 resources! A target and a config_host')
                return False
        self.target_host = self.resources[0]
        self.config_host = self.resources[1]
        if self.DoEvDet:
            self.evdet_host = self.resources[2]

        self.log.info("Performing apt update...")
        cmd_str = "apt update -y -qq"
        rv = self.config_host.execcmd(cmd_str, wait=True, shell=True)
        self.log.info(rv)

        self.log.info("Installing python3...")
        cmd_str = "apt install -y -qq python3"
        rv = self.config_host.execcmd(cmd_str, wait=True, shell=True)
        self.log.info(rv)

        self.log.info("Uploading media contents...")
        if self.config_host.path_exists('/tmp/scrapcode'):
            self.config_host.rmtree('/tmp/scrapcode')
        self.config_host.mkdir('/tmp/scrapcode')
        transfer.upload_dir(self.config_host, 'media', '/tmp/scrapcode/scrapcode_media')
        if self.config_host.path_exists('/tmp/scrapcode/scrapcode_media') is not True:
            self.log.error('/tmp/scrapcode/scrapcode_media not tranferred!')
            return False
        self.log.info('scrapcode transferred to config_host')

        self.udp_port = int(self.kwargs.get('port', 53))
        self.num_of_pings = int(self.kwargs.get('num_of_pings', 4))
        self.log.info("Using {} for port and {} for num_of_pings".format(self.udp_port, self.num_of_pings))

        self.log.info("Installing tcpdump...")
        cmd = 'apt install -y -qq tcpdump'
        rv = self.config_host.execcmd(cmd, wait=True, shell=True)
        self.log.info(rv)
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        self.config_host.rmtree('/tmp/scrapcode')

    def run(self):
        self.log.info("######## run ########")
        if self.DoEvDet:
            self.log.info("Sleep to give VM time to settle down")
            sleep(30)
            self.ed = EvDet(self.target_host, self.evdet_host)

        returnCode = self.SUCCESS
        returnStr = "ScrapCode passes muster!"

        retVal1, retStr1 = self.test_file_dropper()
        if retVal1 != self.SUCCESS:
            returnCode = retVal1
            returnStr = retStr1

        if self.DoEvDet:
            eventCount, maxInterval, numFailures = self.ed.stop()
            if eventCount > 0:
                if returnCode != self.SUCCESS:
                    returnCode = self.FAILURE
                    returnStr = returnStr + ' {} Events Detected!'.format(eventCount)
                else:
                    returnCode = self.FAILURE
                    returnStr = '{} Events Detected!'.format(eventCount)

        self.log.info("Get a HAL object to power_cycle it!")
        HAL(self.target_host, bypass_version_check=True)
        self.log.info("Powering off to remove ScrapCode from target machine!")

        task = self.target_host.HAL.power_cycle()
        while not self.target_host.service_ping():
            self.log.info("Still waiting...")

        if self.DoEvDet:
            self.log.info("Sleep 30 secs to give VM time to settle down")
            sleep(30)
            self.ed.start()

        retVal2, retStr2 = self.test_udp_ping()
        if retVal2 != self.SUCCESS:
            if returnCode != self.SUCCESS:
                returnCode = retVal2
                returnStr = returnStr + ' ' + retStr2
            else:
                returnCode = retVal2
                returnStr = retStr2

        if self.DoEvDet:
            eventCount, maxInterval, numFailures = self.ed.stop()
            if eventCount > 0:
                if returnCode != self.SUCCESS:
                    returnCode = self.FAILURE
                    returnStr = returnStr + ' {} Events Detected!'.format(eventCount)
                else:
                    returnCode = self.FAILURE
                    returnStr = '{} Events Detected!'.format(eventCount)

        return returnCode, returnStr
