import time
from uuid import uuid4

import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

SLEEP_TIME = 5

@leafi.MainLeaf()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")

        self.log.info(f"Initializing HAL on {self.hostname}...")
        HAL(self.host)

        self.log.info(f"Attaching {self.usbname} to {self.hostname}...")
        success, msg = self.host.HAL.attach_device_to_vm(self.usb.db_properties)
        if not success:
            return self.FAILURE, f"Attach failed: {msg}"

        time.sleep(SLEEP_TIME)

        self.log.info("Running lsusb...")
        lsusb_out = self.host.execcmd('lsusb')
        self.log.info(lsusb_out)

        return self.SUCCESS, 'Completed Successfully.'

    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) != 1:
            self.log.error("Not enough resources specified, expected 1")
            return False
        if len(self.usbs) != 1:
            self.log.error("Not enough USBs specified, expected 1")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.hostname = self.host.db_properties.get("name", "VM")
            self.host_osname = self.host.db_properties.get("properties", {}).get("os_name")
            self.log.info(f"HOST: {self.hostname}")
            self.log.info(f"OSNAME: {self.host_osname}")

        self.usb = self.usbs[0]
        if hasattr(self.usb, "db_properties") and self.usb.db_properties is not None:
            self.usbname = self.usb.db_properties.get("name", "VM")
            bus = self.usb.db_properties.get("properties", {}).get("bus")
            device = self.usb.db_properties.get("properties", {}).get("device")
            if bus is None or device is None:
                self.log.error(f"Invalid USB: {self.usb.db_properties}")
                return False
            self.log.info(f"USB: {bus}, {device}, {self.usbname}")

        if not self.host.service_is_up():
            self.log.error("Palantir not responding")
            return False
        self.log.info("Palantir is running")

        # Install packages needed by test
        try:
            # Determine which package manager to use
            if self.host_osname in ["debian", "ubuntu"]:
                pacman = "apt"
            else:
                pacman = "dnf"

            # Install usbutils
            command = f"{pacman} -q -y install usbutils"
            self.log.info(f"EXECUTE: {command}...")
            rc, out = self.host.execcmd(command, shell=True, returncode=self.host.execute.RETURN)
            self.log.info(out)
            if rc != 0:
                return False
        except Exception as ex:
            self.log.error(f"{pacman} install error: {ex}")
            return False
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")

        # Detach USB device
        self.log.info(f"Detaching {self.usbname} from {self.hostname}...")
        success, msg = self.host.HAL.detach_device_from_vm(self.usb.db_properties)
        if not success:
            return self.FAILURE, f"Detach failed: {msg}"
        return True
