import os
import shutil
import time

import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from undermine.undermine.client import Client


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def runSetup(self):
        self.log.info("######## runSetup ########")
        return True

    def run(self):
        self.log.info("######## run ########")
        if len(self.resources) == 0:
            return self.FAILURE, "No resources"
        host = self.resources[0]
        assert isinstance(host, undermine.undermine.client.Client)
        assert isinstance(host, palantir.client.Client)
        hostname = host.db_properties.get("name", "VM")
        self.log.info(f"HOST: {hostname}")

        self.log.info("Creating test directory...")
        rv = host.mkdir('test')
        self.log.info(f"mkdir returned {rv}")

        self.log.info("Creating test.txt...")
        file_text = 'Random Data in a File!'
        rv = host.fappend('test/test.txt', file_text.encode())
        self.log.info(f"fappend returned {rv}")

        self.log.info("Retrieving test directory...")
        time.sleep(5)
        try:
            rv = host.rget('test')
            self.log.info(f"rget returned {rv}")
        except NetcomError as e:
            return self.FAILURE, 'rget failed: %s' % e

        file_size = os.stat("test/test.txt").st_size
        if (os.path.exists('test/test.txt') and file_size == len(file_text.encode())):
            return self.SUCCESS, f"rget returned {file_size} bytes"

        if not os.path.exists('test'):
            return self.FAILURE, "rget did not retrieve the directory. What did rget return?"

        if not os.path.exists('test/test.txt'):
            return self.FAILURE, "rget did not retrieve the file.  the directory is here, but not the file. What did rget return?"

        return self.FAILURE, f"rget returned {file_size} bytes, expected {len(file_text.encode())}"

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        host = self.resources[0]  # type: Client
        host.rmtree('test')
        shutil.rmtree('test')
