import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## runSetup ########")

        HAL(self.host)

        methods = []
        for method in dir(self.host.HAL):
            if not method.startswith("__") and callable(getattr(self.host.HAL, method)):
                methods.append(method)

        return self.SUCCESS, f"HAL methods: {methods}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) < 1:
            self.log.error("Wrong number of resources specified, expecting at least 1")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.host_db = self.host.db_properties
            self.hostname = self.host_db.get("name", "UNKNOWN")
            self.parent = self.host_db.get("parent", {}).get("name", "")
            self.log.info(f"HOST: {self.hostname}")
            self.log.info(f"HOST IP: {self.host.ip}")
            self.log.info(f"PARENT: {self.parent}")

        if not self.host.service_is_up():
            self.log.error("Host Palantir not responding")
            return False
        self.log.info(f"Palantir service is running")
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
