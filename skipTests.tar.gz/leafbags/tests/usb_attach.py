import time

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

SLEEPTIME = 10

@leafi.MainLeaf()
class UnitTest(leaf.Leaf):
    """Simple attach USB test"""

    def run(self):
        self.log.info("######## run ########")
        try:
            # Initialize HAL
            self.log.info(f"Initializing HAL on {self.hostname}...")
            HAL(self.host)

            # Attach to USB to the VM
            self.log.info(f"Attaching {self.usbname} to {self.hostname}...")
            success, msg = self.host.HAL.attach_device_to_vm(self.usb.db_properties)
            if not success:
                return self.FAILURE, f"Attach failed: {msg}"

            self.log.info(f"Sleeping for {SLEEPTIME} seconds...")
            time.sleep(SLEEPTIME)

            # Detach the USB from the VM
            self.log.info(f"Detaching {self.usbname} from {self.hostname}...")
            success, msg = self.host.HAL.detach_device_from_vm(self.usb.db_properties)
            if not success:
                return False

            return self.SUCCESS, f"Successfully attached/detached {self.usbname}"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) != 1:
                self.log.error("Wrong number of resources specified, expecting 1")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.hostname = self.host.db_properties.get("name")
            self.log.info(f"HOST: {self.hostname}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False
            if not self.host.service_is_up():
                self.log.error(f"Agent not responding on {self.hostname}")
                return False

            if len(self.usbs) != 1:
                self.log.error("Wrong number of USB resources specified, expecting 1")
                return False
            self.usb = self.usbs[0]
            if not hasattr(self.usb, "db_properties") or self.usb.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            self.usb.properties = self.usb.db_properties.get("properties")
            if self.usb.properties is None:
                self.log.error("No USB properties found")
                return False
            self.usbname = self.usb.db_properties.get("name")
            bus = self.usb.properties.get("bus")
            device = self.usb.properties.get("device")
            if bus is None or device is None:
                self.log.error(f"Invalid USB: No bus or device")
                return False
            self.log.info(f"USB: {bus}, {device}, {self.usbname}")
            return True
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
