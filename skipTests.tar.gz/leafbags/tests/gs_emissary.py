import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")

        try:
            self.log.info(f"Executing whoami...")
            (retcode, whoami, stderr) = self.host.execcmd("whoami", shell=True)
            if retcode != 0:
                self.log.error(f"Error: retcode={retcode}\n{stderr}")
            whoami = whoami.strip()
            self.log.info(f"WHOAMI: {whoami}")

            self.log.info("Getting emissary...")
            em = self.host.getEmissary()

            self.log.info(f"Executing emissary whoami...")
            (retcode, em_whoami, stderr) = em.execcmd("whoami", shell=True)
            if retcode != 0:
                self.log.error(f"Error: retcode={retcode}\n{stderr}")
            em_whoami = em_whoami.strip()
            self.log.info(f"WHOAMI: {em_whoami}")
            if whoami == em_whoami:
                return self.FAILURE, "Accounts are the same"

            return self.SUCCESS, "GS Emissary test complete"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) != 1:
                self.log.error("Wrong number of resources specified, expecting 1")
                return False

            self.host = self.resources[0]
            if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
                self.hostname = self.host.db_properties.get("name", "VM")
                self.log.info(f"HOST: {self.hostname}")
            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
