import time
from uuid import uuid4

import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

USB_SLEEP_TIME = 5

@leafi.MainLeaf()
class UnitTest(leaf.Leaf):
    """Android testing for Linux."""

    def run(self):
        self.log.info("######## run ########")

        # Initialize HAL
        self.log.info(f"Initializing HAL on {self.hostname}...")
        HAL(self.host)

        # Attach Android phone
        self.log.info(f"Attaching {self.usbname} to {self.hostname}...")
        success, msg = self.host.HAL.attach_device_to_vm(self.usb.db_properties)
        if not success:
            return self.FAILURE, f"Attach failed: {msg}"
        time.sleep(USB_SLEEP_TIME)      # Give host time to attach the device

        try:
            # List Google USB devices
            self.log.info("Running lsusb...")
            rc, out = self.host.execcmd("lsusb | grep -i google", shell=True,
                                        returncode=self.host.execute.RETURN)
            self.log.info(out)
            if rc != 0:
                return self.FAILURE, "Error running lsusb"

            if self.host_osname in ["debian", "ubuntu"]:
                # List Android devices
                self.log.info("Running adb...")
                rc, out = self.host.execcmd("adb devices -l", shell=True, returncode=self.host.execute.RETURN)
                self.log.info(out)
                if rc != 0:
                    return self.FAILURE, "Error running adb"
        except Exception as ex:
            self.log.error(f"Exception: {ex}")
            return self.FAILURE, str(ex)

        return self.SUCCESS, "Completed Successfully."

    def runSetup(self):
        self.log.info("######## runSetup ########")

        # Verify number of resources
        if len(self.resources) != 1:
            self.log.error("Not enough resources specified, expected 1")
            return False
        if len(self.usbs) != 1:
            self.log.error("Not enough USBs specified, expected 1")
            return False

        # Verify host resource
        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
            self.log.error("Test host must be specified using resource id (rid://)")
            return False
        self.hostname = self.host.db_properties.get("name", "VM")
        self.host_osname = self.host.db_properties.get("properties", {}).get("os_name")
        self.log.info(f"HOST: {self.hostname}")
        self.log.info(f"OSNAME: {self.host_osname}")

        # Verify USB resource
        self.usb = self.usbs[0]
        if not hasattr(self.usb, "db_properties") or self.usb.db_properties is None:
            self.log.error("USB must be specified using resource id (rid://)")
            return False
        self.usbname = self.usb.db_properties.get("name", "VM")
        bus = self.usb.db_properties.get("properties", {}).get("bus")
        device = self.usb.db_properties.get("properties", {}).get("device")
        if bus is None or device is None:
            self.log.error(f"Invalid USB: {self.usb.db_properties}")
            return False
        self.log.info(f"USB: {bus}, {device}, {self.usbname}")

        # Make sure Palantir is running
        if not self.host.service_is_up():
            self.log.error("Palantir not responding")
            return False
        self.log.info("Palantir is running")

        # Install packages needed by test
        try:
            # Determine which package manager to use
            if self.host_osname in ["debian", "ubuntu"]:
                pacman = "apt"
            else:
                pacman = "dnf"

            # Install usbutils
            self.log.info("Installing usbutils...")
            rc, out = self.host.execcmd(f"{pacman} -q -y install usbutils", shell=True,
                                        returncode=self.host.execute.RETURN)
            self.log.info(out)
            if rc != 0:
                return False

            # Only Debian and Ubuntu had Android SDK in their standard repos
            if self.host_osname in ["debian", "ubuntu"]:
                # Install android-tools-adb
                self.log.info("Installing android-tools-adb...")
                rc, out = self.host.execcmd(f"{pacman} -qq -y install android-tools-adb", shell=True,
                                            returncode=self.host.execute.RETURN)
                self.log.info(out)
                if rc != 0:
                    return False
        except Exception as ex:
            self.log.error(f"{pacman} install error: {ex}")
            return False
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")

        # Detach the Android phone
        self.log.info(f"Detaching {self.usbname} from {self.hostname}...")
        success, msg = self.host.HAL.detach_device_from_vm(self.usb.db_properties)
        if not success:
            return self.FAILURE, f"Detach failed: {msg}"
        return True
