import random
import time

import palantir.client
import undermine.underlib.wingman as WM
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from event_detection.evdet_util import EvDet

EVDET_INTERVAL = 2.0
INTERVAL_TOLERANCE = 0.25

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) != 2:
            self.log.error("Wrong number of resources specified, expecting 2")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.hostname = self.host.db_properties.get("name", "VM")
            self.log.info(f"HOST: {self.hostname}")
            properties = self.host.db_properties.get("properties", {})
            if properties.get("family", "") != "windows":
                self.log.error("Host is not running windows")
                return False

        if not self.host.service_is_up():
            self.log.error("Host Palantir not responding")
            return False
        self.log.info(f"Palantir running on {self.hostname}")

        self.eventDet = self.resources[1]
        assert isinstance(self.eventDet, undermine.undermine.client.Client)
        assert isinstance(self.eventDet, palantir.client.Client)
        if hasattr(self.eventDet, "db_properties") and self.eventDet.db_properties is not None:
            self.evdet_hostname = self.eventDet.db_properties.get("name", "VM")
            self.log.info(f"EVDET: {self.evdet_hostname}")

        if not self.eventDet.service_is_up():
            self.log.error("EventDet Palantir not responding")
            return False
        self.log.info(f"Palantir running on {self.evdet_hostname}")

        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True

    def run(self):
        self.log.info("######## run ########")
        self.log.info(f"Starting EventDetection, interval={EVDET_INTERVAL}")
        evDet = EvDet(self.host, self.eventDet, interval=EVDET_INTERVAL)

        self.log.info("Getting emissary...")
        em = self.host.getEmissary()

        self.log.info("Installing wingman...")
        wingman = WM.install_wingman(em)

        desktop = wingman.Desktop()

        # Open NotePad, write some text, and save file
        self._notepad_test(em, desktop, "Now is the time for all good men to come to the aid of their country.")
        time.sleep(5)

        self.log.info("Stopping EvDet...")
        numEvents, max_interval, numFailures = evDet.stop(get_files=True)
        msg = f"Got {numEvents} events, {numFailures} failures. max_interval {max_interval:.4f}"
        self.log.info(msg)

        if numEvents == 0:
            self.log.error("No events")
            return self.FAILURE, "No events"

        if max_interval - EVDET_INTERVAL > INTERVAL_TOLERANCE:
            msg = f"Max interval was {max_interval:.4f}, expected {EVDET_INTERVAL} or less"
            self.log.error(msg)
            return self.FAILURE, msg

        #### Do it all again
        time.sleep(5)
        self.log.info("Restarting EvDet...")
        evDet.start(interval=EVDET_INTERVAL)

        self._notepad_test(em, desktop, "Ask not what your country can do for you, ask what you can do for your country.")
        time.sleep(5)

        self.log.info("Stopping EvDet...")
        numEvents, max_interval, numFailures = evDet.stop(get_files=True)
        msg = f"Got {numEvents} events, {numFailures} failures. max_interval {max_interval:.4f}"
        self.log.info(msg)

        if numEvents == 0:
            self.log.error("No events")
            return self.FAILURE, "No events"

        if max_interval - EVDET_INTERVAL > INTERVAL_TOLERANCE:
            msg = f"Max interval was {max_interval:.4f}, expected {EVDET_INTERVAL} or less"
            self.log.error(msg)
            return self.FAILURE, msg

        return self.SUCCESS, msg

    def _notepad_test(self, em, desktop, test_str):
        """Open Notepad, write some text, save the file, and close Notepad."""
        self.log.info("---- Starting notepad.exe...")
        em.spawn('notepad.exe', shell=True)

        time.sleep(5)

        self.log.info("Finding Notepad window...")
        notepad_windows = desktop.listWindows('Notepad')
        if len(notepad_windows) == 0:
            return self.FAILURE, "Notepad window not found"
        notepad_win = notepad_windows[0]

        self.log.info("Sending text...")
        notepad_win.sendKeys(test_str)
        time.sleep(5)

        self.log.info("Opening the File menu")
        notepad_win.mouseClick(10, -15)
        time.sleep(5)

        self.log.info("Clicking on Save button")
        notepad_win.mouseClick(15,70)
        time.sleep(5)

        self.log.info("Finding SaveAs window")
        windows = desktop.listWindows('Save As')
        if len(windows) == 0:
            return self.FAILURE, "SaveAs window not found"
        save_win = windows[0]
        time.sleep(5)

        # Create random filename
        rand_int = random.randint(0,999)
        filename = f'TestFile{rand_int:03d}.txt'

        self.log.info(f"Entering filename: {filename}")
        save_win.sendKeys(filename)
        time.sleep(5)

        self.log.info(f"Saving {filename}")
        buttons = save_win.listControls('Save')
        if len(buttons) == 0:
            return self.FAILURE, "Save button not found"
        save_button = buttons[0]
        save_button.mouseClick()
        time.sleep(5)

        self.log.info("Closing all Notepad windows...")
        for win in notepad_windows:
            win.close()
