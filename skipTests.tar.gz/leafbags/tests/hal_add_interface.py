import time

import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

MAX_TRIES = 60

@leafi.MainLeaf()
@leafi.DefineProcessor()
class HalAddInterface(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")

        # Initialize HAL
        HAL(self.host, bypass_version_check=True)

        (success, msg) = self.host.HAL.add_interface("br1201")       # Testing adding a new network interface  (Should PASS)
        if not success:
            self.log.error(f"HAL add_interface error: {msg}")
            return self.FAILURE, msg

        return self.SUCCESS, "HAL add_interface succeeded"

    def runSetup(self):
        self.log.info("######## runSetup ########")

        if len(self.resources) == 0:
            self.log.error("No resources")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        hostname = self.host.db_properties.get("name", "VM")
        self.log.info(f"HOST: {hostname}")

        # Wait for the initial Palantir service
        self.log.info("Waiting for initial Palantir service...")
        status = self._wait_for_service(self.host, True)
        if status < 0:
            self.log.error("Palantir failed to start")
            return False
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return

    def _wait_for_service(self, host, state: bool) -> int:
        """ Wait for Palantir service of host to match specified state. """
        tries = 0
        while tries < MAX_TRIES:
            is_up = host.service_is_up()
            self.log.info(f"is_up: {is_up}")
            if is_up == state:
                break
            tries += 1
            time.sleep(1)

        if tries >= MAX_TRIES:
            return -1
        return 0
