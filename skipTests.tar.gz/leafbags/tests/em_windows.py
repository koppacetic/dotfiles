import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            self.log.info("---- Creating emissary...")
            em = self.host.getEmissary(username=self.username, password=self.password, method=self.method)

            self.log.info("---- Getting username...")
            username = em.execfunc("win32api.GetUserName")
            if self.createAcct:
                return self.SUCCESS, f"User '{username}' created and logged in"
            else:
                return self.SUCCESS, f"User '{username}' logged in"
        except Exception as ex:
            self.log.error("Exception:", exc_info=ex)
            return self.ERROR, f"Exception: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) == 0:
            self.log.error("No resources")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        hostname = self.host.db_properties.get("name", "VM")
        self.log.info(f"HOST: {hostname}")

        self.parseArgs(*self.args, **self.kwargs)
        self.log.info(f"METHOD: {self.method}")
        self.log.info(f"USER:   {self.username}")
        self.log.info(f"CREATE: {self.createAcct}")

        if self.createAcct:
            try:
                self.log.info(f"Creating {self.username}...")
                # create a user account to use for logging in; user must not already exist
                win32net = self.host.mirrorfunc("import", "win32net")
                win32netcon = self.host.mirrorfunc("import", "win32netcon")
                win32net.NetUserAdd(
                    None,
                    1,
                    {
                        "name": self.username,
                        "password": self.password,
                        "password_age": 0,
                        "priv": win32netcon.USER_PRIV_USER,
                        "home_dir": None,
                        "comment": None,
                        "flag": win32netcon.UF_DONT_EXPIRE_PASSWD,
                        "script_path": None,
                    },
                )

                # add to local users group
                self.log.info(f"Adding {self.username} to local users group...")
                win32net.NetLocalGroupAddMembers(None, "Users", 3, ({"domainandname": self.username},))
                self.log.info(f"User '{self.username}' created successfully")
            except Exception as ex:
                self.log.error(f"Error creating {self.username}: {ex}")
                return False
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return

    def parseArgs(self, username=None, password=None, method=None, createAcct=False, **kwargs):
        self.username = username
        self.password = password
        self.method = method
        self.createAcct = createAcct
