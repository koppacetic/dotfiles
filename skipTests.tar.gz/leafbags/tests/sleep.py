import time

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

DEFAULT_SLEEPTIME = 3

@leafi.MainLeaf()
class SleepTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            self.log.info(f"Sleeping for {self.sleeptime} seconds...")
            time.sleep(self.sleeptime)
            return self.SUCCESS, f"Slept for {self.sleeptime} seconds."
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            self.log.info(f"ARGS: {self.args}")
            self.log.info(f"KWARGS: {self.kwargs}")
            self.parseArgs(*self.args, **self.kwargs)

            if len(self.resources) < 1:
                self.log.error("Wrong number of resources specified, expecting at least 1")
                return False

            self.host = self.resources[0]
            if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
                self.hostname = self.host.db_properties.get("name", "VM")
                self.log.info(f"HOST: {self.hostname}")
            return True
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return

    def parseArgs(self, sleeptime=DEFAULT_SLEEPTIME, **kwargs):
        self.sleeptime = int(sleeptime)
