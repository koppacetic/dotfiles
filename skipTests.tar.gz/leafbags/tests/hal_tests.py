import time
from typing import Optional

import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

MAX_TRIES = 60  # 5 minutes
SNAPSHOT_NAME = "Snapshot01"

@leafi.MainLeaf()
@leafi.DefineProcessor()
class HalTests(leaf.Leaf):
    def runSetup(self):
        self.log.info("######## runSetup ########")
        return True

    def run(self):
        self.log.info("######## run ########")
        if len(self.resources) == 0:
            return self.FAILURE, "No resources"
        host = self.resources[0]
        assert isinstance(host, undermine.undermine.client.Client)
        assert isinstance(host, palantir.client.Client)
        hostname = host.db_properties.get("name", "VM")
        self.log.info(f"HOST: {hostname}")

        # Initialize HAL
        HAL(host, bypass_version_check=True)

        # Wait for the guest agent to be up and running
        self.log.info("Waiting for guest agent...")
        status = self._wait_for_power(host, True)
        if status < 0:
            return self.FAILURE, "Wait for guest agent (power) failed"
        status = self._wait_for_service(host, True)
        if status < 0:
            return self.FAILURE, "Wait for guest agent (palantir) failed"

        ######## Reboot/Shutdown Test ########

        msg = self._test_reboot(host)
        if msg is not None:
            return self.FAILURE, msg

        # Restart host for next test
        self.log.info("---- Restarting host...")
        (success, msg) = host.HAL.power_on()
        if not success:
            return self.FAILURE, msg
        status = self._wait_for_service(host, True)
        if status < 0:
            return self.FAILURE, "Host failed to restart"
        self.log.info("Restart succeeded")
        time.sleep(2)

        ######## Power Tests ########

        msg = self._test_power(host)
        if msg is not None:
            return self.FAILURE, msg

        self.log.info("---- Waiting for service...")
        status = self._wait_for_service(host, True)
        if status < 0:
            return self.FAILURE, "Host failed to restart"
        self.log.info("Service is up")
        time.sleep(2)

        ######## Suspend/Resume Test ########

        msg = self._test_suspend(host)
        if msg is not None:
            return self.FAILURE, msg

        ######## Snapshot Test ########

        msg = self._test_snapshot(host)
        if msg is not None:
            return self.FAILURE, msg

        return self.SUCCESS, "All HAL tests succeeded"

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return

    def _test_snapshot(self, host) -> Optional[str]:
        """ Test HAL snapshot functions """
        # Has napshots
        self.log.info("==== HasSnapshots Test")
        (has_snapshots, _) = host.HAL.has_snapshots()
        self.log.info(f"has_snapshots: {has_snapshots}")
        if has_snapshots:
            (success, msg) = host.HAL.delete_snapshot(SNAPSHOT_NAME)
            if not success:
                return msg

        # Snapshot VM
        self.log.info("==== CreateSnapshot Test")
        (success, msg) = host.HAL.snapshot_vm(SNAPSHOT_NAME)
        if not success:
            return msg
        (has_snapshots, _) = host.HAL.has_snapshots()
        self.log.info(f"has_snapshots: {has_snapshots}")

        self.log.info("==== GetCurrentSnapshot Test")
        (success, snapshot) = host.HAL.get_current_snapshot()
        if not success:
            return msg
        if snapshot is not None:
            self.log.info(f"get_current_snapshot successful")

        self.log.info("==== ListSnapshots Test")
        (success, snapshots) = host.HAL.list_snapshots()
        if not success:
            return msg
        for name in snapshots:
            self.log.info(f"{name}")

        self.log.info("==== HasSnapshot Test")
        (success, has_snapshot) = host.HAL.has_snapshot(SNAPSHOT_NAME)
        if not success:
            return msg
        self.log.info(f"has_snapshot({SNAPSHOT_NAME}): {has_snapshot}")

        self.log.info("==== DeleteSnapshot Test")
        (success, msg) = host.HAL.delete_snapshot(SNAPSHOT_NAME)
        if not success:
            return msg
        (has_snapshots, _) = host.HAL.has_snapshots()
        self.log.info(f"has_snapshots: {has_snapshots}")

    def _test_power(self, host) -> Optional[str]:
        """ Test HAL power functions """
        # Power off VM
        self.log.info("==== PowerOff Test")
        (success, msg) = host.HAL.power_off()
        if not success:
            return msg

        # Wait for state to change
        self.log.info("Waiting for powered off state...")
        status = self._wait_for_power(host, False)
        if status < 0:
            return "Wait for PowerOff failed"
        self.log.info("PowerOff succeeded")

        # Power on VM
        self.log.info("==== PowerOn Test")
        (success, msg) = host.HAL.power_on()
        if not success:
            return msg

        # Wait for state to change
        self.log.info("Waiting for powered on state...")
        status = self._wait_for_power(host, True)
        if status < 0:
            return "Wait for PowerOn failed"
        self.log.info("PowerOn succeeded")

    def _test_reboot(self, host) -> Optional[str]:
        """ Test HAL guest functions """
        self.log.info("==== Reboot Test")
        (success, msg) = host.HAL.guest_power_cycle()
        if not success:
            return msg

        # Woit for host to go down
        self.log.info(f"Waiting to host to go down...")
        status = self._wait_for_service(host, False)
        if status < 0:
            return "Reboot failed"

        # Woit for host to come back up
        self.log.info(f"Waiting to host come back up...")
        status = self._wait_for_power(host, True)
        if status < 0:
            return "Wait for PowerOn failed"
        status = self._wait_for_service(host, True)
        if status < 0:
            return "Reboot failed"
        self.log.info("Reboot succeeded")

        self.log.info("==== Shutdown Test")
        (success, msg) = host.HAL.guest_power_off()
        if not success:
            return msg

        # Woit for host to go down
        self.log.info(f"Waiting to host to go down...")
        status = self._wait_for_service(host, False)
        if status < 0:
            return "Shutdown failed"
        self.log.info("Shutdown succeeded")

    def _test_suspend(self, host) -> Optional[str]:
        """ Test HAL suspend/resume functions """
        self.log.info("==== Suspend Test")
        (success, msg) = host.HAL.suspend()
        if not success:
            return msg

        # Woit for host to go down
        self.log.info(f"Waiting to host to go down...")
        status = self._wait_for_service(host, False)
        if status < 0:
            return "Suspend failed"
        self.log.info("Suspend succeeded")

        self.log.info("==== Resume Test")
        (success, msg) = host.HAL.resume()
        if not success:
            return msg

        # Woit for host to come back up
        self.log.info(f"Waiting to host to come back up...")
        status = self._wait_for_service(host, True)
        if status < 0:
            return "Resume failed"
        self.log.info("Resume succeeded")

    def _wait_for_power(self, host, state: bool) -> int:
        """ Wait for power_state of host to match specified state. """
        tries = 0
        while tries < MAX_TRIES:
            try:
                (success, powered_up) = host.HAL.power_state()
                self.log.info(f"powered_up: '{powered_up}'")
                if success and powered_up == state:
                    break
            except Exception as ex:
                self.log.info(f"power_state() error: {ex}")

            tries += 1
            time.sleep(5)

        if tries >= MAX_TRIES:
            return -1
        return 0

    def _wait_for_service(self, host, state: bool) -> int:
        """ Wait for Palantir service of host to match specified state. """
        tries = 0
        while tries < MAX_TRIES:
            is_up = host.service_is_up()
            self.log.info(f"is_up: {is_up}")
            if is_up == state:
                break
            tries += 1
            time.sleep(5)

        if tries >= MAX_TRIES:
            return -1
        return 0
