import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        if len(self.resources) == 0:
            return self.FAILURE, "No resources"
        test_host = self.resources[0]
        assert isinstance(test_host, undermine.undermine.client.Client)
        assert isinstance(test_host, palantir.client.Client)

        os_mirror = test_host.mirrorfunc('import', 'getpass')
        user_name = os_mirror.getuser()

        return self.SUCCESS, "User: {}".format(user_name)
