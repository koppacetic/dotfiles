import os
import time

import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from undermine.undermine.client import Client

TEST_DIR = "putTest"
TEST_FILE = "lorem.txt"

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def runSetup(self):
        self.log.info("######## runSetup ########")
        return True

    def run(self):
        self.log.info("######## run ########")
        if len(self.resources) == 0:
            return self.FAILURE, "No resources"
        host = self.resources[0]
        assert isinstance(host, undermine.undermine.client.Client)
        assert isinstance(host, palantir.client.Client)
        hostname = host.db_properties.get("name", "VM")
        self.log.info(f"HOST: {hostname}")

        try:
            self.log.info(f"Creating {TEST_DIR} directory...")
            rv = host.mkdir(TEST_DIR)
            self.log.info(f"mkdir() returned {rv}")

            lpath = f"media/{TEST_FILE}"
            rpath = f"putTest/{TEST_FILE}"
            self.log.info(f"Putting {lpath} to {rpath}...")
            rv = host.put(lpath, rpath)
            self.log.info(f"put() returned {rv}")

            self.log.info(f"Reading {rpath}...")
            # time.sleep(5)
            contents = host.fread(rpath)

            self.log.info(f"Getting {rpath}...")
            rv = host.get(rpath, TEST_FILE)
            self.log.info(f"get() returned {rv}")
        except Exception as ex:
            return self.FAILURE, f"Exception: {ex}"

        put_size = os.stat(lpath).st_size
        read_size = len(contents)
        if put_size != read_size:
            return self.FAILURE, f"put_size: {put_size}, read_size: {read_size}"

        get_size = os.stat(TEST_FILE).st_size
        if put_size != get_size:
            return self.FAILURE, f"put_size: {put_size}, get_size: {get_size}"

        return self.SUCCESS, f"{put_size} bytes transferred"

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        host = self.resources[0]  # type: Client
        host.rmtree(TEST_DIR)
