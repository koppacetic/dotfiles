import palantir
import gs_client
import undermine
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            agent = self.host.properties.get("agent")
            if agent is None:
                return self.FAILURE, "No agent property"
            if agent == "None":
                return self.FAILURE, "VM is not running an agent"

            if agent == "pal3":
                r_palantir = self.host.mirrorfunc('import', 'palantir')
                remote_ver = r_palantir.__version__
                local_ver = palantir.__version__
                self.log.info("Getting logged in user...")
                whoami = self.host.execcmd("whoami", shell=True)
                whoami = whoami.strip()
                self.log.info(f"SUCCESS - User: {whoami}, Undermine: {undermine.__version__}, RemotePal: {remote_ver}, LocalPal: {local_ver}")
                return self.SUCCESS, f"User: {whoami}, Undermine: {undermine.__version__}, RemotePal: {remote_ver}, LocalPal: {local_ver}"
            elif agent == "gene":
                remote_ver = self.host.version()
                local_ver = gs_client.__version__

                self.log.info("Getting logged in user...")
                (retcode, whoami, stderr) = self.host.execcmd("whoami", shell=True)
                if retcode != 0:
                    self.log.error(f"Error: retcode={retcode}\n{stderr}")
                whoami = whoami.strip()
                self.log.info(f"SUCCESS - User: {whoami}, Undermine: {undermine.__version__}, RemoteGS: {remote_ver}, LocalGS: {local_ver}")
                return self.SUCCESS, f"User: {whoami}, Undermine: {undermine.__version__}, RemoteGS: {remote_ver}, LocalGS: {local_ver}"

            return self.FAILURE, f"Invalid agent property: {agent}"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) == 0:
                self.log.error("No resources specified")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties found, use rid:// to specify resources")
                return False

            hostname = self.host.db_properties.get("name")
            if hostname is None:
                self.log.error("No 'name' in db_properties")
                return False
            self.log.info(f"HOST: {hostname}")

            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False

            return self.host.service_is_up()
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
