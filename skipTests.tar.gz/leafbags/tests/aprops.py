import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from palantir.support.netcom import NetcomError


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):


        randnum=0
        randstr = 'Success'


        aprops=['sw.os.servicepack', 'sw.os.sysencoding', 'sw.os.termencoding', 'sw.os.version', 'sys.hw', 'sys.name', 'sys.network.hostname', 'sys.nics', 'sys.platform', 'hw.class', 'sw.apps', 'sw.os.architecture', 'sw.os.buildId', 'sw.os.distribution', 'sw.os.edition', 'sw.os.family', 'sw.os.installId', 'sw.os.installType', 'sw.os.language', 'sw.os.name', 'sw.os.product', 'sw.os.productId']
        for aprop in aprops:
            try:
                self.log.info('Getting {}: {}'.format(aprop, self.resources[0].aprops[aprop]))
            except ImportError as err:
                errstr = 'Could not find {}:{} '.format(aprop, err)
                self.log.error(errstr)
                randstr += errstr
                randnum = self.FAILURE


        return randnum, randstr
