import time

import palantir.client
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
import undermine.undermine.main_script as main

DEFAULT_SLEEPTIME = 60
DEFAULT_TIMEOUT = 30

@leafi.MainLeaf()
class MyTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")

        self.log.info(f"Setting timeout to {self.script_timeout} seconds...")
        main.script_set_timeout(self.script_timeout)

        self.log.info(f"Sleeping for {self.sleeptime} seconds...")
        time.sleep(self.sleeptime)

        return self.SUCCESS, f"Slept for {self.sleeptime} seconds."

    def runSetup(self):
        self.log.info("######## runSetup ########")
        self.log.info(f"ARGS: {self.args}")
        self.log.info(f"KWARGS: {self.kwargs}")
        self.parseArgs(*self.args, **self.kwargs)

        if len(self.resources) < 1:
            self.log.error("Wrong number of resources specified, expecting at least 1")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.hostname = self.host.db_properties.get("name", "VM")
            self.log.info(f"HOST: {self.hostname}")

        if not self.host.service_is_up():
            self.log.error("Host Palantir not responding")
            return False
        self.log.info(f"Palantir running on {self.hostname}")
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return

    def parseArgs(self, sleeptime=DEFAULT_SLEEPTIME, script_timeout=DEFAULT_TIMEOUT, **kwargs):
        self.sleeptime = int(sleeptime)
        self.script_timeout = int(script_timeout)
