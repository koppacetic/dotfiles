import time
from uuid import uuid4

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL


@leafi.MainLeaf()
class UnitTest(leaf.Leaf):
    def run(self):
        target = self.resources[0]
        build = self.resources[1]
        usb = self.usbs[0]
        unique_str = uuid4().hex
        HAL(target, bypass_version_check=True)
        HAL(build, bypass_version_check=True)
        self.log.info(unique_str)
        task = build.HAL.attach_device_to_vm(usb.db_properties['properties']['address'])
        task.wait(5)
        self.log.info(task.value)
        og_lsblk_ret = build.execcmd('lsblk')
        self.log.info(og_lsblk_ret)
        time.sleep(10)

        # mount USB, write a unique string to disk, and then unmount
        mkdir_ret = build.mkdir('/tmp/some_usb_device/')
        self.log.info(mkdir_ret)
        more_out = build.execcmd('/usr/sbin/mkfs.ext3 /dev/sdb1', shell=True, wait=True)
        self.log.info(more_out)
        another = build.execcmd('mount -o rw /dev/sdb1 /tmp/some_usb_device/', shell=True, wait=True)
        self.log.info(another)
        echo_ret = build.execcmd('echo {} > /tmp/some_usb_device/somefile'.format(unique_str), shell=True, wait=True)
        self.log.info(echo_ret)
        some_lsblk_ret = build.execcmd('lsblk')
        self.log.info(some_lsblk_ret)
        umount_ret = build.execcmd('umount /dev/sdb1', shell=True, wait=True)
        self.log.info(umount_ret)
        more_task = build.HAL.detach_device_from_vm(usb.db_properties['properties']['address'])
        more_task.wait(30)
        self.log.info(more_task.value)

        # start evdet, attach usb to target, mount, and cat file
        targ_task = target.HAL.attach_device_to_vm(usb.db_properties['properties']['address'])
        targ_task.wait(30)
        self.log.info(targ_task.value)
        target.mkdir('/tmp/another_usb_device/')
        lsblk_ret = target.execcmd('lsblk')
        self.log.info(lsblk_ret)
        target.execcmd('mount /dev/sdb1 /tmp/another_usb_device/', shell=True, wait=True)
        cat_out = target.execcmd('cat /tmp/another_usb_device/somefile', shell=True, wait=True)
        self.log.info(cat_out)

        # check to see that the unique string is present and the same value as previous
        if cat_out.split('\n')[0] == unique_str:
            return self.SUCCESS, 'Completed Successfully.'
        return self.FAILURE, 'Uh oh.'
