import random
import time

import palantir.client
import undermine.underlib.wingman as WM
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from event_detection.evdet_util import EvDet

EVDET_INTERVAL = 2.0
INTERVAL_TOLERANCE = 0.25

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) != 2:
            self.log.error("Wrong number of resources specified, expecting 2")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.hostname = self.host.db_properties.get("name", "VM")
            self.log.info(f"HOST: {self.hostname}")
            properties = self.host.db_properties.get("properties", {})
            if properties.get("family", "") != "windows":
                self.log.error("Host is not running windows")
                return False

        if not self.host.service_is_up():
            self.log.error("Host Palantir not responding")
            return False
        self.log.info(f"Palantir running on {self.hostname}")

        self.eventDet = self.resources[1]
        assert isinstance(self.eventDet, undermine.undermine.client.Client)
        assert isinstance(self.eventDet, palantir.client.Client)
        if hasattr(self.eventDet, "db_properties") and self.eventDet.db_properties is not None:
            self.evdet_hostname = self.eventDet.db_properties.get("name", "VM")
            self.log.info(f"EVDET: {self.evdet_hostname}")

        if not self.eventDet.service_is_up():
            self.log.error("EventDet Palantir not responding")
            return False
        self.log.info(f"Palantir running on {self.evdet_hostname}")
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True

    def run(self):
        self.log.info("######## run ########")
        self.log.info(f"Creating EvDet...")
        evDet = EvDet(self.host, self.eventDet, auto_start=False)

        try:
            self.log.info("Stopping EvDet without starting...")
            num_events, max_interval, num_errors = evDet.stop()
        except Exception as ex:
            if evDet.stop_error_msg:
                self.log.info(f"Stop reason: {evDet.stop_error_msg}")
            self.log.info(f"Stop exception: {ex}")

        # Start EvDet with a short timeout
        self.log.info(f"Starting EvDet, interval={EVDET_INTERVAL}, timeout=10")
        evDet.start(interval=EVDET_INTERVAL, timeout=10)

        self.log.info("Getting emissary...")
        em = self.host.getEmissary()

        self.log.info("Installing wingman...")
        wingman = WM.install_wingman(em)

        desktop = wingman.Desktop()

        # Run test that takes longer that timeout value
        self._notepad_test(em, desktop)

        # Make sure we detect the event detection timeout
        try:
            self.log.info("Stopping EvDet...")
            num_events, max_interval, num_errors = evDet.stop()
        except Exception as ex:
            if evDet.stop_error_msg:
                self.log.info(f"Stop reason: {evDet.stop_error_msg}")
                return self.SUCCESS, "Event detection timeout successfully detected"
            self.log.error(f"Stop exception: {ex}")
            return self.FAILURE, str(ex)

        msg = f"Got {num_events} events, {num_errors} errors, max_interval {max_interval:.4f}"
        self.log.info(msg)
        return self.FAILURE, "Event detection timeout not detected"

    def _notepad_test(self, em, desktop):
        """Open and close Notepad."""
        self.log.info("---- Starting notepad.exe...")
        em.spawn('notepad.exe', shell=True)
        time.sleep(5)

        self.log.info("Finding Notepad window...")
        notepad_windows = desktop.listWindows('Notepad')
        if len(notepad_windows) == 0:
            return self.FAILURE, "Notepad window not found"
        time.sleep(5)

        self.log.info("Closing all Notepad windows...")
        for win in notepad_windows:
            win.close()
        time.sleep(5)
