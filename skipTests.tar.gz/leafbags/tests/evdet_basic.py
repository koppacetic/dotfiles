import time

import undermine.underlib.wingman as WM
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from event_detection.evdet_util import EvDet

EVDET_INTERVAL = 2.0
INTERVAL_TOLERANCE = 0.25

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            self.log.info(f"Starting EventDetection, interval={EVDET_INTERVAL}")
            evDet = EvDet(self.host, self.eventDet, interval=EVDET_INTERVAL)

            self.log.info("Getting emissary...")
            em = self.host.getEmissary()

            self.log.info(f"Executing emissary whoami...")
            em_whoami = em.execcmd("whoami", shell=True)
            self.log.info(f"WHOAMI: {em_whoami}")

            self.log.info(f"Executing emissary notepad...")
            if self.host.properties.get("agent") == "gene":
                retval = em.execcmd("notepad.exe", shell=True, wait=False)
            else:
                retval = em.execcmd("notepad.exe", shell=True, wait=False, detach=True)
            self.log.info(f"{retval}")

            self.log.info(f"Sleeping...")
            time.sleep(10)

            self.log.info("Stopping EvDet...")
            numEvents, max_interval, numFailures = evDet.stop(get_files=True)
            msg = f"Got {numEvents} events, {numFailures} failures. max_interval {max_interval:.4f}"
            self.log.info(msg)

            if numEvents == 0:
                self.log.error("No events detected")
                return self.FAILURE, "No events detected"

            if max_interval - EVDET_INTERVAL > INTERVAL_TOLERANCE:
                msg = f"Max interval was {max_interval:.4f}, expected {EVDET_INTERVAL} or less"
                self.log.error(msg)
                return self.FAILURE, msg

            return self.SUCCESS, msg
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) != 2:
                self.log.error("Wrong number of resources specified, expecting 2")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            hostname = self.host.db_properties.get("name")
            self.log.info(f"HOST: {hostname}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False
            if not self.host.service_is_up():
                self.log.error(f"Agent not responding on {hostname}")
                return False

            self.eventDet = self.resources[1]
            if not hasattr(self.eventDet, "db_properties") or self.eventDet.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            evdet_hostname = self.eventDet.db_properties.get("name")
            self.log.info(f"EVDET: {evdet_hostname}")
            if not self.eventDet.service_is_up():
                self.log.error(f"Agent not responding on {evdet_hostname}")
                return False
            return True
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
