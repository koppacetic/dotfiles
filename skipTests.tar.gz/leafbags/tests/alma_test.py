import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

SLEEP_TIME = 5

@leafi.MainLeaf()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            self.log.info("Running tcpdump...")
            tcpdump_out = self.host.execcmd("tcpdump --version", shell=True, wait=True)
            self.log.info(tcpdump_out)

            return self.SUCCESS, 'Completed Successfully.'
        except Exception as ex:
            self.log.error(f"Exception: {ex}")
            return self.FAILURE, f"Exception: {ex}"

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) != 1:
                self.log.error("Not enough resources specified, expected 1")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties found, use rid:// to specify resources")
                return False

            hostname = self.host.db_properties.get("name")
            if hostname is None:
                self.log.error("No 'name' in db_properties")
                return False
            self.log.info(f"HOST: {hostname}")

            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False

            # # Install packages needed by test
            # # Determine which package manager to use
            # if self.host_osname in ["debian", "ubuntu"]:
            #     pacman = "apt"
            # else:
            #     pacman = "dnf"

            # # Install nmap
            # self.log.info("Installing nmap...")
            # rc, out = self.host.execcmd(f"{pacman} -q -y --force-yes install nmap", shell=True,
            #                             returncode=self.host.execute.RETURN)
            # self.log.info(out)
            # if rc != 0:
            #     return False
            return True
        except Exception as ex:
            self.log.error(f"{pacman} install error: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True
