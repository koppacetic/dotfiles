import time

import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from hal_client.hal_client import HAL

REBOOT_WAIT = 15
MAX_TRIES = 24  # 4 minutes

@leafi.MainLeaf()
@leafi.DefineProcessor()
class HalReboot(leaf.Leaf):
    def run(self):
        self.log.info("######## run ########")
        try:
            # Initialize HAL
            HAL(self.host, bypass_version_check=True)

            # Wait for the initial host power on
            self.log.info("Waiting for initial host power on...")
            status = self._wait_for_power(self.host, True)
            if status < 0:
                return self.FAILURE, "Wait for initial power on failed"

            """ Test HAL guest functions """
            self.log.info("Calling guest_power_cycle...")
            (success, msg) = self.host.HAL.guest_power_cycle()
            if not success:
                return self.FAILURE, msg

            # # Wait for host to shutdown
            # self.log.info("Waiting to host to shut down...")
            # status = self._wait_for_power(self.host, False)
            # if status < 0:
            #     return self.FAILURE, "Reboot failed: No power off"
            self.log.info(f"Sleeping for {REBOOT_WAIT} seconds...")
            time.sleep(REBOOT_WAIT)

            # Wait for host to come back up
            self.log.info("Waiting to host come back up...")
            status = self._wait_for_power(self.host, True)
            if status < 0:
                return self.FAILURE, "Reboot failed: No power on"

            # Wait for agent service
            self.log.info("Waiting for agent service...")
            status = self._wait_for_service(self.host, True)
            if status < 0:
                return self.FAILURE, "Reboot failed: Agent service failed to start"

            self.log.info("Reboot succeeded")
            return self.SUCCESS, "Reboot succeeded"
        except Exception as ex:
            self.log.error(f"{type(ex).__name__}: {ex}")
            return self.FAILURE, f"{type(ex).__name__}: {ex}"

    def _wait_for_power(self, host, state: bool) -> int:
        """ Wait for power_state of host to match specified state. """
        tries = 0
        while tries < MAX_TRIES:
            try:
                (success, powered_up) = host.HAL.power_state()
                self.log.info(f"powered_up: '{powered_up}'")
                if success and powered_up == state:
                    break
            except Exception as ex:
                self.log.info(f"power_state() error: {ex}")

            tries += 1
            time.sleep(10)

        if tries >= MAX_TRIES:
            return -1
        return 0

    def _wait_for_service(self, host, state: bool) -> int:
        """ Wait for Palantir service of host to match specified state. """
        tries = 0
        while tries < MAX_TRIES:
            is_up = host.service_is_up()
            self.log.info(f"is_up: {is_up}")
            if is_up == state:
                break
            tries += 1
            time.sleep(10)

        if tries >= MAX_TRIES:
            return -1
        return 0

    def runSetup(self):
        self.log.info("######## runSetup ########")
        try:
            if len(self.resources) != 1:
                self.log.error("Wrong number of resources specified, expecting 1")
                return False

            self.host = self.resources[0]
            if not hasattr(self.host, "db_properties") or self.host.db_properties is None:
                self.log.error("No db_properties, use rid:// to specify resources")
                return False
            hostname = self.host.db_properties.get("name")
            self.log.info(f"HOST: {hostname}")
            self.host.properties = self.host.db_properties.get("properties")
            if self.host.properties is None:
                self.log.error("No properties found")
                return False
            if not self.host.service_is_up():
                self.log.error(f"Agent not responding on {hostname}")
                return False
            return True
        except Exception as ex:
            self.log.error(f"runSetup error: {type(ex).__name__}: {ex}")
            return False

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
