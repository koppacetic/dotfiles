import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

import paramiko

USERNAME = "root"
PASSWORD = "dartadmin"

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        self.log.info("######## runSetup ########")

        try:
            self.log.info("Connecting to host...")
            ssh = paramiko.client.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(self.host.ip, username=USERNAME, password=PASSWORD)

            self.log.info("Running command...")
            _stdin, _stdout, _stderr = ssh.exec_command("uname -a")
            output = _stdout.read().decode()

            self.log.info("Closing connection...")
            ssh.close()
        except Exception as ex:
            self.log.error(f"ERROR: {ex}")
            return self.FAILURE, str(ex)

        return self.SUCCESS, output

    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) < 1:
            self.log.error("Wrong number of resources specified, expecting at least 1")
            return False

        self.host = self.resources[0]
        # self.log.info(f"RESOURCE: {self.host.db_properties}")
        if self.host.db_properties is None:
            self.log.error("Resource has no db_properties, use rid:// to specify")
            return False

        self.hostname = self.host.db_properties.get("name", "UNKNOWN")
        self.parent = self.host.db_properties.get("parent", {}).get("name", "")
        self.log.info(f"HOST: {self.hostname}")
        self.log.info(f"IP: {self.host.ip}")
        self.log.info(f"PARENT: {self.parent}")

        self.host_props = self.host.db_properties.get("properties")
        if self.host_props is None:
            self.log.error("Resource has no properties, use rid:// to specify")
            return False

        os_name = self.host_props.get("os_name", "")
        if os_name != "esxi":
            self.log.error("OS is not esxi")
            return False

        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return
