import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

import undermine.underlib.wingman as wingman

import time


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def parseArgs(self, username=None, password=None, domain=None, method=None, createAcct=False, **kwargs):
        self.username = username
        self.password = password
        self.domain = domain
        self.method = method
        self.createAcct = createAcct

    def runSetup(self):
        self.parseArgs(*self.args, **self.kwargs)
        resource = self.resources[0]
        resource.manage_pip_package('comtypes=1.1.8')
        if self.createAcct:
            # create a user account to use for logging in; user must not already
            # exist
            win32net = resource.mirrorfunc("import", "win32net")
            win32netcon = resource.mirrorfunc("import", "win32netcon")
            win32net.NetUserAdd(
                None,
                1,
                {
                    "name": self.username,
                    "password": self.password,
                    "password_age": 0,
                    "priv": win32netcon.USER_PRIV_USER,
                    "home_dir": None,
                    "comment": None,
                    "flag": win32netcon.UF_DONT_EXPIRE_PASSWD,
                    "script_path": None,
                },
            )

            # add to local users group
            win32net.NetLocalGroupAddMembers(None, "Users", 3, ({"domainandname": self.username},))

        return True

    def run(self):
        if len(self.resources) == 0:
            return self.FAILURE, "no resources"

        h = self.resources[0]

        self.testNoGui(h)
        # self.testGui(h)
        # self.testMirror(h)

        return self.SUCCESS, "Pass"

    def testGui(self, h):
        self.log.info("Testing GUI")

        ex = None
        try:
            em = h.getEmissary(domain=self.domain, username=self.username, password=self.password, method=self.method)
            # h.execfunc( 'exec',
            #              'import subprocess',
            #              'import time',
            #              'p = subprocess.Popen(["mspaint.exe"])',
            #          )
            if em:
                em.execfunc(
                    "exec",
                    "import subprocess",
                    "import time",
                    'p = subprocess.Popen(["mspaint.exe"])',
                )

            time.sleep(2)

            # use wingman to get the paint window and close it
            wm = wingman.install_wingman(em)
            desktop = wm.Desktop()
            win = desktop.listWindows("paint")[0]
            win.close()

        except Exception as e:
            self.log.error("Unexpected exception:", exc_info=e)
            raise self.FailureException("Unexpected exception thrown: {0}".format(e))
        else:
            self.log.info("Verify that MSPAINT is running and visible.")

    def testNoGui(self, h):
        self.log.info("Testing No GUI")
        try:
            em = h.getEmissary(domain=self.domain, username=self.username, password=self.password, method=self.method)
        except Exception as ex:
            self.log.error("Exception:", exc_info=ex)
            raise self.FailureException("Exception: %r" % ex)

        if self.username is not None:
            username = em.execfunc("win32api.GetUserName")
            if not self.username.lower().endswith(username.lower()):
                raise Exception("expected user %r but found %r" % (self.username, username))

    def testMirror(self, h):
        self.log.info("Testing Mirror")
        em = h.getEmissary(domain=self.domain, username=self.username, password=self.password, method=self.method)

        ros = em.mirrorfunc("import", "os")
        mircwd = ros.getcwd()
        emcwd = em.execfunc("os.getcwd")

        if mircwd != emcwd:
            failure_msg = "mirror and regular function calls are different: {0} vs {1}".format(mircwd, emcwd)
            raise self.FailureException(failure_msg)
