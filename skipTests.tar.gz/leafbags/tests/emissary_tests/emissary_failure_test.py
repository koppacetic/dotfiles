import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

# test to check a deliberate bad Emissary login
@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):

    def run(self):
        if len(self.resources) > 0:
            # run the bad Emissary login test
            rv, msg = self.emissary_badlogin_test()
            if rv != self.SUCCESS:
                return self.FAILURE, msg

            return self.SUCCESS, msg
        return self.FAILURE, "A Resource wasn't assigned to this test"

    # tests that a bad Emissary login fails the way we expect
    def emissary_badlogin_test(self):
        target = self.resources[0]

        rv = self.FAILURE
        msg = 'Giving a bad username and password failed in an unexpected way'

        # run getEmissary with a bad username and password
        try:
            em = target.getEmissary(username='notarealuser', password='notarealpassword')
        # bad user/password throws a generic exception with a message 'timed out waiting for user login or reboots'
        except Exception as e:
            message = "{0}".format(e)
            if 'timed out waiting for user login' in message:
                rv = self.SUCCESS
                msg = 'User Login failed correctly when a bad user/pass was provided'

        # log in with the proper credentials to reset machine state to pre-test status
        # will need to be configured for specific environment
        em = target.getEmissary(username='user', password='dartadmin')

        return rv, msg


