import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def parseArgs(self, username=None, password=None, domain=None, method=None,
                  createAcct=False, **kwargs):
        self.username = username
        self.password = password
        self.domain   = domain
        self.method   = method
        self.createAcct = createAcct

    def runSetup(self):
        self.parseArgs(*self.args, **self.kwargs)
        resource = self.resources[0]
        #if self.createAcct:


        return True

    def run(self):
        if( len( self.resources ) == 0):
            return self.FAILURE, 'no resources'

        h = self.resources[0]

        self.testGui(h)
        self.testMirror(h)

        return self.SUCCESS, 'Pass'

    def testGui(self, h):
        self.log.info('Testing GUI')

        ex = None
        try:
            em = h.getEmissary(self.username, self.password)
            if self.username is not None:
                palantir_user = em.execcmd('whoami').rstrip()
                if not self.username.lower() == (palantir_user.lower()):
                    raise Exception('expected user %r but found %r' %
                                                (self.username, palantir_user))

            em.execfunc( 'exec',
                         'import subprocess',
                         'import time',
                         'p = subprocess.Popen(["open", "-a", "safari"])',
                     )
        except Exception, e:
            self.log.error('Unexpected exception:', exc_info=e)
            raise self.FailureException('Unexpected exception thrown.')
        else:
            self.log.info('Verify that Safari is running and visible.')

    def testMirror(self, h):
        self.log.info('Testing Mirror')
        em = h.getEmissary(self.username, self.password)

        ros = em.mirrorfunc('import', 'os')
        mircwd = ros.getcwd()
        emcwd = em.execfunc('os.getcwd')

        if mircwd != emcwd:
            raise self.FailureException(
                'mirror and regular function calls return different values (%r vs %r)' %\
                (mircwd, emcwd))
