import time

import undermine.underlib.wingman as WM
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        if len(self.resources) > 0:
            # run the wingman text test and collect its results
            rv, msg = self.test_wingman_unicode()
            if rv is not self.SUCCESS:
                self.log.info("Wingman Unicode Test Failed: {0}".format(msg))
                return rv, msg
            return self.SUCCESS, msg
        return self.SKIPPED, "Test was not provided a host object"

    def test_wingman_unicode(self):
        # initialize return values
        rv = self.SUCCESS
        msg = "Wingman Unicode Test completed successfully"

        # initialize emissary_tests and wingman
        em = self.resources[0].getEmissary(username='user', password='dartadmin')
        wingman = WM.install_wingman(em)
        desktop = wingman.Desktop()

        # start notepad and give it a couple of seconds to come up
        em.spawn('notepad.exe', shell=True)
        time.sleep(2)

        # enter text into the notepad
        win = None
        while win is None:
            windows = desktop.listWindows('Notepad')
            if len(windows) > 0:
                win = windows[0]
                test_string = \
u'Some Cyrillic: хорошо́.\nSome Greek: Καλησπέρα.\nSome Arabic:نحن نتكلم لغتين\nSome Chinese: 屠杀大学生\nSome fun: Ⓣⓗⓔ ⒬⒰⒤⒞⒦ 🇧🇷🇴🇼🇳  िѻซ ṿöẗëḋ ɟoɹ ɌȺłᵽħ ᴺᵃᵈᵉʳ'
                win.sendKeys(test_string, ucode=True)
            time.sleep(15)

        # # open the file menu
        # win.mouseClick(10, -15)
        # time.sleep(1)
        #
        # # click on the save button
        # win.mouseClick(15,70)
        # time.sleep(1)

        # open the save Dialog by using the save hotkey
        win.sendKeys('{CTRLDOWN}s{CTRLUP}')

        time.sleep(5)

        # get the Save Window
        save_win = None
        while save_win is None:
            windows = desktop.listWindows('Save As')
            if len(windows) > 0:
                save_win = windows[0]
            time.sleep(1)

        # enter file name
        save_win.sendKeys('TestUnicodeFile.txt')
        time.sleep(5)

        # check Windows version to determine if encoding needs to be changed
        systeminfo = em.execcmd('systeminfo', shell=True)
        for line in systeminfo.splitlines():
            if 'OS Name' in line:
                if not '10' in line and not '11' in line:
                    self.log.info('Not Windows 10, change Encode to UTF8')
                    encode_ctrl = save_win.getControlByClassInst('ComboBox', 3)
                    encode_ctrl.mouseClick()
                    time.sleep(1)
                    encode_ctrl.sendKeys('{DOWN}')
                    time.sleep(1)
                    encode_ctrl.sendKeys('{DOWN}')
                    time.sleep(1)
                    encode_ctrl.sendKeys('{DOWN}')
                    time.sleep(1)
                    encode_ctrl.sendKeys('{DOWN}')
                    time.sleep(1)
                    encode_ctrl.sendKeys('{ENTER}')
                    time.sleep(5)
                    break

        # save the file
        save_win.listControls('Save')[0].mouseClick()
        time.sleep(5)

        # close the notepad window
        win.close()

        time.sleep(5)

        # check that the file exists
        ros = em.mirrorfunc('import', 'os')
        ruser = ros.getenv('username')
        rpath = 'C:\\Users\\{0}\\Documents\\TestUnicodeFile.txt'.format(ruser)
        self.log.info('rpath {0}'.format(rpath))
        if not em.path_exists(rpath):
            rv = self.FAILURE
            msg = "The Test File was not saved properly"

        # check that the contents of the file have the typed string
        else:
            text = em.fread(rpath)
            self.log.info('Contents of file: {0}'.format(text))
            # adjust the newlines to match Windows's
            if test_string.replace('\n', '\r\n') not in text.decode('utf-8', 'ignore'):
                rv = self.FAILURE
                msg = 'Contents of the saved file do not match intended typed text'


        return rv, msg
