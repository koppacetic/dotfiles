import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

from palantir.support.netcom import NetcomError as NetcomError

import time

# test to check a deliberate host failure_tests scenario
@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):

    def run(self):
        if len(self.resources) > 0:

            rv, msg = self.host_failure_test()
            if rv != self.SUCCESS:
                return self.FAILURE, msg

            return self.SUCCESS, msg
        return self.FAILURE, "A Resource wasn't assigned to this test"

    def host_failure_test(self):
        rv = self.FAILURE
        msg = "Host Failure Test didn't fail in the expected way"

        failed_host = self.resources[0]
        failed_em = failed_host.getEmissary(username='user', password='dartadmin')

        try:
            # shut down the host and then run a command targeting the shutdown host, which should timeout
            failed_host.service_shutdown()

            time.sleep(10)

            failed_host.execcmd('dir', shell=True)

        # catch the NetcomError timeout exception
        except NetcomError as e:
            self.log.info('Command correctly timed out when attempting to connect to a host which has been shutdown')
            rv = self.SUCCESS
            msg = "A Timeout Error correctly fired when running a command targeting a host which has been disconnected"

        # reset the connection using the Emissary to restore the vm to a pre-test state
        failed_em.execcmd('shutdown /r /f /t 0', shell=True)

        # check for up to 5 minutes for the system to come back up, then proceed
        self.log.info('waiting for reboot to complete')
        system_up = False
        count = 0
        while system_up is False and count < 30:
            if failed_host.service_is_up():
                system_up = True
            count += 1
            time.sleep(10)

        # log the user back in
        em = failed_host.getEmissary(username='user', password='dartadmin')

        time.sleep(10)

        return rv, msg