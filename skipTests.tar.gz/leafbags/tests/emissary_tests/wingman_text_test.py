import time

import undermine.underlib.wingman as WM
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):

    def run(self):
        if len(self.resources) > 0:
            # run the wingman text test and collect it's results
            rv, msg = self.test_wingman_text()
            if rv is not self.SUCCESS:
                self.log.info("Wingman Text Test Failed: {0}".format(msg))
                return rv, msg
            return self.SUCCESS, msg
        return self.SKIPPED, "Test wasn't provided a host object"


    def test_wingman_text(self):
        # initialize return values
        rv = self.SUCCESS
        msg = "Wingman Text Test completed successfully"

        # initialize emissary_tests and wingman
        em = self.resources[0].getEmissary(username='user', password='dartadmin')
        wingman = WM.install_wingman(em)
        desktop = wingman.Desktop()

        # start notepad and give it a couple of seconds to come up
        em.spawn('notepad.exe', shell=True)
        time.sleep(2)

        # enter text into the notepad
        win = None
        while win is None:
            windows = desktop.listWindows('Notepad')
            if len(windows) > 0:
                win = windows[0]
                test_string = 'I am a longer string making sure that all of the text gets entered properly'
                win.sendKeys(test_string)
            time.sleep(15)

        # # open the file menu
        # win.mouseClick(10, -15)
        # time.sleep(1)
        #
        # # click on the save button
        # win.mouseClick(15,70)
        # time.sleep(1)

        # open the save Dialog by using the save hotkey
        win.sendKeys('{CTRLDOWN}s{CTRLUP}')
        time.sleep(5)

        # get the Save Window
        save_win = None
        while save_win is None:
            windows = desktop.listWindows('Save As')
            if len(windows) > 0:
                save_win = windows[0]
            time.sleep(1)

        # enter file name
        save_win.sendKeys('TestFile.txt')
        time.sleep(5)

        # save the file
        save_win.listControls('Save')[0].mouseClick()
        time.sleep(5)

        # close the notepad window
        win.close()

        time.sleep(5)

        # check that the file exists
        ros = em.mirrorfunc('import', 'os')
        ruser = ros.getenv('username')
        rpath = 'C:\\Users\\{0}\\Documents\\TestFile.txt'.format(ruser)
        self.log.info('rpath {0}'.format(rpath))
        if not em.path_exists(rpath):
            rv = self.FAILURE
            msg = "The Test File wasn't saved properly"

        # check that the contents of the file have the typed string
        else:
            text = em.fread(rpath)
            self.log.info('Contents of file: {0}'.format(text))
            if test_string not in text:
                rv = self.FAILURE
                msg = 'Contents of the saved file do not match intended typed text'

        return rv, msg
