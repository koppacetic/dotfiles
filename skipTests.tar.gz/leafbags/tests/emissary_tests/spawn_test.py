from undermine.undermine.consts import FailureException
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from undermine_testing.tests.undermine.process_utils import get_procs
from undermine.underlib.system.uac_utils import execute_elevated

from undermine.undermine.client import Client

import os


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        # check that there is more than one host assigned
        if len(self.resources) < 0:
            return self.FAILURE, 'No Resource Specified'

        target = self.resources[0]  # type: Client
        em = target.getEmissary()
        em.spawn('Calculator.exe', shell=True)

        if not get_procs(em, 'Calculator.exe'):
            return self.FAILURE, "Process Failed to spawn sucessfully"

        return self.SUCCESS, "Process spawned succesfully successfully"

    def runCleanup(self):
        target = self.resources[0]  # type: Client
        execute_elevated(
            target,
            "taskkill /IM Calculator.exe /F",
        )