import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def parseArgs(self, username=None, password=None, domain=None, method=None, createAcct=False, **kwargs):
        self.username = username
        self.password = password
        self.domain   = domain
        self.method   = method
        self.createAcct = createAcct

    def runSetup(self):
        self.parseArgs(*self.args, **self.kwargs)
        resource = self.resources[0]
        #if self.createAcct:
        return True

    def run(self):
        if( len( self.resources ) == 0):
            return self.FAILURE, 'no resources'

        h = self.resources[0]
        self.testNoGui(h)
        #self.testGui(h)
        #self.testMirror(h)
        return self.SUCCESS, 'Pass'

    def testNoGui(self, h):
        self.log.info('Testing No GUI')
        em = h.getEmissary(self.username, self.password)

        palantir_user = em.execcmd('whoami').rstrip()
        self.log.info('Current user is {}'.format(palantir_user))
        if self.username is not None:
            if not self.username.lower().endswith(palantir_user.lower()):
                raise Exception('expected user %r but found %r' % (self.username, palantir_user))

    def testGui( self, h ):
        self.log.info('Testing GUI')

        ex = None
        try:
            em = h.getEmissary(self.username, self.password, gui_login=True)
            em.execfunc( 'exec',
                         'import subprocess',
                         'import time',
                         'p = subprocess.Popen(["firefox"])',
                     )
        except Exception as e:
            self.log.error( 'Unexpected exception:', exc_info=e )
            raise self.FailureException( 'Unexpected exception thrown.' )
        else:
            self.log.info( 'Verify that Firefox is running and visible.' )

    def testMirror( self, h ):
        self.log.info( 'Testing Mirror' )
        em = h.getEmissary(self.username, self.password, domain=self.domain)

        ros = em.mirrorfunc('import', 'os')
        mircwd = ros.getcwd()
        emcwd = em.execfunc('os.getcwd')

        if mircwd != emcwd:
            raise self.FailureException(
                'mirror and regular function calls return different values (%r vs %r)' % (mircwd, emcwd))
