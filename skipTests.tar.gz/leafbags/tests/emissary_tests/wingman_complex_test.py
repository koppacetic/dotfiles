import time

import undermine.underlib.wingman as WM
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def run(self):
        if len(self.resources) > 0:
            # run the wingman text test and collect it's results
            rv, msg = self.test_wingman_complex()
            if rv is not self.SUCCESS:
                self.log.info("Wingman Text Test Failed: {0}".format(msg))
                return rv, msg
            return self.SUCCESS, msg
        return self.SKIPPED, "Test wasn't provided a host object"

    def test_wingman_complex(self):
        # initialize return values
        rv = self.SUCCESS
        msg = "Wingman Complex Test completed successfully"

        # initialize emissary_tests and wingman
        em = self.resources[0].getEmissary(username='user', password='dartadmin')
        wingman = WM.install_wingman(em)
        desktop = wingman.Desktop()

        # start paint and give it a couple of seconds to come up
        em.spawn('mspaint.exe', shell=True)

        # get the paint window
        win = None
        while win is None:
            windows = desktop.listWindows('Paint')
            if len(windows) > 0:
                win = windows[0]
            time.sleep(2)

        # get the window controls
        controls = win.listControls()

        # initial mouse drag
        # controls 1 is the drawing area control
        controls[0].mouseClickDrag(50,50, 100,100, mode=1)
        time.sleep(1)

        # select a new color
        # controls 2 is the palette area
        # first row of colors is at X,35 second is X,65
        # first column of colors is 470,Y last is 670,Y
        controls[2].mouseClick(530, 35)
        time.sleep(1)

        # Make second mouse drag
        controls[0].mouseClickDrag(100,50, 50,100, mode=1)
        time.sleep(1)

        # select the color 2 button that's used on right mouse button
        # color 2 is next to the color palette
        controls[2].mouseClick(445, 35)
        time.sleep(1)

        # select a color for the right mouse button color 2
        controls[2].mouseClick(610, 65)
        time.sleep(1)

        # do right mouse click
        controls[0].mouseClickDrag(51,51, 51,99, mode=1, btn=2)
        time.sleep(1)

        # select the shapes button
        # Shapes button is at roughly 250-280, Y
        controls[2].mouseClick(270, 35)
        time.sleep(1)

        # select a shape in the Shapes popup
        # clicks in the popup for shapes
        # 310, 105 is roughly the middle of the top row of shapes
        controls[2].mouseClick(310, 105)
        time.sleep(1)

        # create the shape on the drawing area
        controls[0].mouseClickDrag(100,100, 200,200, mode=1, btn=2)
        time.sleep(1)

        # # open the file menu
        # # controls[2].mouseClick(5, 5)
        # # time.sleep(1)
        # #
        # # # click on the print button
        # # win.mouseClick(10,240)
        # # time.sleep(1)
        #
        # # open the save Dialog by using the print hotkey
        # win.sendKeys('{CTRLDOWN}p{CTRLUP}')
        #
        # time.sleep(5)
        #
        # # get the Print Window
        # print_win = None
        # while print_win is None:
        #     windows = desktop.listWindows('Print')
        #     if len(windows) > 0:
        #         print_win = windows[0]
        #     time.sleep(1)
        #
        # # scroll over to other options
        # # print_controls[1] is the select printer pane
        # # 5,75 is the scroll left button to move the printers pane
        # print_controls = print_win.listControls()
        # print_controls[1].mouseClick(5,75)
        # time.sleep(1)
        #
        # # set to print to PDF
        # # the print to pdf selection is in the middle of the list, it's at 25,25
        # print_controls[1].mouseClick(25,25)
        # time.sleep(1)
        #
        # # click print
        # # it's the second control because 'Printer Selection' also matches
        # print_win.listControls('Print')[1].mouseClick()
        # time.sleep(1)
        #
        # # get the Save Window
        # save_win = None
        # while save_win is None:
        #     windows = desktop.listWindows('Save')
        #     if len(windows) > 0:
        #         save_win = windows[0]
        #     time.sleep(1)
        #
        # # type file name
        # save_win.sendKeys('TestPaintPdf')
        # time.sleep(5)
        #
        # # click the save button
        # save_win.listControls('Save')[0].mouseClick()
        # time.sleep(5)
        #
        # # close the paint window and chose not to save
        # win.close()
        # time.sleep(1)
        # prompts = desktop.listWindows('Paint')
        # closed = False
        # for prompt in prompts:
        #     ctls = prompt.listControls()
        #     if prompt is not win and len(ctls) > 14:
        #         closed = True
        #         ctls[15].mouseClick(3,3)
        #         time.sleep(2)
        #
        # if closed is False:
        #     self.log.info('Failed to find not saved prompt')

        # open the save Dialog by using the save hotkey
        win.sendKeys('{CTRLDOWN}s{CTRLUP}')
        time.sleep(5)

        # get the Save Window
        save_win = None
        while save_win is None:
            windows = desktop.listWindows('Save As')
            if len(windows) > 0:
                save_win = windows[0]
            time.sleep(1)

        # enter file name
        save_win.sendKeys('TestPaint.png')
        time.sleep(15)

        # save the file
        save_win.listControls('Save')[0].mouseClick()
        time.sleep(5)

        # close the notepad window
        win.close()

        time.sleep(5)

        # check that the file exists
        ros = em.mirrorfunc('import', 'os')
        ruser = ros.getenv('username')
        rpath = 'C:\\Users\\{0}\\Pictures\\TestPaint.png'.format(ruser)
        if not em.path_exists(rpath):
            rpath = 'C:\\Users\\{0}\\Documents\\TestPaint.png'.format(ruser)
            if not em.path_exists(rpath):
                rv = self.FAILURE
                msg = "The Test File was not saved properly"

        # get a copy of the file, and add it to the output location
        self.log.info("rpath {0}".format(rpath))
        if rv != self.FAILURE:
            output_location = self.output_dir + '/TestPaint.png'
            em.get(rpath, output_location)
            self.log.info('Please check {0} to ensure it matches test criteria for mouse actions')

        return rv, msg
