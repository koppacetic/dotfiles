from tplanner.planlang import PLANSPEC, EXECUTE, RESOURCE, FACTORS, HOST

# cli = RESOURCE(family=['win']) - RESOURCE(os=['2kpro', '2ksvr', '10ent'])
# cli = cli % FACTORS(os=True, ossp=True, arch=True, lang=True, apps=True)

cli = HOST(family=['windows'], os_name=['seven'])

test = PLANSPEC(
    script='undermine_testing.tests.emissary_tests.win_emissary_test',
    hostslots=[cli],
    paramslots=[
        ['username=emtuser'], ['password=EmtP@ss123'], ['method=gui'],
        ['createAcct=@True']
    ],
    namespace='emissary_tests',
)

e = EXECUTE(testcase=test)
