import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi

@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):

    def run(self):
        if len(self.resources) > 0:
            rv = self.SUCCESS
            msg = 'Emissary Parent test complete'

            # initialize system level and emissary_tests level host resources
            system = self.resources[0]
            em = system.getEmissary(username='user', password='dartadmin')

            # check that system level get_emissary_parent returns itself
            check_system = (system is system.get_emissary_parent())
            if check_system is False:
                rv = self.FAILURE
                msg = "FAILURE: System level host doesn't match system get_emissary_parent"

            else:
                # check that emissary_tests level get_emissary_parent return the system level host
                check_emissary = ((not(em is system)) and (system is em.get_emissary_parent()))

                if check_emissary is False:
                    rv = self.FAILURE
                    msg = "FAILURE: Emissary get_emissary_parent is not the system level host"

            return rv, msg

        return self.SKIPPED, 'No target resource provided.'