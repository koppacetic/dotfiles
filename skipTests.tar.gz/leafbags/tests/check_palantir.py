import time

import palantir
import palantir.client
import undermine
import undermine.undermine.client
import undermine.undermine.leaf as leaf
import undermine.undermine.meta.leafi as leafi
from undermine.underlib.system.win_utils import getLoggedInUser


@leafi.MainLeaf()
@leafi.DefineProcessor()
class UnitTest(leaf.Leaf):
    def runSetup(self):
        self.log.info("######## runSetup ########")
        if len(self.resources) == 0:
            self.log.error("No resources specified")
            return False

        self.host = self.resources[0]
        assert isinstance(self.host, undermine.undermine.client.Client)
        assert isinstance(self.host, palantir.client.Client)
        if hasattr(self.host, "db_properties") and self.host.db_properties is not None:
            self.hostname = self.host.db_properties.get("name", "VM")
            self.log.info(f"HOST: {self.hostname}")

        if not self.host.service_is_up():
            self.log.error("Palantir not responding")
            return False
        return True

    def runCleanup(self):
        self.log.info("######## runCleanup ########")
        return True

    def run(self):
        self.log.info("######## run ########")
        p = self.host.mirrorfunc('import', 'palantir')
        remote_ver = p.__version__
        local_ver = palantir.__version__

        self.log.info("Checking OS family...")
        if self.host.get_os_family() == 'windows':
            self.log.info("Getting logged in user...")
            (domain, user_name) = getLoggedInUser(self.host)
            while user_name is None:
                self.log.warning("Host not ready, sleeping...")
                time.sleep(5)
                self.log.info("Getting logged in user...")
                (domain, user_name) = getLoggedInUser(self.host)
            return self.SUCCESS, "User: {}/{}, Undermine: {}, RemotePalantir: {}, LocalPalantir: {}".format(domain,
                user_name, undermine.__version__, remote_ver, local_ver)
        else:
            self.log.info("Importing getpass...")
            os_mirror = self.host.mirrorfunc('import', 'getpass')
            self.log.info("Getting user...")
            user_name = os_mirror.getuser()
            return self.SUCCESS, "User: {}, Undermine: {}, RemotePalantir: {}, LocalPalantir: {}".format(user_name,
                undermine.__version__, remote_ver, local_ver)
