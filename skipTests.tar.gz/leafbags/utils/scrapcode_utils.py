import palantir

def config_it(config_host, target_host, json_data):
    config_host.fwrite('/tmp/scrapcode/scrapcode_media/input.json', json_data.replace('\\', '\\\\'), is_text=True)
    target_bin='scrap-code'
    new_target_bin='new-scrap-code'
    #if target_host.get_os_family() == palantir.client.constvalueWindows:
    if target_host.db_properties['properties']['family'] == 'windows':
        target_bin += '.exe'
        new_target_bin += '.exe'
    cmd= '/usr/bin/python3 /tmp/scrapcode/scrapcode_media/config_bin.py {} /tmp/scrapcode/scrapcode_media/input.json -o {}'.format(target_bin, new_target_bin) 
    config_host.log.info("executing {}".format(cmd))
    retval = config_host.execcmd( cmd,
                                  shell=True,
                                  wait=True, 
                                  cwd='/tmp/scrapcode/scrapcode_media')
    config_host.log.info("config_bin.py returned: {}".format(retval))

    #if target_host.get_os_family() == palantir.client.constvalueWindows:
    if target_host.db_properties['properties']['family'] == 'wdinwos':
        return 'scrap-code.exe.configured'
    else:
        return 'scrap-code.configured'
    #return new_target_bin

def config_scrapcode_file_dropper(config_host, target_host, target_path, data_path):
    '''
    [
        {   
            "operation": "drop-file",
            "configs": {
                "type": "txt", 
                "target_path": "/home/box-admin/test_file.txt",
                "data_path": "./data/test_data.txt"
            }
        }
    ]
    '''
    json_data = '[ {   "operation": "drop-file", "configs": { "type": "txt", "target_path": "'+target_path+'", "data_path": "'+data_path+'" } } ]'
    target_bin=config_it(config_host, target_host, json_data)
    return '/tmp/scrapcode/scrapcode_media/'+target_bin

def config_scrapcode_udp_ping(config_host, target_host, target_ip, data_path, port=53, num_of_pings=5, delay=1):
    '''
    [
        {
            "operation": "udp-ping",
            "configs": {
                "target_ip": "192.168.56.106",
                "port": 53,
                "num_of_pings": 5,
                "delay": 1,
                "data_path": "./data/test_data.txt"
            }
        }
    ]
    '''
    json_data = '[ { "operation": "udp-ping", "configs": { "target_ip": "'+target_ip+'", "port": '+str(port)+', "num_of_pings": '+str(num_of_pings)+', "delay": '+str(delay)+', "data_path": "'+data_path+'" } } ]'
    target_bin=config_it(config_host, target_host, json_data)
    return '/tmp/scrapcode/scrapcode_media/'+target_bin

def config_scrap_code_arp_poison(config_host, target_host, interface, target_ip, spoof_ip, ipv4_forward=True, bidirectional=True, broadcast=True):
    '''
    [
        {
            "operation": "arp-poison",
            "configs": {
                "interface": 1,
                "target_ip": "192.168.56.101",
                "spoof_ip": "192.168.56.50",
                "ipv4_forward": true,
                "bidirectional": true,
                "broadcast": true
            }
        }
    ]
    '''
    pass
