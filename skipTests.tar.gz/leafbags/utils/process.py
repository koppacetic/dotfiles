"""

"""
#import utils.constants
from palantir.client import constvalueLinux, constvalueWindows, constvalueMac

WINDOWS_TEMP_TASKFILE = 'C:\\tasklist.txt'


def get_process_list(host, name='', pid=''):
    """ Gets a formatted process list from a host.

    Is platform agnostic, but the format will be different between different os families.
    All outputs will consist of a list of dicts with at least a 'pid' field and a 'name' field

    Args:
        host: a host object
        name: (str), optional, process name to filter by
        pid: (int), optional, pid to filter by

    Returns:

    """
    process_list = ""
    os_family = host.get_os_family()
    if os_family == constvalueLinux:
        return get_process_list_linux(host, name, pid)

    elif os_family == constvalueWindows:
        return get_process_list_windows(host, name, pid)

    return process_list


def get_process_list_linux(host, name='', pid=''):
    """

    Args:
        host: a linux host object
        name: (str), optional, process name to filter by
        pid: (int), optional, pid to filter by

    Returns:

    """
    ps_list_raw = host.execcmd('ps -A', shell=True)
    ps_list_raw_lines = ps_list_raw.splitlines()
    process_list = []
    for line in ps_list_raw_lines[1:-1]:
        split_line = line.split()
        process_dict = {
            'pid': int(split_line[0]),
            'tty': split_line[1],
            'time': split_line[2],
            'name': split_line[3]
        }
        if name and pid:
            if name in process_dict['name'] and pid == process_dict['pid']:
                process_list.append(process_dict)
        elif name:
            if name in process_dict['name']:
                process_list.append(process_dict)
        elif pid:
            if pid == process_dict['pid']:
                process_list.append(process_dict)
        else:
            process_list.append(process_dict)
    return process_list


def get_process_list_windows(host, name='', pid=''):
    """

    Args:
        host: a windows host object
        name: (str), optional, process name to filter by
        pid: (int), optional, pid to filter by

    Returns:

    """
    host.execcmd('tasklist > {}'.format(WINDOWS_TEMP_TASKFILE), shell=True)
    ps_list_raw = host.fread(WINDOWS_TEMP_TASKFILE)
    ps_list_raw_lines = ps_list_raw.splitlines()
    process_list = []
    for line in ps_list_raw_lines[3:-1]:
        split_line = line.split()
        num_process_name_words = len(split_line) - 6
        process_dict = {
            'name': ' '.join(split_line[0:num_process_name_words + 1]),
            'pid': int(split_line[num_process_name_words + 1]),
            'session': split_line[num_process_name_words + 2],
            'session_num': split_line[num_process_name_words + 3],
            'mem_usage': split_line[num_process_name_words + 4]
        }
        if name and pid:
            if name in process_dict['name'] and pid == process_dict['pid']:
                process_list.append(process_dict)
        elif name:
            if name in process_dict['name']:
                process_list.append(process_dict)
        elif pid:
            if pid == process_dict['pid']:
                process_list.append(process_dict)
        else:
            process_list.append(process_dict)
    return process_list


def get_pid_from_process_name(host, name, multiple_pids=False, exact_match=True):
    """ Gets a pid from a process name. By default just gets one pid (the first it finds matching the given process
     name) but it can also return a list of pids if told to do so matching the process name in case of multiple
     processes that you want to find.

    Args:
        host: (resource object) the host to get the pid from
        name: (str) the name of the process you want to find the pid for
        multiple_pids: (bool, optional) set to True if you want to return a list of pids matching hte process name
        exact_match: (bool, optional) set to False if you want send this just a partial name ot search for (e.g.
         'chrome' instead of 'chrome.exe'

    Returns: pid, list of pids, or False/empty if not found

    """
    # get a list of all processes with the names matching the given name
    proc_list = get_process_list(host, name=name)
    pid_list = []

    # loop through the processes
    for proc in proc_list:
        # if it's an exact match either append it to the pid list or just return it depending on multiple_pids
        if exact_match and proc['name'] == name:
            if multiple_pids:
                pid_list.append(proc['pid'])
            else:
                return proc['pid']

        # if not exact_match
        elif not exact_match:
            if multiple_pids:
                pid_list.append(proc['pid'])
            else:
                return proc['pid']

    if multiple_pids:
        return pid_list

    # if we didn't find any matches, return False
    return False


def kill_process_by_name(host, name):
    """ Kills a process on a host with a given name. Pretty self-explanatory

    Args:
        host: host object to look
        name: name of process to kill

    """
#    os_family = host.get_os_family()
#    host.log.info('killing process {}'.format(name))
#    if os_family == constvalueLinux or os_family == constvalueMac:
    output = host.execcmd('pkill {}'.format(name), shell=True)
    host.log.debug(output)

#    elif os_family == constvalueWindows:
#        output = host.execcmd('taskkill /F /IM "{}"'.format(name), shell=True)
#        host.log.debug(output)
