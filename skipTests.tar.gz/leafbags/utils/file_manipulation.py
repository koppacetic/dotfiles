import os
import time


def make_temp_dir(host, root=None):
    """
    Create a temporary directory unique to the session. Directory will be rooted in the testing directory and assigned
    to the 'computer' object. No effect if called more than once. Or you could just make up your own but hey who am I
    to say.

    Args:
        host (host object): The system you want to make a temp directory on
        root (str, optional): The root directory on the system you would like to make a temp directory in. Default is
                              None. If set to None then uses the current directory.

    Returns: (str) the temp directory

    """
    host.log.info("[resource_utils.file_manipulation.make_temp_dir] Checking on creating temp_dir")
    h_os = host.mirrorfunc('import', 'os')
    if root is None:
        root = h_os.getcwd()
    if not hasattr(host, 'temp_dir') or (
            hasattr(host, 'temp_dir') and not host.execfunc('os.path.exists', host.temp_dir)):
        temp_dir = root + h_os.path.sep + get_uniq_tmp_name('temp')
        host.log.info('[resource_utils.file_manipulation.make_temp_dir] Creating temp directory: {}'.format(temp_dir))
        host.mkdir(temp_dir)
        host.temp_dir = temp_dir

    return host.temp_dir


def get_uniq_tmp_name(prefix='tmp'):
    return '_'.join([prefix, str(os.getpid()), time.strftime("%d%b%Y_%H%M%S")])

