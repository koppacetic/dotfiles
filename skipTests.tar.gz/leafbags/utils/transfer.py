import os
import sys


def upload_file(host, lname, rname, force=False, remote_check=True):
    """ Uploads a file to a host. Is basically a fancy wrapper for host.put

    Args:
        host: the host to upload the to
        lname: (str) path of the file to upload on the DART workstation
        rname: (str) remote path of where to put the file
        force: (bool) whether or not to force the put if there's already a file or whatever. Is just
            passed to host.put
        remote_check: (bool) I'm not sure what this does as it's a host.put parameter and it isn't documented in
            client.py. Tbh same thing with force that's just a guess
    """
    host.log.debug("[upload_file] Uploading file from %r to %r", lname, rname)
    rname_txt = rname + ".txt"
    host.put(lname, rname_txt, mode=0o777, force=force, remote_check=remote_check)
    host.execfunc("shutil.move", rname_txt, rname)


def upload_dir(host, lpath, rpath, force=False):
    """ Uploads a directory to a host. Is basically a fancy wrapper for host.rput

    Args:
        host: the host to upload the directory to
        lpath: (str) path of the file to upload on the DART workstation
        rname: (str) remote path of where to put the
        force: (bool) whether or not to force the put if there's already a file or whatever. Is just
            passed to host.put
    """
    host.log.debug(f'uploading dir: {lpath} --> {rpath}')
    filecount = [0]

    for root, dirs, files in os.walk(lpath):
        host.log.info('root: {}, dirs: {}, files: {}'.format(root, dirs, files))
        rdirname = rpath + lpath[len(lpath):].replace(os.sep, host.sep())
        if not host.execfunc('os.path.exists', rdirname):
            host.mkdir(rdirname)
        for name in files:
            lname = lpath + os.sep + name
            rname = rdirname + host.sep() + name
            if not os.path.isfile(lname):
                continue
            filecount[0] += 1
            host.put(lname, rname, force=force, remote_check=False)

    host.log.info(f'-uploaded {filecount[0]} files')
    return


def upload_content(host, content, rname, force=False):
    """ Uploads some text to a file. Basically a wrapper for host.fwrite() in client.py

    Args:
        host: the host object to write the file on
        content: (str) an the text to write to the file
        rname: (str) the path of the file to write
        force: (bool) True if you're cool with removing a file that's already there, False if you're not

    Returns:

    """
    if force:
        host.rmfile(rname)
    else:
        if host.execfunc('os.path.exists', rname):
            return
    if isinstance(content.str):
        host.fwrite(rname, content.encode())
    else:
        host.fwrite(rname, content)
    host.execfunc('os.fchmod', rname, 0o777)

def transfer_file_between_hosts(from_host, from_path, to_host, to_path, transfer_buffer = 1024 * 512):
    """ Transfers a file between 2 hosts.

    Chunks it in bytes so as not to break the range

    Args:
        from_resource: resource object to transfer file from
        from_path: (str) path on from_resource for file to transfer
        to_resource: resource object to transfer file to
        to_path: (str) path on to_resource to transfer file to
        transfer_buffer: (optional, int) buffer in bytes for transferring buffer

    Returns: True if success, False otherwise

    """
    if not from_host.path_exists(from_path):
        return False, "path {} does not exist on host {}".format(from_path, from_host)
    offset = 0

    # read from from_path in chunks to memory, then write to to_path
    data = from_host.fread(from_path, offset=offset, nbytes=transfer_buffer)
    while data:
        to_host.fwrite(to_path, data, offset=offset)
        offset += transfer_buffer
        data = from_host.fread(from_path, offset=offset, nbytes=transfer_buffer)

    return True

def is_buffer_binary(buffer):
    """
    Uses python magic to check if the buffer is binary.  Buffer must be at least 2048 bytes
    and it must start at an offset of 0.
    """
    import magic

    mgc = magic.Magic(mime_encoding=True)
    return mgc.from_buffer(buffer) == 'binary'
