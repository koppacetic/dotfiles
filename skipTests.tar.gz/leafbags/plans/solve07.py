from tplanner.planlang import *

PARENT = "kvm-r2-u37.qqcyber.net"
USB_REGEX = "^usb_Alcor-Micro-Corp"

testPlan = PLANSPEC(
    script = 'tests.usb_windows',
    hostslots = [
        HOST(family="windows", os_version="10", parent=ParentCondition(name=PARENT)),
        RESOURCE(resource_type="usb", parent=ParentCondition(name=PARENT), name=RegexCondition(USB_REGEX))
    ],
    namespace = "solveTest-$t",
    planname = "solveTest",
    p_notes = "Windows host, USB by regex, same parent",
    samples = -1,
    replications = 1,
)

EXECUTE(testcase=testPlan)
