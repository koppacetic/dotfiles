from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

test_plan = PLANSPEC(
    script = "tests.gs_network",
    hostslots = [
        HOST(agent="gene"),
    ],
    namespace = f"gsNetwork_{TIMESTAMP}",
    planname = f"gsNetwork",
    verbose = True,
    samples = -1,
    replications = 5
)
EXECUTE(testcase=test_plan)
