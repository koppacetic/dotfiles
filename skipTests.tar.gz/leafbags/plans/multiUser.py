from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SAMPLES = 5

test_plan = PLANSPEC(
    script = "tests.check_agent",
    hostslots = [
        # Typical onsite run
        HOST(family="windows", architecture="x64"),
        HOST(family="windows", os_version="7", architecture="x64"),
        HOST(family="linux", os_name="debian", os_version="11", service_pack="6", architecture="x64"),
        HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")]),
    ],
    namespace = f"multiUser_{TIMESTAMP}",
    planname = f"multiUser",
    # verbose = True,
    samples = SAMPLES,
    replications = 1
)
EXECUTE(testcase=test_plan)
