from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

testPlan = PLANSPEC(
    script = "tests.evdet_windows",
    namespace = f"evdetWindows_{TIMESTAMP}",
    planname = "evdetWindows",
    p_notes = 'EventDetection Windows test',
    hostslots = [
        HOST(family="windows", os_version="10"),
        HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")])
    ],
    verbose = True,
    samples = 1
)
EXECUTE(testcase=testPlan)
