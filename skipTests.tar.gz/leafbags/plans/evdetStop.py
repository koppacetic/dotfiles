from tplanner.planlang import *

testPlan = PLANSPEC(
    namespace = "evdetStop-$t",
    planname = "evdetStop",
    p_notes = 'EventDetection stop test',
    script = "tests.evdet_stop",
    hostslots = [
        HOST(family="windows") - HOST(os_name="8"),
        HOST(name=RegexCondition("prerelease"), apps=[AppCondition("evdet")]),
        # HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")]),
    ],
    samples = 1
)
EXECUTE(testcase=testPlan)
