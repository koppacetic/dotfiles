from tplanner.planlang import *

multiPalantir = PLANSPEC(
    script = "tests.check_palantir",
    hostslots = [
        HOST(os_name="centos"),
        HOST(os_name="debian"),
        HOST(os_name="ubuntu"),
        HOST(family="windows"),
    ],
    namespace = "multi-palantir-$t",
    samples = 5,
#    replications=3
)
EXECUTE(testcase=multiPalantir)

# palantir_check_plan = PLANSPEC(
#     script = "tests.palantir_version_check",
#     hostslots = [
# #        HOST(),
#          HOST(
#              family='windows', os_version='10'
#         )
#         #$HOST(parent=ParentCondition(id='2a049b57-c9f3-40d2-b9ce-c1a27f3d6aff'))
#     ],
#     namespace = "test1-palantir-version-$t",
#     samples = -1,
# #    replications=3
# )
# EXECUTE(testcase=palantir_check_plan)

# palantir_check_plan_2 = PLANSPEC(
#     script = "tests.palantir_version_check",
#     hostslots = [
#         HOST(apps=[AppCondition("evdet")]),
#     ],
#     namespace = "test2-palantir-version-$t",
#     samples = -1,
# )
#EXECUTE(testcase=palantir_check_plan_2)

#palantir_check_evdet = PLANSPEC(
#    script = "tests.palantir_version_check",
##    hostslots = [HOST(os_name='centos'), HOST(id='7d2ecfa6-297a-40ca-83b1-e0398b4150c3')],
#    hostslots = [
#        HOST(apps=[AppCondition(RegexCondition(".*"))]),
#    ],
#    paramslots = [],
#    namespace = "test-evdet-$t",
#    samples = -1,
##    replications=5
#)
#EXECUTE(testcase=palantir_check_evdet)

#emissary_test = PLANSPEC(
#    script = "tests.emmisary_test",
#    hostslots = [HOST()],
#    paramslots = [],
#    namespace = "emissary_test-$t",
#    samples = -1,
##    replications=20
#)
#
#EXECUTE(testcase=emissary_test)
#
#process_test = PLANSPEC(
#    script = "tests.process_test",
##    hostslots = [HOST(os_name='centos'), HOST(id='7d2ecfa6-297a-40ca-83b1-e0398b4150c3')],
#    hostslots = [HOST()],
#    #hostslots = [HOST(virtualization_type='kvm')],
#    paramslots = [],
#    namespace = "test-process_listing-$t",
#    samples = -1,
##    replications=5
#)
#EXECUTE(testcase=process_test)
#
#put_test = PLANSPEC(
#    script = "tests.put_test",
#    hostslots = [HOST()],
#    paramslots = [],
#    namespace = "test-put_test-$t",
#    samples = -1,
##    replications=2
#)
#EXECUTE(testcase=put_test)
