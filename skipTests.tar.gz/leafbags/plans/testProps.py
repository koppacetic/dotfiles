from tplanner.planlang import *

theTest = PLANSPEC(
    script = 'tests.aprops',
    hostslots = [HOST()],
    paramslots = [],
    namespace = 'testProps-$t',
    samples = 1,
    replications = 1
)

EXECUTE(testcase=theTest)
