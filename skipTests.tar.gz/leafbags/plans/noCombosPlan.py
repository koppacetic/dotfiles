from tplanner.planlang import *

planSpec = PLANSPEC(
    script = "tests.sleep",
    hostslots = [HOST(os_name="cpm")],
    paramslots = [],
    namespace = "noCombos-$t",
    planname = "noCombos",
    samples = 1
)
EXECUTE(testcase=planSpec)
