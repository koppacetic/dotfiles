from tplanner.planlang import *

deb_host = HOST(os_name='debian')
ubuntu_host = HOST(os_name='ubuntu')

testPlan = PLANSPEC(
    namespace = "solveTest-$t",
    planname = "solveTest",
    script = "tests.scrapcode",
    hostslots = [
        deb_host | ubuntu_host,
        HOST(family='linux', os_name=['debian'], os_version=['10'], service_pack=['13']),
        HOST(apps=[AppCondition("evdet")])
    ],
    paramslots = [
        ['DoEvDet=@True'],
    ],
    p_notes = "Ubuntu or Debian host, Debian host, evdet",
    samples = -1,
)
EXECUTE(testcase=testPlan)
