from tplanner.planlang import *

for version in ["10", "8", "7"]:
    for arch in ["x86","x64"]:
        testPlan = PLANSPEC(
            script = 'tests.check_palantir',
            hostslots = [
                HOST(family="windows", os_version=version, architecture=arch)
            ],
            namespace = "loopWindows-$t",
            planname = f"loopWindows_{version}_{arch}",
            samples = -1,
            replications = 1,
        )
        EXECUTE(testcase=testPlan)
