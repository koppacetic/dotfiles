from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SLEEPTIME = 3
PARENT = "kvm-r2-u37.qqcyber.net"

test_plan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(),
        #HOST(parent=ParentCondition(name=PARENT)),
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"],
    ],
    namespace = f"skipSleep_{TIMESTAMP}",
    planname = f"skipSleep-{SLEEPTIME}s",
    p_notes = f"Sleep time: {SLEEPTIME} seconds",
    # verbose = True,
    samples = 3,
    replications = 1
)
EXECUTE(testcase=test_plan)
