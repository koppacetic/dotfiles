from tplanner.planlang import *

SLEEPTIME = 60
SCRIPT_TIMEOUT = 30

test_plan = PLANSPEC(
    script = "tests.script_timeout",
    hostslots = [
        HOST(),
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"], [f"script_timeout={SCRIPT_TIMEOUT}"]
    ],
    namespace = "scriptTimeout-$t",
    planname = f"scriptTimeout-{SCRIPT_TIMEOUT}s_{SLEEPTIME}s",
    p_notes = f"Sleep time: {SLEEPTIME} seconds, Timeout: {SCRIPT_TIMEOUT} seconds",
    # verbose = True,
    samples = 1,
    replications = 1
)
EXECUTE(testcase=test_plan)
