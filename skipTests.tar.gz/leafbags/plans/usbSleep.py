from tplanner.planlang import *

usbSleepPlan = PLANSPEC(
    script = 'tests.sleep',
    hostslots = [RESOURCE(resource_type='usb')],
    paramslots = [],
    namespace = 'usbSleep-$t',
    samples = -1,
    replications = 1
)

EXECUTE(testcase=usbSleepPlan)
