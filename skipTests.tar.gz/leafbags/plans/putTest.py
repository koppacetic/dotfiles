from tplanner.planlang import *

testplan = PLANSPEC(
    script = "tests.put_test",
    hostslots = [HOST()],
    # hostslots = [HOST(family='linux')],
    # hostslots = [HOST(name=RegexCondition("^windows_8.*265"))],
    # hostslots = [HOST(family="linux", os_name="debian")],
    # hostslots = [HOST(family='windows', os_version='10', build='1903')],
    # hostslots = [HOST(family='windows', os_version='10')],
    namespace = "putTest-$t",
    planname = "putTest",
    samples = 10
)
EXECUTE(testcase=testplan)
