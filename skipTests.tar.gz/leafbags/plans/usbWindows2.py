from tplanner.planlang import *

USB_REGEX = "^usb_Alcor-Micro-Corp_Flash-Drive_3_1_4_1"

testPlan = PLANSPEC(
    script = 'tests.usb_windows',
    hostslots = [
        HOST(family="windows", os_version="10", build="22H2", edition="pro", architecture="x64"),
        RESOURCE(resource_type="usb", name=RegexCondition(USB_REGEX))
    ],
    xattrs=XATTRS(parent="1"),
    namespace = "usbWindows2-$t",
    planname = "usbWindows2",
    samples = 1,
    replications = 1,
)

EXECUTE(testcase=testPlan)
