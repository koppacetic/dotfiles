from tplanner.planlang import *

SLEEPTIME = 5

test_plan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        # HOST(family="windows", os_version=["10", "11"], architecture="x64"),
        # HOST(family="windows", os_version=["7", "8", "8.1"], architecture="x64"),
        # HOST(family="linux", os_name=["debian", "ubuntu"]),
        HOST(family="linux", os_name=["alma", "centos", "fedora"]),
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"],
    ],
    namespace = "skipSleep-$t",
    planname = f"skipSleep-{SLEEPTIME}s",
    p_notes = f"Sleep time: {SLEEPTIME} seconds",
    # verbose = True,
    samples = -1,
    replications = 1
)
EXECUTE(testcase=test_plan)
