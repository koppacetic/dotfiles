from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
PARENT = "kvm-r2-u37.qqcyber.net"

testPlan = PLANSPEC(
    script = "tests.check_palantir",
    hostslots = [HOST()],
    # hostslots = [HOST(parent=ParentCondition(name=PARENT))],
    # hostslots = [HOST(language='ko-kr')],
    # hostslots = [HOST(name=RegexCondition(".*300"))],
    # hostslots = [HOST(os_name='debian', os_version='8')],
    # hostslots = [HOST(os_name='2012r2', edition='datacenter-desktop')],
    # hostslots = [HOST(family='linux')],
    # hostslots = [HOST(family='windows', os_version='10', build='21H2', edition='pro')],
    # hostslots = [HOST(family='windows', os_version='7', edition='professional', architecture='x64')],
    # hostslots = [HOST(family='windows', name=RegexCondition(".*333"))],
    namespace = f"checkPalantir_{TIMESTAMP}",
    planname = "checkPalantir",
    samples = 50,
    replications = 1,
)
EXECUTE(testcase=testPlan)
