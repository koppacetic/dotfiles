from tplanner.planlang import *

deb_host = HOST(os_name='debian')
ubuntu_host = HOST(os_name='ubuntu')

scrapcode_test_evdet = PLANSPEC(
    namespace = "scrapcodeTest-$t",
    planname = "scrapcodeTest-evdet",
    script = "tests.scrapcode",
    hostslots = [
        deb_host | ubuntu_host,
        HOST(family='linux', os_name=['debian'], os_version=['10'], service_pack=['13']),
        HOST(apps=[AppCondition("evdet")])
    ],
    paramslots = [
        ['DoEvDet=@True'],
    ],
    p_notes = 'EventDetection run',
    n_notes = 'NameSpace Notes A',
    samples = 1,
)
EXECUTE(testcase=scrapcode_test_evdet)

scrapcode_test = PLANSPEC(
    namespace = "scrapcodeTest-$t",
    planname = "scrapcodeTest-no-evdet",
    script = "tests.scrapcode",
    hostslots = [
        deb_host | ubuntu_host,
        HOST(family=['linux'], os_name=['debian'], os_version=['10'], service_pack='13'),
    ],
    paramslots = [
    ],
    p_notes = 'NonEventDetection Run',
    samples = 1,
)
EXECUTE(testcase=scrapcode_test)
