from tplanner.planlang import *

testPlan = PLANSPEC(
    script = "tests.esxi_basic",
    hostslots = [HOST(os_name="esxi", agent="none")],
    paramslots = [],
    namespace = "esxiPlan-$t",
    planname = "esxiPlan",
    samples = -1
)
EXECUTE(testcase=testPlan)
