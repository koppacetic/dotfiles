from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

testPlan = PLANSPEC(
    script = 'tests.alma_test',
    hostslots = [
        HOST(os_name="alma"),
    ],
    namespace = f"almaTest_{TIMESTAMP}",
    planname = "almaTest",
    samples = -1,
    replications = 1,
)

EXECUTE(testcase=testPlan)
