from tplanner.planlang import *

spec = PLANSPEC(
    script = "tests.em_test",
    hostslots = [HOST()],
    # paramslots=[
    #     ['username=emtuser'], ['password=EmtP@ss123'], ['method=reg'], ['createAcct=@True']
    # ],
    namespace = "checkEmissary-$t",
    planname = "checkEmissary",
    samples = -1,
)
EXECUTE(testcase=spec)

# linux_spec = PLANSPEC(
#     script = "tests.em_test",
#     hostslots = [HOST(family="linux")],
#     paramslots=[
#         ['username=emtuser'], ['password=EmtP@ss123'], ['method=reg'], ['createAcct=@True']
#     ],
#     namespace = "checkEmissary_linux-$t",
#     planname = "checkEmissary_linux",
#     samples = -1,
# )
# EXECUTE(testcase=linux_spec)

# windows_spec = PLANSPEC(
#     script = "tests.em_test",
#     hostslots = [HOST(family="windows")],
#     paramslots=[
#         ['username=emtuser'], ['password=EmtP@ss123'], ['method=gui'], ['createAcct=@True']
#     ],
#     namespace = "checkEmissary_windows-$t",
#     planname = "checkEmissary_windows",
#     samples = -1,
# )
# EXECUTE(testcase=windows_spec)
