from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d-%H:%M:%S")

test_plan = PLANSPEC(
    script = "tests.gs_getput",
    hostslots = [
        HOST(agent="gene"),
    ],
    namespace = f"gsGetPut_{TIMESTAMP}",
    planname = f"gsGetPut",
    # verbose = True,
    samples = -1,
    replications = 1
)
EXECUTE(testcase=test_plan)
