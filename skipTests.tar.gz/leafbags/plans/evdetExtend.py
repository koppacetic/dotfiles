from tplanner.planlang import *

testPlan = PLANSPEC(
    namespace = "evdetExtend-$t",
    planname = "evdetExtend",
    p_notes = 'EventDetection extend timeout',
    script = "tests.evdet_extend",
    hostslots = [
        HOST(family='linux', os_name=['debian'], os_version=['10'], service_pack=['13']),
        HOST(apps=[AppCondition("evdet")])
    ],
    samples = 1,
)
EXECUTE(testcase=testPlan)
