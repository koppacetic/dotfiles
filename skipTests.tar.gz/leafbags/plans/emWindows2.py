from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y%m%d-%H%M%S")
USERNAME = "emuser"
METHOD = "gui"
VERSIONS = ["10", "11", "2008r2", "2012", "2012r2", "2016", "2019", "2022", "7", "8.1", "8"]

for version in VERSIONS:
    if version == "8.1":
        host = HOST(family="windows", os_name=version, architecture="x64")
    else:
        host = HOST(family="windows", os_version=version, architecture="x64")

    test_plan = PLANSPEC(
        script = "tests.em_windows2",
        hostslots = [host],
        paramslots=[
            [f'username={USERNAME}'], ['password=emPassword123'], [f'method={METHOD}'], ['createAcct=@True']
        ],
        namespace = f"emWindows2-{TIMESTAMP}",
        planname = f"emWindows2-{version}-{METHOD}-{USERNAME}",
        p_notes = f"Windows: {version}, Method: {METHOD}, Username: {USERNAME}",
        # verbose = True,
        samples = -1,
        replications = 1
    )
    EXECUTE(testcase=test_plan)
