from tplanner.planlang import *

testPlan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(family="windows") % FACTORS(architecture=True),
        HOST(family="linux") % FACTORS(architecture=True),
    ],
    namespace = "solveTest-$t",
    planname = "solveTest",
    p_notes = "Windows FACTORS arch, Linux FACTORS arch",
    samples = -1,
    replications = 1
)
EXECUTE(testcase=testPlan)
