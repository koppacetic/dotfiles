from tplanner.planlang import *

os_names = ["centos", "debian", "ubuntu", "2012r2", "2016", "2019", "7", "8", "8.1", "10"]
for name in os_names:
    myTest = PLANSPEC(
        script = "tests.check_palantir",
        hostslots = [HOST(os_name=name)],
        namespace = "sampler-$t",
        planname = "sampler-{}".format(name),
        samples = 1
    )
    EXECUTE(testcase=myTest)
