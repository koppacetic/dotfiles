from tplanner.planlang import *

testPlan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(family='windows', os_version='10', build='21H2', edition='pro'),
    ],
    namespace = "solveTest-$t",
    planname = "solveTest",
    p_notes = "Specific family, os, build, and edition",
    samples = -1,
    replications = 1
)
EXECUTE(testcase=testPlan)
