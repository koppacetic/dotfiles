from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

test_plan = PLANSPEC(
    script = "tests.file_ops",
    hostslots = [
        HOST(agent="gene"),
    ],
    namespace = f"gsFileOps_{TIMESTAMP}",
    planname = f"gsFileOps",
    verbose = True,
    samples = -1,
    replications = 1
)
EXECUTE(testcase=test_plan)
