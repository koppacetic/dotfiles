from tplanner.planlang import *

SLEEPTIME = 10

test_plan = PLANSPEC(
    script = 'tests.sleep',
    hostslots = [
        HOST(),
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"],
    ],
    namespace = 'skipSleep2-$t',
    planname = f"skipSleep2-{SLEEPTIME}s",
    p_notes = f"Sleep time: {SLEEPTIME} seconds",
    samples = 10,
    replications = 1
)

EXECUTE(testcase=test_plan)
