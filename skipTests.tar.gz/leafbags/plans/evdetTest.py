from tplanner.planlang import *

# targets = HOST()
# targets = HOST(family="linux")
targets = HOST(os_name="ubuntu")

eventDet = HOST(apps=[AppCondition("evdet")])
# eventDet = HOST(name=[RegexCondition("^ubuntu_.*_evdet-stable")])

testPlan = PLANSPEC(
    script = "tests.evdet_test",
    hostslots = [targets, eventDet],
    paramslots = [],
    namespace = "evdetTest-$t",
    planname = "evdetTest",
    samples = 1
)
EXECUTE(testcase=testPlan)
