from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
# KVMS = ["kvm-r2-u30.qqcyber.net", "kvm-r2-u34.qqcyber.net", "kvm-r2-u37.qqcyber.net", "kvm-r2-u38.qqcyber.net"]
KVMS = ["kvm-r2-u30.qqcyber.net", "kvm-r2-u34.qqcyber.net", "kvm-r2-u38.qqcyber.net"]
# KVMS = ["kvm-r2-u37.qqcyber.net", "kvm-r2-u38.qqcyber.net"]
# KVMS = ["kvm-r2-u30.qqcyber.net", "kvm-r2-u34.qqcyber.net"]
# KVMS = ["kvm-r2-u37.qqcyber.net"]
SAMPLES = 10

for kvm in KVMS:
    short_name = kvm.replace(".qqcyber.net", "")
    testPlan = PLANSPEC(
        script = "tests.check_agent",
        hostslots = [
            HOST(parent=ParentCondition(name=kvm)),
            # HOST(parent=ParentCondition(name=kvm), architecture="x86"),
            # HOST(parent=ParentCondition(name=kvm), family="windows", os_version="11"),
            # HOST(parent=ParentCondition(name=kvm), family="linux"),
        ],
        namespace = f"kvmCheck_{TIMESTAMP}",
        planname = f"kvmCheck-{short_name}",
        samples = SAMPLES,
        replications = 1
    )
    EXECUTE(testcase=testPlan)
