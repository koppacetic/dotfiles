from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y%m%d-%H%M%S")

testPlan = PLANSPEC(
    script = "tests.subdirs",
    hostslots = [
        HOST(),
    ],
    namespace = f"subdirTest-{TIMESTAMP}",
    n_notes = "A simple sub-directory test",
    planname = f"subdirTest",
    samples = 1,
    replications = 1
)

EXECUTE(testcase=testPlan)
