from tplanner.planlang import *

for osname in ["alma", "centos", "debian", "fedora", "ubuntu"]:
    testPlan = PLANSPEC(
        script = 'tests.check_palantir',
        hostslots = [
            HOST(family="linux", os_name=osname)
        ],
        namespace = "loopLinux-$t",
        planname = f"loopLinux_{osname}",
        samples = -1,
        replications = 1,
    )
    EXECUTE(testcase=testPlan)
