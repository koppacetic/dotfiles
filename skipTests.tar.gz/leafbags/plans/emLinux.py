from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

emTest = PLANSPEC(
    script = "tests.em_linux",
    hostslots = [HOST(family="linux", os_name="debian")],
    paramslots = [
        ["username=user"], ["password=dartadmin"]
    ],
    namespace = f"emLinux_{TIMESTAMP}",
    planname = "emLinux",
    samples = 1
)
EXECUTE(testcase=emTest)
