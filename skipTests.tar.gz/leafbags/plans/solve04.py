from tplanner.planlang import *

testPlan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(family="windows"),
    ],
    namespace = "solveTest-$t",
    planname = "solveTest",
    p_notes = "Specific family",
    samples = -1,
    replications = 1
)
EXECUTE(testcase=testPlan)
