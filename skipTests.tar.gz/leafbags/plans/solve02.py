from tplanner.planlang import *

testPlan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(os_name="11"),
    ],
    namespace = "solveTest-$t",
    planname = "solveTest",
    p_notes = "Specific os_name",
    samples = -1,
    replications = 1
)
EXECUTE(testcase=testPlan)
