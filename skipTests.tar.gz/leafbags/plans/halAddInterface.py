from tplanner.planlang import *

testplan = PLANSPEC(
    script = "tests.hal_add_interface",
    hostslots = [
        HOST(),
    ],
    namespace = "halAddInterface-$t",
    planname = "halInterface",
    samples = 10
)
EXECUTE(testcase=testplan)
