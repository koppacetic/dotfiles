from datetime import datetime
from tplanner.planlang import *

NAMESPACE = "gsTestPlans"
TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
DEFAULT_SAMPLES = 3

USB_HOST = "kvm-r2-u37.qqcyber.net"

# Plan table
#  An array of dicts containing test parameters.
#
#  name: (required) PLANSPEC planname
#  script: (required) PLANSPEC script
#  hostslots: PLANSPEC hostslots. Can be a string or a list. Default: all
#             Valid string values:
#               all: HOST()
#               windows, linux, bsd: HOST(family=<stringvalue>)
#               gene: HOST(agent="gene")
#  paramslots: PLANSPEC paramslots. Default: []
#  samples: PLANSPEC samples. Default: DEFAULT_SAMPLES
PLANS = [
            # Basic tests
            {"name": "sleepTest", "script": "sleep", "hostslots": "gene", "samples": -1},
            {"name": "gsBasic", "script": "gs_basic", "hostslots": "gene", "samples": -1},
            {"name": "gsGetPut", "script": "gs_getput", "hostslots": "gene", "samples": -1},
            {"name": "gsNetwork", "script": "gs_network", "hostslots": "gene", "samples": -1},
            {"name": "checkAgent", "script": "check_agent", "hostslots": "gene", "samples": -1},
            {"name": "fileOps", "script": "file_ops", "hostslots": "gene", "samples": -1},

            # Emissary tests
            {"name": "gsEmissary", "script": "gs_emissary", "hostslots": "gene", "samples": -1},

            # EventDetection tests
            {"name": "evdetBasic", "script": "evdet_basic", "hostslots": [
                HOST(family="windows", os_version="10", agent="gene"),
                HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")])
            ]},
            {"name": "evdetExtend", "script": "evdet_extend", "hostslots": [
                HOST(family="windows", os_version="10", agent="gene"),
                HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")])
            ]},

            # HAL tests
            # {"name": "halReboot", "script": "hal_reboot", "hostslots": "gene"},
            # {"name": "halPower", "script": "hal_power", "hostslots": "gene"},
            {"name": "halSnapshot1", "script": "hal_snapshot1", "hostslots": "gene", "samples": -1},
            {"name": "halScreenshot", "script": "hal_screenshot", "hostslots": "gene", "samples": -1},

            # USB tests
            # {"name": "usbAttach", "script": "usb_attach", "hostslots": [
            #     HOST(family="windows", os_version="10", parent=ParentCondition(name=USB_HOST), agent="gene"),
            #     RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST)),
            # ]},
            # {"name": "usbWindows", "script": "usb_windows", "hostslots": [
            #     HOST(family="windows", os_version="10", parent=ParentCondition(name=USB_HOST), agent="gene"),
            #     RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST)),
            # ]},
        ]

def execute_plan(plan_info):
    plan_name = plan_info.get("name")
    script = plan_info.get("script")
    hostslots = plan_info.get("hostslots", "all")
    paramslots = plan_info.get("paramslots", [])
    samples = plan_info.get("samples", DEFAULT_SAMPLES)

    if hostslots == "all":
        planname = f"{plan_name}-{hostslots}"
        hosts = [HOST()]
    elif hostslots in ["windows", "linux", "bsd"]:
        planname = f"{plan_name}-{hostslots}"
        hosts = [HOST(family=hostslots)]
    elif hostslots == "gene":
        planname = f"{plan_name}-{hostslots}"
        hosts = [HOST(agent=hostslots)]
    elif isinstance(hostslots, list):
        planname = plan_name
        hosts = hostslots
    else:
        print(f"Invalid hostslots for {plan_name}")
        return

    test_plan = PLANSPEC(
        script = f"tests.{script}",
        hostslots = hosts,
        namespace = f"{NAMESPACE}_{TIMESTAMP}",
        planname = planname,
        paramslots = paramslots,
        samples = samples,
        replications = 1
    )
    EXECUTE(testcase=test_plan)

def run():
    for plan_dict in PLANS:
        execute_plan(plan_dict)

run()
