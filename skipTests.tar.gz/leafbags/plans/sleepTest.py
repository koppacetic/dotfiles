from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
PARENT = "kvm-r2-u38.qqcyber.net"
SLEEPTIME = 5
SAMPLES = 10

testPlan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(),
        # HOST(parent=ParentCondition(name=PARENT)),
        # HOST(family="windows", memory_mb="16184"),
        # HOST(family="windows", os_version="10"),
        # HOST(family="linux"),
        # HOST(agent="none"),
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"],
    ],
    namespace = f"sleepTest_{TIMESTAMP}",
    n_notes = "A simple sleep test",
    planname = f"sleepTest-{SLEEPTIME}s",
    p_notes = f"Sleep time: {SLEEPTIME} seconds",
    samples = SAMPLES,
    replications = 1
)

EXECUTE(testcase=testPlan)
