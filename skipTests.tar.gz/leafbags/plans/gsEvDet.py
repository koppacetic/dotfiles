from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")

testPlan = PLANSPEC(
    script = "tests.evdet_basic",
    namespace = f"gsEvDet_{TIMESTAMP}",
    planname = "gsEvDet",
    hostslots = [
        HOST(agent="gene"),
        HOST(name=RegexCondition("stable"), apps=[AppCondition("evdet")])
    ],
    samples = 1
)
EXECUTE(testcase=testPlan)
