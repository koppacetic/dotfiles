from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y%m%d-%H%M%S")
PARENT = "kvm-r2-u37.qqcyber.net"

testPlan = PLANSPEC(
    script = "tests.hal_tests",
    hostslots = [
        # HOST(),
        HOST(parent=ParentCondition(name=PARENT)),
        # HOST(family='windows'),
    ],
    namespace = f"halTests-{TIMESTAMP}",
    planname = "halTests",
    samples = 50
)
EXECUTE(testcase=testPlan)
