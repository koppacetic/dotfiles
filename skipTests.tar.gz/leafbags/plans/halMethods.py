from tplanner.planlang import *

testplan = PLANSPEC(
    script = "tests.hal_methods",
    hostslots = [HOST()],
    namespace = "halMethods-$t",
    planname = "halMethods",
    samples = 1
)
EXECUTE(testcase=testplan)
