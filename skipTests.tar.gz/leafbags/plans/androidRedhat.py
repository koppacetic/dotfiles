from tplanner.planlang import *

PARENT = "srv-r2-u37.incy.tech"
HOST_REGEX = "^(centos|fedora)"
USB_REGEX = "^usb_Google.*Pixel"

testPlan = PLANSPEC(
    script = 'tests.android_redhat',
    hostslots = [
        HOST(os_name=RegexCondition(HOST_REGEX), parent=ParentCondition(name=PARENT)),
        RESOURCE(resource_type="usb", parent=ParentCondition(name=PARENT), name=RegexCondition(USB_REGEX))
    ],
    namespace = "androidRedhat-$t",
    planname = "androidRedhat",
    samples = 3,
    replications = 1,
)

EXECUTE(testcase=testPlan)
