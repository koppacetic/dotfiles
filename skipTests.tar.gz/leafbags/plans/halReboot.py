from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y%m%d-%H%M%S")

FAMILY = "linux"
LINUX = ["alma", "centos", "debian", "fedora", "ubuntu"]
for version in LINUX:
    host = HOST(family=FAMILY, os_name=version)
    testplan = PLANSPEC(
        script = "tests.hal_reboot",
        hostslots = [host],
        namespace = f"halReboot-{TIMESTAMP}",
        planname = f"halReboot-{FAMILY}-{version}",
        p_notes = f"Family: {FAMILY}, Version: {version}",
        samples = -1,
        replications = 1
    )
    EXECUTE(testcase=testplan)

FAMILY = "bsd"
BSD = ["freebsd"]
for version in BSD:
    host = HOST(family=FAMILY, os_name=version)
    testplan = PLANSPEC(
        script = "tests.hal_reboot",
        hostslots = [host],
        namespace = f"halReboot-{TIMESTAMP}",
        planname = f"halReboot-{FAMILY}-{version}",
        p_notes = f"Family: {FAMILY}, Version: {version}",
        samples = -1,
        replications = 1
    )
    EXECUTE(testcase=testplan)

FAMILY = "windows"
WINDOWS = ["10", "11", "2008r2", "2012", "2012r2", "2016", "2019", "2022", "7", "8.1", "8"]
for version in WINDOWS:
    if version == "8.1":
        host = HOST(family=FAMILY, os_name=version)
    else:
        host = HOST(family=FAMILY, os_version=version)

    testplan = PLANSPEC(
        script = "tests.hal_reboot",
        hostslots = [host],
        namespace = f"halReboot-{TIMESTAMP}",
        planname = f"halReboot-{FAMILY}-{version}",
        p_notes = f"Family: {FAMILY}, Version: {version}",
        samples = -1,
        replications = 1
    )
    EXECUTE(testcase=testplan)
