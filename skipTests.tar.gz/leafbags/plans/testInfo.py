from tplanner.planlang import *

testplan = PLANSPEC(
    script = "tests.test_info",
    # hostslots = [HOST(family="linux", os_name="debian")],
    hostslots = [HOST(family='windows')],
    # hostslots = [HOST(family='windows', os_version='10', build='1903')],
    # hostslots = [HOST(family='windows', os_version='11')],
    # paramslots = [
    #     ["username=user"], ["password=dartadmin"]
    # ],
    namespace = "testInfo-$t",
    planname = "testInfo",
    samples = 1
)
EXECUTE(testcase=testplan)
