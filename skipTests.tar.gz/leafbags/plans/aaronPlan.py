from tplanner.planlang import *
from pathlib import Path
import os


PARAMSLOTS = [["pre_built=@True"]]

hostslots = [
    # Builder
    RESOURCE(family="linux", architecture="x64"),
    # Client
    RESOURCE(os_name="ubuntu", architecture="x64"),
    # Target
    RESOURCE(),
    # Server
    RESOURCE(os_name="debian", architecture="x64"),
]

test = PLANSPEC(
    script = 'tests.sleep',
    hostslots = hostslots,
    paramslots = PARAMSLOTS,
    namespace = 'aaronPlan-$t',
    samples = 1
)

EXECUTE(testcase=test)
