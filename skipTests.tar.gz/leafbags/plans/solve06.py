from tplanner.planlang import *

PARENT = "kvm-r2-u37.qqcyber.net"

testPlan = PLANSPEC(
    script = 'tests.usb_linux',
    hostslots = [
        HOST(family="linux", parent=ParentCondition(name=PARENT)),
        RESOURCE(resource_type="usb", parent=ParentCondition(name=PARENT))
    ],
    namespace = "solveTest-$t",
    planname = "solveTest",
    p_notes = "Linux host, any USB, same parent",
    samples = -1,
    replications = 1,
)

EXECUTE(testcase=testPlan)
