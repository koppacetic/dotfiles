from tplanner.planlang import *

testPlan = PLANSPEC(
    script = "tests.myexception",
    hostslots = [HOST()],
    namespace = "myException-$t",
    planname = "myException",
    samples = 1,
    replications = 1,
)
EXECUTE(testcase=testPlan)
