from tplanner.planlang import *

deb_host = HOST(os_name='debian')
ubuntu_host = HOST(os_name='ubuntu')

testPlan = PLANSPEC(
    namespace = "solveTest-$t",
    planname = "solveTest",
    script = "tests.scrapcode",
    hostslots = [
        deb_host | ubuntu_host,
        HOST(family=['linux'], os_name=['debian'], os_version=['10'], service_pack='13'),
    ],
    paramslots = [
    ],
    p_notes = "Ubuntu or Debian host, Debian host",
    samples = -1,
)
EXECUTE(testcase=testPlan)
