from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
USB_HOST = "kvm-r2-u37.qqcyber.net"
# USB_REGEX = "^usb_GEMBIRD_PhotoFrame"
USB_REGEX = "^usb_Alcor-Micro-Corp"

testPlan = PLANSPEC(
    script = 'tests.usb_linux',
    hostslots = [
        HOST(family="linux", parent=ParentCondition(name=USB_HOST)),
        # HOST(os_name="debian", parent=ParentCondition(name=USB_HOST)),
        # RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST), name=RegexCondition(USB_REGEX))
        RESOURCE(resource_type="usb", parent=ParentCondition(name=USB_HOST))
    ],
    namespace = f"usbLinux_{TIMESTAMP}",
    planname = "usbLinux",
    samples = 5,
    replications = 1,
)

EXECUTE(testcase=testPlan)
