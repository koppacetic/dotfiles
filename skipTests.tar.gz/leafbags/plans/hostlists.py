from tplanner.planlang import *

WINDOWS = HOST(family="windows")
WINDOWS10 = HOST(family="windows", os_version="10")

CENTOS = HOST(os_name="centos")
DEBIAN = HOST(os_name="debian")
UBUNTU = HOST(os_name="ubuntu")
