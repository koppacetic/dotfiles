import os

from tplanner.planlang import *

usbPlan = PLANSPEC(
    script = 'tests.usbTest',
    hostslots = [
        HOST(name='nudev2_debian10_x86_64_basebox', parent='10.100.1.20'),
        HOST(name='nudev2_debian10_x86_64_basebox', parent='10.100.1.20'),
        HOST(resource_type='usb')
    ],
    namespace = 'tybase_regression-$t',
    samples = -1,
    replications = 6
)

EXECUTE(testcase=usbPlan)
