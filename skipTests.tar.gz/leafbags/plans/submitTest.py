from tplanner.planlang import *

test_plan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(family="linux"),
    ],
    paramslots = [[]],
    namespace = "submitTest-$t",
    planname = f"submitTest",
    samples = -1,
    replications = 1
)
EXECUTE(testcase=test_plan)
