from tplanner.planlang import *

my_plan = PLANSPEC(
    script = "tests.check_user",
    hostslots = [HOST()],
    namespace = "checkUser-$t",
    planname = "checkUser",
    samples = 25
)
EXECUTE(testcase=my_plan)
