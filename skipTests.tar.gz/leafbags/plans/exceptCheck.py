from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
SAMPLES = 1

testPlan = PLANSPEC(
    script = "tests.except_check",
    hostslots = [
        HOST(),
    ],
    namespace = f"exceptCheck_{TIMESTAMP}",
    planname = f"exceptCheck",
    samples = SAMPLES,
    replications = 1
)

EXECUTE(testcase=testPlan)
