from tplanner.planlang import *

PARENT = "kvm-r2-u30.qqcyber.net"

testplan = PLANSPEC(
    script = "tests.hal_screenshot",
    hostslots = [
        HOST(),
        # HOST(family='windows', parent=ParentCondition(name=PARENT))
    ],
    namespace = "halScreenshot-$t",
    planname = "halScreenshot",
    samples = 3
)
EXECUTE(testcase=testplan)
