from tplanner.planlang import *

SLEEPTIME = 5

test_plan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(family="windows"),
        HOST(family="linux"),
        HOST(family="windows"),
        HOST(family="linux"),
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"],
    ],
    namespace = "multiSleep-$t",
    planname = "multiSleep",
    p_notes = f"Sleep time: {SLEEPTIME} seconds",
    samples = 3,
    replications = 1
)
EXECUTE(testcase=test_plan)
