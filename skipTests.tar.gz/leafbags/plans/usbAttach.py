from tplanner.planlang import *

SLEEPTIME = 1 * 10
PARENT = "kvm-r2-u37.int.qqcyber.net"
USB_REGEX = "^usb_Alcor-Micro-Corp"

test_plan = PLANSPEC(
    script = "tests.usb_attach",
    hostslots = [
        # HOST(parent=ParentCondition(name=PARENT)),
        HOST(os_name="debian", os_version="11", parent=ParentCondition(name=PARENT)),
        RESOURCE(resource_type="usb", parent=ParentCondition(name=PARENT), name=RegexCondition(USB_REGEX))
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"],
    ],
    namespace = "usbAttach-$t",
    planname = "usbAttach",
    p_notes = f"USB: {USB_REGEX}, Sleep: {SLEEPTIME} seconds",
    # verbose = True,
    samples = -1,
    replications = 2
)
EXECUTE(testcase=test_plan)
