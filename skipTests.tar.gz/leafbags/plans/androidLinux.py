from tplanner.planlang import *

PARENT = "kvm-r2-u37.qqcyber.net"
HOST_REGEX = "^(debian|ubuntu)"
USB_REGEX = "^usb_Google.*Pixel"

testPlan = PLANSPEC(
    script = 'tests.android_linux',
    hostslots = [
        HOST(family="linux", parent=ParentCondition(name=PARENT)),
        # HOST(os_name=RegexCondition(HOST_REGEX), parent=ParentCondition(name=PARENT)),
        RESOURCE(resource_type="usb", parent=ParentCondition(name=PARENT), name=RegexCondition(USB_REGEX))
    ],
    namespace = "androidLinux-$t",
    planname = "androidLinux",
    samples = -1,
    replications = 1,
)

EXECUTE(testcase=testPlan)
