from tplanner.planlang import *

testplan = PLANSPEC(
    script = "tests.rget_test",
    hostslots = [HOST()],
    # hostslots = [HOST(family='linux')],
    # hostslots = [HOST(name=RegexCondition("^windows_8.*265"))],
    # hostslots = [HOST(family="linux", os_name="debian")],
    # hostslots = [HOST(family='windows', os_version='10', build='1903')],
    # hostslots = [HOST(family='windows', os_version='10')],
    namespace = "rgetTest-$t",
    planname = "rgetTest",
    samples = 10
)
EXECUTE(testcase=testplan)
