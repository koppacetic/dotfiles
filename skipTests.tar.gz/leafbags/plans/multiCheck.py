from tplanner.planlang import *

testPlan4 = PLANSPEC(
    script = "tests.check_palantir",
    hostslots = [HOST(family='linux')],
    namespace = "checkPalantir",
    planname = "linux-$t",
    samples = 5
    #replications=3
)
EXECUTE(testcase=testPlan4)

testPlan = PLANSPEC(
    script = "tests.check_palantir",
    hostslots = [HOST(family='windows')],
    namespace = "checkPalantir",
    planname = "windows-$t",
    samples = 5
    #replications=3
)
EXECUTE(testcase=testPlan)

# testPlan5 = PLANSPEC(
#     script = "tests.check_palantir",
#     hostslots = [HOST(family='bsd')],
#     namespace = "checkPalantir",
#     planname = "bsd-$t",
#     samples = 20
#     #replications=3
# )
#EXECUTE(testcase=testPlan5)

# testPlan2 = PLANSPEC(
#     script = "tests.check_palantir",
#     hostslots = [HOST(agent='none')],
#     namespace = "checkPalantir",
#     planname = "no-agent-$t",
#     samples = 20
#     #replications=3
# )
#EXECUTE(testcase=testPlan2)

# testPlan3 = PLANSPEC(
#     script = "tests.check_palantir",
#     hostslots = [HOST(apps=[AppCondition(RegexCondition(".*"))])],
#     namespace = "checkPalantir",
#     planname = "apps-$t",
#     samples = 20
#     #replications=3
# )
#EXECUTE(testcase=testPlan3)
