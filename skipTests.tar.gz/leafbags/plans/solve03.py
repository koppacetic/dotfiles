from tplanner.planlang import *

testPlan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(),
    ],
    namespace = "solveTest-$t",
    planname = "solveTest",
    p_notes = "All hosts",
    samples = -1,
    replications = 1
)
EXECUTE(testcase=testPlan)
