from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y%m%d-%H%M%S")
VERSION = "10"
USERNAME = "emuser"
METHOD = "gui"

test_plan = PLANSPEC(
    script = "tests.em_windows",
    hostslots = [HOST(family="windows", os_version=VERSION)],
    paramslots=[
        [f'username={USERNAME}'], ['password=emPassword123'], [f'method={METHOD}'], ['createAcct=@True']
    ],
    namespace = f"emWindows-{TIMESTAMP}",
    planname = f"emWindows-{VERSION}-{METHOD}-{USERNAME}",
    p_notes = f"Windows: {VERSION}, Method: {METHOD}, Username: {USERNAME}",
    samples = 1,
    replications = 1
)
EXECUTE(testcase=test_plan)
