from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
PARENT = "kvm-r2-u34.qqcyber.net"

testPlan = PLANSPEC(
    script = "tests.hal_snapshot",
    hostslots = [HOST()],
    # hostslots = [HOST(family="linux")],
    # hostslots = [HOST(family="windows", os_version="10")],
    #hostslots = [HOST(family="windows", os_version ="8")],
    #hostslots = [HOST(family="linux", os_name="alma")],
    #hostslots = [HOST(family="linux", parent=[ParentCondition(name=PARENT)])],
    #hostslots = [HOST(family="windows", os_version="10", parent=[ParentCondition(name=PARENT)])],
    namespace = f"halSnapshot_{TIMESTAMP}",
    planname = "halSnapshot",
    samples = 10,
    replications = 1
)

EXECUTE(testcase=testPlan)
