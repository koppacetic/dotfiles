from tplanner.planlang import *

SLEEPTIME = 10

test_plan = PLANSPEC(
    script = 'tests.sleep',
    hostslots = [
        HOST(),
    ],
    paramslots = [
        [f"sleeptime={SLEEPTIME}"],
    ],
    namespace = 'gitTest-$t',
    planname = f"gitTest-{SLEEPTIME}s",
    p_notes = f"Sleep time: {SLEEPTIME} seconds",
    samples = 1,
    replications = 1
)

EXECUTE(testcase=test_plan)
