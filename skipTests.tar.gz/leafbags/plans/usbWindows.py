from datetime import datetime
from tplanner.planlang import *

TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
PARENT = "kvm-r2-u37.qqcyber.net"
# USB_REGEX = "^usb_GEMBIRD_PhotoFrame"
USB_REGEX = "^usb_Alcor-Micro-Corp"

testPlan = PLANSPEC(
    script = 'tests.usb_windows',
    hostslots = [
        HOST(parent=ParentCondition(name=PARENT)),
        # HOST(family="windows", os_version="10", build=RegexCondition("2.H."), edition="pro", parent=ParentCondition(name=PARENT)),
        # HOST(family="windows", os_version="10", edition="pro", parent=ParentCondition(name=PARENT)),
        # HOST(family="windows", os_version="11", build="21H2", parent=ParentCondition(name=PARENT)),
        # HOST(family="windows", os_version="10", build="22H2", edition=RegexCondition("^pro"), architecture="x64", parent=ParentCondition(name=PARENT)),
        # HOST(family="windows", os_version="10", build="22H2", architecture="x64", parent=ParentCondition(name=PARENT)),
        # RESOURCE(resource_type="usb", parent=ParentCondition(name=PARENT), name=RegexCondition(USB_REGEX)),
        RESOURCE(resource_type="usb", parent=ParentCondition(name=PARENT)),
    ],
    namespace = f"usbWindows_{TIMESTAMP}",
    planname = "usbWindows",
    samples = 5,
    replications = 1,
)

EXECUTE(testcase=testPlan)
