from tplanner.planlang import PLANSPEC, EXECUTE, HOST, RESOURCE, FACTORS

linux_host = HOST(family=['linux'])
test = PLANSPEC(
    script='tests.emissary_tests.linux_emissary_test',
    hostslots=[linux_host],
    paramslots=[
        ['username=emtuser'], ['password=EmtP@ss123'], ['method=reg'], ['createAcct=@True']
    ],
    namespace='emissaryTest-$t',
    planname='emissaryTest-linux',
    samples=-1
)
EXECUTE(testcase=test)

win_host = HOST(family=['windows'])
test = PLANSPEC(
    script='tests.emissary_tests.win_emissary_test',
    hostslots=[win_host],
    paramslots=[
        ['username=emtuser'], ['password=EmtP@ss123'], ['method=gui', 'method=reg'], ['createAcct=@True']
    ],
    namespace='emissaryTest-$t',
    planname='emissaryTest-windows',
    samples=10
)
EXECUTE(testcase=test)

wingman_tests = ['wingman_complex_test', 'wingman_text_test', 'wingman_unicode_test']
for wingman in wingman_tests:
    test = PLANSPEC(
        script="tests.emissary_tests.{}".format(wingman),
        hostslots=[win_host],
        namespace='emissaryTest-$t',
        planname="emissaryTest-{}".format(wingman),
        samples=10
    )
    EXECUTE(testcase=test)







# cli = RESOURCE(family=['win']) - RESOURCE(os=['2kpro', '2ksvr', '10ent'])
# cli = cli % FACTORS(os=True, ossp=True, arch=True, lang=True, apps=True)
#
# test = PLANSPEC(
#     script='undermine_testing.tests.win_emissary_test',
#     resourceslots=[cli],
#     paramslots=[
#         ['username=emtuser'], ['password=EmtP@ss123'], ['method=gui'],
#         ['createAcct=@True']
#     ],
#     planname='emissary_tests'
# )
#
# e = EXECUTE(testcase=test)
#
# cli = RESOURCE(family=['win']) - RESOURCE(os=['2kpro', '2ksvr', '10ent'])
# cli = cli % FACTORS(os=True, ossp=True, arch=True, lang=True, apps=True)
#
# test = PLANSPEC(
#     script='undermine_testing.tests.win_emissary_test',
#     resourceslots=[cli],
#     paramslots=[
#         ['username=emtuser'], ['password=EmtP@ss123'], ['method=gui'],
#         ['createAcct=@True']
#     ],
#     planname='emissary_tests'
# )
#
# e = EXECUTE(testcase=test)
#
# cli = RESOURCE(family=['win']) - RESOURCE(os=['2kpro', '2ksvr', '10ent'])
# cli = cli % FACTORS(os=True, ossp=True, arch=True, lang=True, apps=True)
#
# test = PLANSPEC(
#     script='undermine_testing.tests.win_emissary_test',
#     resourceslots=[cli],
#     paramslots=[
#         ['username=emtuser'], ['password=EmtP@ss123'], ['method=gui'],
#         ['createAcct=@True']
#     ],
#     planname='emissary_tests'
# )
#
# e = EXECUTE(testcase=test)
#
# cli = RESOURCE(family=['win']) - RESOURCE(os=['2kpro', '2ksvr', '10ent'])
# cli = cli % FACTORS(os=True, ossp=True, arch=True, lang=True, apps=True)
#
# test = PLANSPEC(
#     script='undermine_testing.tests.win_emissary_test',
#     resourceslots=[cli],
#     paramslots=[
#         ['username=emtuser'], ['password=EmtP@ss123'], ['method=gui'],
#         ['createAcct=@True']
#     ],
#     planname='emissary_tests'
# )
#
# e = EXECUTE(testcase=test)
