from tplanner.planlang import *

testPlan = PLANSPEC(
    script = "tests.sleep",
    hostslots = [
        HOST(family="windows"),
        HOST(family="linux"),
    ],
    namespace = "solveTest-$t",
    planname = "solveTest",
    p_notes = "Windows host, Linux host",
    samples = 500,
    replications = 1
)
EXECUTE(testcase=testPlan)
