#!/usr/bin/env python3
#
# Script:
#   rangeInfo.py - Display info about the range
#
# Description:
#  Display info about the range.
import argparse
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

# Third-party packages
import requests
from rich import print as rprint
from rich.table import Table
from dotenv import load_dotenv

# Constants
VERSION = "1.0.0"
PAGE_SIZE = 500
REQUESTS_TIMEOUT = 60
DART_ENV_FILE = Path(Path.home(), ".dart", "dart_cli.cfg")
HELP = """
Displays info about the range.
"""

JsonDict = Dict[str, Any]

def main():
    global settings

    # Parse command line
    parser = argparse.ArgumentParser(description=HELP)
    parser.add_argument("-D", "--debug", action="store_true", help="Debug mode")
    parser.add_argument("-V", "--version", action="version", version=f"rangeInfo.py {VERSION}", help="Print version")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose mode")
    settings = parser.parse_args()

    # Load and check env
    load_settings()

    vm_hosts = get_resources({"resource_type": "vm_host"})
    networks = get_resources({"resource_type": "network"})
    storage = get_resources({"resource_type": "storage_pool"})
    usbs = get_resources({"resource_type": "usb"})
    active_VMs = get_resources({"resource_type": "pc", "offline_time__isnull": True, "is_clone": False})
    linux_VMs = [x for x in active_VMs if x["properties"]["family"] == "linux" and x["properties"]["agent"] == "pal3"]
    windows_VMs = [x for x in active_VMs if x["properties"]["family"] == "windows" and x["properties"]["agent"] == "pal3"]
    none_VMs = [x for x in active_VMs if x["properties"]["agent"] == "none"]
    offline_VMs = get_resources({"resource_type": "pc", "offline_time__isnull": False, "is_clone": False})
    cloned_VMs = get_resources({"resource_type": "pc", "offline_time__isnull": True, "is_clone": True})

    resman = settings.resourceman.replace("https://", "")
    table = Table(title=resman, title_style="bold")
    table.add_column("ResourceType")
    table.add_column("Description")
    table.add_column("Count")
    table.add_row("VM_HOST", "VM Hosts", str(len(vm_hosts)))
    table.add_row("NETWORK", "Networks", str(len(networks)))
    table.add_row("STORAGE_POOL", "Storage Pools", str(len(storage)))
    table.add_row("USB", "USB Devices", str(len(usbs)))
    table.add_row("PC", "Offline", str(len(offline_VMs)))
    table.add_row("PC", "Clones", str(len(cloned_VMs)))
    table.add_row("PC", "Active", str(len(active_VMs)))
    table.add_row("PC", "Linux w/Agent", str(len(linux_VMs)))
    table.add_row("PC", "Windows w/Agent", str(len(windows_VMs)))
    table.add_row("PC", "No Agent", str(len(none_VMs)))
    rprint(table)

    sys.exit(0)

def get_resources(params: JsonDict) -> List[JsonDict]:
    resources_url = f"{settings.resourceman}/resources/"
    params["page_size"] =  PAGE_SIZE
    headers = {"Authorization": f"Bearer {settings.token}"}
    if settings.debug:
        print(f"GET {resources_url}, {params}")
    response = requests.get(resources_url, params=params, headers=headers, timeout=REQUESTS_TIMEOUT)
    response.raise_for_status()
    resp_json = response.json()
    resources = resp_json.get("results", [])

    next_url = resp_json.get("next")
    while next_url is not None:
        if settings.debug:
            print(f"GET {next_url}")
        response = requests.get(next_url, headers=headers, timeout=REQUESTS_TIMEOUT)
        response.raise_for_status()
        resp_json = response.json()
        results = resp_json.get("results", [])
        resources += results
        next_url = resp_json.get("next")

    if settings.debug:
        for ii, res in enumerate(resources):
            name = res.get("name")
            print(f"{ii}: {name}")
    if settings.verbose or settings.debug:
        print(f"Found {len(resources)} {params['resource_type']} resources")
    return resources


def load_settings():
    """Load and check settings"""
    load_dotenv(DART_ENV_FILE)
    settings.resourceman = os.environ.get("DART_RESMGR_URL")
    if settings.resourceman is None:
        abort(f"DART_RESMGR_URL not set, check {DART_ENV_FILE}")

    settings.token = os.environ.get("DART_AUTH_TOKEN")
    if settings.token is None:
        abort(f"DART_AUTH_TOKEN not set, check {DART_ENV_FILE}")

    requests_bundle = os.environ.get("REQUESTS_CA_BUNDLE")
    if requests_bundle is None:
        abort(f"REQUESTS_CA_BUNDLE not set, check {DART_ENV_FILE}")


def abort(msg: str):
    print(msg)
    sys.exit(1)


if __name__ == "__main__":
    main()
