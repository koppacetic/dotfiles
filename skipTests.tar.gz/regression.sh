#!/bin/bash
TESTS="skipSleep halTests putTest rgetTest emTest scrapcodePlan"
#TESTS="${TESTS} usbLinux usbWindows"

for test in ${TESTS}; do
    echo "Submitting plans.${test}..."
    dart_cli submit plans.${test}
    sleep 2
done

dart_cli show plans -l7
