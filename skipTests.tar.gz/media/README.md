# Scrap Code

ScrapCode is a cross-platform tool design to test the reactivity of Security Products by exhibiting malware-like behaviors. ScrapCode is written in Rust. Users compile ScrapCode with the appropriate Rust toolchain for the target platform, then add configuration and payload data to the binary using the included config_bin.py script.

## Building

### Build environment

* Install a toolchain [https://rust-lang.github.io/rustup/concepts/toolchains.html]

* Windows
  * Install Visual Studio build tools for Windows XP (v140 with XP support), v141, and v142 (latest)
  * Install the latest version of rust [https://www.rust-lang.org/tools/install]
  * For windows Vista through Windows 10 32-bit Add the `i686-pc-windows-msvc` toolchain
* Linux
  * Install the equivalent of Debian/Ubuntu's build-essential packages
  * Install the latest version of rust [https://www.rust-lang.org/tools/install]
  * For recent 32-bit Linux targets (2.6.32+, glibc 2.11+), add the `i686-unknown-linux-gnu` toolchain
* Other useful targets
  * see [https://doc.rust-lang.org/nightly/rustc/platform-support.html] for a full list
  * `i586-unknown-musl`: 32-bit Linux with the static standalone MUSL libc implementation
  * `i686-unknown-freebsd`: 32-bit FreeBSD
  * `i686-unknown-linux-musl`: 32-bit Linux with the static standalone MUSL libc implementation
  * `x86_64-unknown-freebsd`: 64-bit FreeBSD
  * `x86_64-unknown-linux-musl`: 64-bit Linux with MUSL
  * `x86_64-unknown-netbsd`: 64-but NetBSD
* Mac OS: TBD
* BSD: TBD

* payload types:
  * `json`: a JSON object
  * `txt`: UTF-8/ASCII text
  * `binary`: binary data (bytes)

* Compilation target examples:
  * 64-bit linux (standalone): `cargo build --target x86_64-unknown-linux-musl`
  * 32-bit windows Vista+:  `cargo rustc --target i686-pc-windows-msvc -- -C link-args=/SUBSYSTEM:CONSOLE,5.01 -C target-feature=+crt-static`
  * 64-bit windows 7+: `cargo rustc -- -C link-args=/SUBSYSTEM:CONSOLE,6.00 -C target-feature=+crt-static -L npcap-sdk-1.07/Lib/x64`

## Configuring

### Payload Data

* The first u8 is the number of operation that will be preformed
* From then on, format is opcode followed by config data for the op code as specified below

#### Drop File
In the binary:

```rust
struct Payload {
    pub payload_type: u16, // the type of payload from above
    // pub target_path_length: u16, // the length in bytes of the string in target_path_buf
        // stored in binary not saved into struct by rust after used to retireve correct amount of data
    pub target_path: String, // converted path information
    // pub payload_len: u32, // the number of bytes of the payload
        // stored in binary not saved into struct by rust after used to retireve correct amount of data
    pub payload: Vec<u8>, // buffer containing payload data.
}
```

How the python script interprets the same:

```python
return (
        struct.pack(
            "HHH", op_codes[OP_TYPES.DROP_FILE], payload_type, len(target_path_bytes)
        )
        + target_path_bytes
        + struct.pack("I", payload_len)
        + payload_buf
    )
```

* where: 
  * `op_code` indicates the operation to perform
  * `payload_type` is one of 'text', 'json', or 'binary'
  * `target_path_len` is the length of the string containing the target path
  * `target_path_bytes` is the the array containing the bytes of the target path string
  * `payload_len` is the length of the data file read from disk
  * `payload_buf` is the the array containing the data to be operated on (for the moment written to file)

* returns:
  * All bytes required for drop-file operation

#### UDP Ping (DNS Ping (port 53))
In the binary:

```rust
struct UDPPing {
    pub target_ip: [u8; 4], // u8 representation of each octal
    pub port: u16,          //port to ping
    pub num_of_pings: u16,  //number of times to send data
    pub delay: u64,         //delay in secs between data sends
    // pub data_length: u32, //(stored by python not needed in rust once data retrieved)
    pub data: Vec<u8>, // data to send over the port
}
```

How the python script interprets the same:

```python
return (
        struct.pack(
            "H",
            op_codes["udp-ping"],
        )
        + target_ip_bytes
        + struct.pack("HH", port, num_of_pings)
        + struct.pack("QI", delay, len(data_buf))
        + data_buf
    )
```

* where: 
  * `op_code` indicates the operation to perform
  * `target_ip_bytes` are the 4 u8s representing each octal of an IP Address
  * `port` the UDP port to ping
  * `num_of_pings` number of times to ping
  * `delay` is the length of time between pings
  * `data_len` is the length of the data_buf
  * `data_buf` is the the array containing the data to be sent to the specified IP and UDP port

* returns:
  * All bytes required for udp-ping operation

#### Arp Poisoning

In the binary:

```rust
struct ArpPoison {
    pub interface: u8, //interface number to attack on
    pub target_ip: [u8; 4], //octals of IP address
    pub spoof_ip: [u8; 4],  //octals of IP address
    pub ipv4_forward: bool,  //stored as u8 in binary by python
    pub bidirectional: bool, //stored as u8 in binary by python
    pub broadcast: bool,     //stored as u8 in binary by python
}
```

How the python script interprets the same:

```python
return struct.pack(
        "H12B",
        op_codes[OP_TYPES.ARP_POISON],
        interface,
        *target_ip_ints,
        *spoof_ip_ints,
        int(ipv4_forward),
        int(bidirectional),
        int(broadcast),
    )
```

* where: 
  * `op_code` indicates the operation to perform
  * `interface` the interface number to perform the attack on
  * `target_ip_ints` the 4 u8 ints representing each octal of the IP of the machine to be poisoned
  * `spoof_ip_ints` the 4 u8 ints representing each octal of the IP of the machine to be spoofed
  * `ipv4_forward` (linux only for now) enables ipv4 forwarding on the executing machine
  * `bidirectional` poison the spoofed ip with the target ip in addition to the target ip with the spoofed ip.
  * `broadcast` uses a gratuitous arp to update ALL hosts on the LAN of the fake MAC address for the target ip (and spoof IP if bidirectional). Will respond poison any host asking for target IP (and spoof IP if bidirectional) from then on.

* returns:
  * All bytes required for arp-spoof operation

### Configuration Tool

```shell
usage: config_bin.py [-h] [-o OUTPUT] binary_path configs_path

positional arguments:
  binary_path           path to the binary to configure
  configs_path          Path to json config file

optional arguments:
  -h, --help            show this help message and exit
  -o OUTPUT, --output OUTPUT
                        Path to configured binary file
```

#### JSON Config Example
```json
[
    {
        "operation": "udp-ping",
        "configs": {
            "target_ip": "192.168.56.106",
            "port": 53,
            "num_of_pings": 5,
            "delay": 1,
            "data_path": "./data/test_data.txt"
        }
    },
    {
	"operation": "drop-file",
	"configs": {
		"type": "txt",
		"target_path": "/home/box-admin/test_file.txt",
		"data_path": "./data/test_data.txt"
	}
    },
    {
        "operation": "arp-poison",
        "configs": {
            "interface": 1,
            "target_ip": "192.168.56.101",
            "spoof_ip": "192.168.56.50",
            "ipv4_forward": true,
            "bidirectional": true,
            "broadcast": true
        }
    }
]
```

* The current version of ScrapCode ha a built-in statically-allocated buffer in the binary that can be written to by the config_bin.py script. Both ScrapCode and config_bin.py share a definition of the structure of data stored in the buffer. 
* In this version one can specify any of three op-codes ['drop-file', 'udp-ping', 'arp-poison']
  * 'drop-file', will drop a file containing the data inserted into the binary at configuration time. config_bin.py reads from the file located at the data_path location and writes it unaltered to the binary. config_bin.py also stores the length of the data in the binary for use when ScrapCode reads it.
    * One also specifies the location (absolute path) to write the data on the target.
    * In this version the format of the output data isnt really used, but must be specified for completeness.
  * 'udp-ping', will ping back to the specified IP and Port with the data that is inserted into the binary at configuration time. config_bin.py reads from the file located at the data_path location and writes it unaltered to the binary. config_bin.py also stores the length of the data in the binary for use when ScrapCode reads it. This will be performed on the interval specified by num_of_pings and delay.
  * 'arp-poison', will perform arp-poisoning. This will set the executing host as a Man In The Middle (MITM). target_ip -> mitm (executing machine of tool) -> spoof_ip. If bidirectional is true, then a reverse path will also be setup. spoof_ip -> mitm (executing machine of tool) -> target_ip. If broadcast is true it will broadcast a gratuitous arp that gets ALL MACHINES on the LAN to update for the spoofed IP (target too if bidirectional). It will then attempt to maintain it's status as those IP by answering any query from ANY machine asking for the IP(s) being spoofed. If ipv4_forward is specified, linux only right now, the executing machine will be asked to forward traffic to the correct hosts (otherwise the true target will never be reached by the sender).

## Deployment

* Compile the binary for the target platform
* Run the configuration tool on the compiled binary
* Copy the compiled and configured file to the target
* Execute the binary on target
* ???
* Profit

## Other

Windows XP Pro SP3
key: MRX3F-47B9T-2487J-KWKMF-RPWBY
https://archive.org/details/WinXPProSP3x86
