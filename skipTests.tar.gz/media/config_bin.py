#! /usr/bin/env python3
import argparse
import json
import os
import struct
import sys
from typing import List

CONFIG_DATA_SIZE = 4096

# this value must be updated to reflect the placeholder value used to fill the static buffer defined in the binary
FILL_CHAR = b"\x49"


class OP_TYPES:
    DROP_FILE = "drop-file"
    UDP_PING = "udp-ping"
    ARP_POISON = "arp-poison"


op_codes = {
    OP_TYPES.DROP_FILE: 0,
    OP_TYPES.UDP_PING: 1,
    OP_TYPES.ARP_POISON: 2,
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("binary_path", help="path to the binary to configure")
    parser.add_argument("configs_path", help="Path to json config file")
    parser.add_argument("-o", "--output", help="Path to configured binary file")
    args = parser.parse_args()
    return args


def create_dropfile_buffer(type: str, target_path: str, data_path: str) -> bytes:
    TYPE_MAPPING = {
        "json": 0,
        "txt": 1,
        "bin": 2,
    }
    # read the data file
    payload_buf: bytes = b""
    if not os.path.exists(data_path):
        raise ValueError(f"data path '{data_path}' does not exist")
    with open(data_path, "rb") as dp_fd:
        payload_buf = dp_fd.read()

    payload_len = len(payload_buf)
    payload_type = TYPE_MAPPING[type]

    target_path_bytes = target_path.encode()

    param_bytes = 10

    max_payload_len = CONFIG_DATA_SIZE - param_bytes - len(target_path_bytes)
    if payload_len > max_payload_len:
        raise ValueError(
            f"data file length {len(payload_buf)} too large for buffer {max_payload_len}"
        )
    return (
        struct.pack(
            "HHH", op_codes[OP_TYPES.DROP_FILE], payload_type, len(target_path_bytes)
        )
        + target_path_bytes
        + struct.pack("I", payload_len)
        + payload_buf
    )


def create_udpping_buffer(
    target_ip: str, port: int, num_of_pings: int, delay: int, data_path: str
) -> bytes:
    target_ip_bytes = bytes([int(i) for i in target_ip.split(".")])

    # read the data file
    data_buf: bytes = b""
    if not os.path.exists(data_path):
        raise ValueError(f"data path '{data_path}' does not exist")
    with open(data_path, "rb") as dp_fd:
        data_buf = dp_fd.read()

    param_bytes = 22

    max_data_len = CONFIG_DATA_SIZE - param_bytes
    if len(data_buf) > max_data_len:
        raise ValueError(
            f"data file length {len(data_buf)} too large for buffer {max_data_len}"
        )
    return (
        struct.pack(
            "H",
            op_codes["udp-ping"],
        )
        + target_ip_bytes
        + struct.pack("HH", port, num_of_pings)
        + struct.pack("QI", delay, len(data_buf))
        + data_buf
    )


def create_arp_buffer(
    interface: int,
    target_ip: str,
    spoof_ip: str,
    ipv4_forward: bool,
    bidirectional: bool,
    broadcast: bool,
) -> bytes:
    # read the data file
    target_ip_ints = [int(i) for i in target_ip.split(".")]
    spoof_ip_ints = [int(i) for i in spoof_ip.split(".")]
    return struct.pack(
        "H12B",
        op_codes[OP_TYPES.ARP_POISON],
        interface,
        *target_ip_ints,
        *spoof_ip_ints,
        int(ipv4_forward),
        int(bidirectional),
        int(broadcast),
    )


def run():

    args = parse_args()

    if not os.path.exists(args.binary_path):
        raise ValueError(f"binary path '{args.binary_path}' does not exist")

    if not os.path.exists(args.configs_path):
        raise ValueError(f"config file path '{args.configs_path}' does not exist")

    with open(args.configs_path) as f:
        configs = json.load(f)

    buffer: bytearray = bytearray(struct.pack("B", len(configs)))
    for task in configs:
        print(f"Writing: {task}")
        op = task["operation"]
        if op == OP_TYPES.DROP_FILE:
            op_buffer = create_dropfile_buffer(**task["configs"])
        elif op == OP_TYPES.UDP_PING:
            op_buffer = create_udpping_buffer(**task["configs"])
        elif op == OP_TYPES.ARP_POISON:
            op_buffer = create_arp_buffer(**task["configs"])
        else:
            raise ValueError(f"{op} is not a valid operation type")
        
        buffer.extend(op_buffer)
        print("Operation %s is %i bytes\n" % (op, len(op_buffer)))
        
        if len(buffer) > CONFIG_DATA_SIZE:
            raise ValueError(
                f"Config data length {len(buffer)} too large for buffer {CONFIG_DATA_SIZE}"
            )

    # read the binary file
    with open(args.binary_path, "r+b") as b_fd:
        binary: bytes = b_fd.read()
        offset = binary.find(FILL_CHAR * 32)
        if offset == -1:
            raise RuntimeError(
                f"fill character pattern '{FILL_CHAR}' with length of at least 32 bytes not found in binary"
            )
        fill = FILL_CHAR * (CONFIG_DATA_SIZE - len(buffer))
        binary = binary[0:offset] + buffer + fill + binary[offset + CONFIG_DATA_SIZE :]

        if args.output:
            with open(f"{args.binary_path}.configured", "wb") as b_out:
                b_out.write(binary)
        else:
            b_fd.seek(0)
            b_fd.write(binary)

    print(f"Wrote: {buffer}")
    print("Total written: %i bytes" % len(buffer))

    # find the offset to the static array
    return 0


if __name__ == "__main__":
    sys.exit(run())
