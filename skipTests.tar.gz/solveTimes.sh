#!/bin/bash
trap "echo TERMINATED; exit" SIGINT

# Show environment tests were run in
rangeInfo.py

echo ""
echo -e "TEST\tCOMBOS\tTIME\tNOTES"
for testPath in leafbags/plans/solve*.py; do
    test=$(basename $testPath | sed -e 's/.py//')
    # echo dart_cli solve plans.${test}
    /bin/time -p -o ${test}-time.out dart_cli solve plans.${test} > ${test}.out
    combos=$(awk '/Combos:/ {print $2}' ${test}.out)
    notes=$(grep Notes: ${test}.out | cut -c14-)
    runtime=$(awk '/real/ {print $2}' ${test}-time.out)
    printf "%s\t%6d\t%6.2f\t%s\n" $test $combos $runtime "$notes"
done

rm -f solve*.out
exit 0
